/* TixTerex service worker (A43): makes the site installable and lets it open offline.
   Pages and data: network first and revalidated, the last copy only when offline (never a stale site after a deploy).
   Icons: cache first. Other websites are never touched. */
const V = 'tf-__TF_BUILD__', SHELL = ['./', 'index.html', 'site.webmanifest', 'icon-192.png', 'icon-512.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(V).then(c => c.addAll(SHELL)).catch(() => {})); self.skipWaiting(); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => { const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return;
  if (/\.(png|svg|webp|ico|woff2?)$/.test(u.pathname)) { e.respondWith(caches.match(r).then(m => m || fetch(r).then(res => { if (res.ok) { const c = res.clone(); caches.open(V).then(x => x.put(r, c)); } return res; }))); return; }
  /* always ask the server whether the page or data changed (no stale copy from the browser's own cache after a deploy) */
  e.respondWith(fetch(r, { cache: 'no-cache' }).then(res => { if (res.ok && (r.mode === 'navigate' || /\/data\/(ingest\/near|places)/.test(u.pathname))) { const c = res.clone(); caches.open(V).then(x => x.put(r, c)); } return res; })
    .catch(() => caches.match(r).then(m => m || (r.mode === 'navigate' ? caches.match('index.html') : Response.error())))); });
/* A71: alerts for followed artists and teams. The message arrives encrypted and is shown as it is; a tap opens the town. */
self.addEventListener('push', e => { let m = {}; try { m = e.data ? e.data.json() : {}; } catch (_) {}
  const title = String(m.title || 'TixTerex: new for you').slice(0, 120), url = /^https:\/\/(www\.)?tixterex\.com\//.test(m.url || '') ? m.url : './';
  e.waitUntil(self.registration.showNotification(title, { body: String(m.body || 'Something you follow has a new date.').slice(0, 300), icon: 'icon-192.png', badge: 'favicon-32.png', tag: m.tag || 'tf-follow', renotify: true, data: { url } })); });
self.addEventListener('notificationclick', e => { e.notification.close(); const url = (e.notification.data && e.notification.data.url) || './';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(ws => { for (const w of ws) if ('focus' in w && 'navigate' in w) return w.navigate(url).then(x => (x || w).focus()).catch(() => self.clients.openWindow(url)); return self.clients.openWindow(url); })); });
