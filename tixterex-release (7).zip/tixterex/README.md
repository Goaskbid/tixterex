TIXTEREX R95 - ORIGINAL VISUALS RESTORED

UPLOAD ONE FILE
Keep the R94 workflow already installed in your repository.
Create a new GitHub release, with a new tag such as r95-visual-restore.
Attach TixTerex-R95-RESTORED.zip without extracting it. Publish the release.
This ZIP contains the complete application, source, tools, images and place files.
Do not attach an older application ZIP alongside it. A separate inventory ZIP can
remain when it contains your newer collected data.
No new workflow file or separate place archives are required with R94.

WHAT RETURNS
The original jungle artwork, T-rex scenes and poses, logos, category panels,
colour-coded tickets, date styling, badges, footer artwork and mobile bottom dock.
The original illustrated visit planner, route links, weather and nearby-service
panels, checklist, sharing, advanced settings and source logs are reachable again.
The welcome artwork is accessible in Menu rather than taking over every load.

WHAT DOES NOT ROLL BACK
The current search engine, collector, source registry, place data, stored records,
image permissions, retry/continuation fixes and scoped service-worker behaviour.
The page remains readable in light mode. No sideways scrolling or running
background animations are reintroduced. Back to top and initial-top behaviour stay.
Unverified venue claims and invented completeness percentages do not return.

SCOPE
This is a file delivery. It has not been deployed to your repository by ChatGPT.
No production data, DNS, credentials, billing or collection schedule was changed.
No new real events were added. The supplied New York snapshot is unchanged and
keeps its expiry. This restoration does not establish 100/75 event coverage.
Browser checks use Chromium, local assets and controlled publisher responses.
Physical iPhone/Safari and production-origin access remain unverified.

FILES INSIDE
site/               Published website assets
src/                Canonical application source
tools/              Existing build, collection and validation tools
qa/                 Existing regression tests plus R95 checks
docs/R95_*          Restoration change register, preservation and test evidence
.github/workflows/  Exact copy of R94 workflow, not a new deployment requirement
