/* R93: static chrome before first paint; no polling and no scroll resets on repaint. */
(function(w,d){'use strict';
const root=d.documentElement;root.classList.add('r91','r93','r95','tt-still');root.classList.remove('tt-anim');root.dataset.theme='light';root.dataset.layout='auto';
w.TIXTEREX_STATIC_CHROME=true;try{history.scrollRestoration='manual';localStorage.setItem('tt:motion','off');localStorage.setItem('tf59:theme','light');}catch(_){}
let touched=false;const input=()=>{touched=true;};for(const name of ['pointerdown','touchstart','wheel','keydown'])w.addEventListener(name,input,{passive:true,once:true});
const top=()=>{w.scrollTo({left:0,top:0,behavior:'instant'});};
// Respect user interaction after startup. A later result/render is never a reason to move the viewport.
const initial=()=>{if(!touched)top();};initial();
w.addEventListener('pageshow',e=>{if(e.persisted){touched=false;top();}else initial();});
w.addEventListener('load',initial,{once:true});
function mount(){initial();let button=d.getElementById('ttBackTop');if(button)return;
button=d.createElement('button');button.id='ttBackTop';button.type='button';button.textContent='Back to top';button.setAttribute('aria-label','Back to top');button.hidden=true;
button.onclick=()=>{top();const target=d.getElementById('loc')||d.querySelector('.search-grid input');target?.focus({preventScroll:true});update();};d.body.append(button);
let frame=0;function update(){frame=0;button.hidden=w.scrollY<300||!!d.querySelector('dialog[open]');}
w.addEventListener('scroll',()=>{if(!frame)frame=requestAnimationFrame(update);},{passive:true});d.addEventListener('close',update,true);update();
}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})(window,document);
