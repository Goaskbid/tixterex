/* Short-lived, dated, source-checked publisher facts. Not a live coverage percentage. */
(function(w){'use strict';
const api=w.TTReviewedProgrammes={version:1,receipt:null};let loaded=null,epoch=0;
const stateOf=()=>{try{return typeof state!=='undefined'?state:w.state;}catch{return w.state;}};
const validNumber=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(+v);
const km=(a,b,c,d)=>Math.hypot((a-c)*111,(b-d)*111*Math.cos((a+c)*Math.PI/360));
async function records(){if(loaded)return loaded;loaded=fetch('data/reviewed-programmes.json',{credentials:'omit'}).then(r=>{if(!r.ok)throw Error('Snapshot not available');return r.json();}).catch(e=>{loaded=null;throw e;});return loaded;}
const key=e=>String(e.sourceUrl||e.url||'')+'|'+new Date(e.start).toISOString();
api.run=async function(){const session=w.TixTerexAudit?.getSession?.(),s=stateOf();if(!session||!s?.loc||!s.window||session.controller?.signal?.aborted)return;
if(!validNumber(s.loc.lat)||!validNumber(s.loc.lon)||km(+s.loc.lat,+s.loc.lon,40.714,-74.006)>Math.min(+s.filters?.radius||10,200)+30)return;
const run=++epoch;let data;try{data=await records();}catch(e){api.receipt={status:'unavailable',reason:e.message};return;}
if(run!==epoch||w.TixTerexAudit.getSession()!==session||session.controller?.signal?.aborted)return;
if(!(Date.parse(data.validUntil)>Date.now())){for(const [id,event]of session.rows)if(event.reviewedSnapshot)session.rows.delete(id);if(Array.isArray(s.events))s.events=s.events.filter(e=>!e.reviewedSnapshot);try{render();}catch(_){}api.receipt={status:'expired',accepted:0,observedAt:data.observedAt};return;}
const seen=new Set([...session.rows.values()].filter(e=>e.start).map(key));const ctx={lat:+s.loc.lat,lon:+s.loc.lon,radiusKm:+s.filters.radius||10,timeZone:s.timeZone,window:s.window};
const result=[];for(const record of data.records||[]){if(Date.parse(record.start)<Date.now()||Date.parse(record.validUntil)<=Date.now())continue;
if(!validNumber(record.lat)||!validNumber(record.lon)||seen.has(key(record)))continue;
const event=w.TFDeep?.card?.({...record,door:'Reviewed publisher programme'},ctx);if(!event)continue;
Object.assign(event,{sourceId:'reviewed-publisher-snapshot',source:record.source,licence:record.licence,factsOnly:true,reviewedSnapshot:true,observedAt:record.observedAt,observedUnknown:false});result.push(event);}
if(result.length){w.TixTerexAudit.consume({type:'events',events:result},session);try{render();}catch(_){}}
api.receipt={status:'dated_snapshot',accepted:result.length,observedAt:data.observedAt,validUntil:data.validUntil,scope:'limited manually checked performances; not complete live coverage'};
w.dispatchEvent(new CustomEvent('tf:inventory-updated',{detail:api.receipt}));
};
w.addEventListener('tf:search-start',()=>{++epoch;api.receipt=null;queueMicrotask(()=>api.run().catch(()=>{}));});
w.addEventListener('tf:search-finished',()=>api.run().catch(()=>{}));
w.addEventListener('tf:search-stop',()=>{++epoch;});
})(window);
