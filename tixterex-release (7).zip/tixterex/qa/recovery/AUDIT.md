# TixTerex: mobile, stability and event-supply recovery

**Audited input:** a90-202611241341. **Delivered candidate:** r91-recovery-1. **Status:** staging recovery, not a production or 100/75 certification.

## Executive decision

Treat this as three coupled problems: the visitor interface, search-state/continuation correctness, and actual event supply. The supplied project contains capable parsers and a large source directory, but neither guarantees a usable mobile journey or a maintained event inventory outside Zurich. Another background treatment or a higher source-count badge would miss the main failure.

The recovery changes the compiled application, provides reproducible source-module replacements, supplies a narrowly patched collector and adds deployment and benchmark gates. It does not deploy the site, connect a private provider account, alter billing, run a large crawl, or overwrite current event data. The original files remain unchanged.

The final package gate passes. The supplied nightly-supply gate fails because that index contains no cities. The 100/75 claim gate remains blocked because no independent live benchmark is attached. These are three different conclusions.

## 1. What the user's own search receipts establish

Both JSON exports describe Zurich, within 8 km. They are not evidence of a Geneva, Berlin or other non-Zurich production search. The shorter window contains 31 observed event rows, including 30 cached Eventsimple records. The wider window contains 236 observed rows, including 204 cached Eventsimple records. The owner's experience of an empty or unusable interface can therefore coexist with nonzero acquisition data. Neither export records the final number of cards actually visible after all active display filters.

The first export lists 507 source reports: 14 ok, one HTTP error, 396 requiring source review, four failed, and 92 queued. Examples include geohazard datasets, remote administrative datasets and survey layers. This is not 507 useful local calendars. Both directory summaries route 359 candidates, including 318 navigation-only links, 35 directory entries, five unresolved items and one configured-lane candidate. Other hardcoded readers exist, so that last number is not a claim that the application has exactly one working provider.

The local policy's deliberate OpenStreetMap-calendar block appears as 'Publisher HTTP 451'. That diagnostic is misleading: the code creates the response locally. The exact transport attribution is still a handoff task. Do not interpret it as proof that the publisher itself refused the deployed browser.

**Change:** the recovery export records query scope, effective display filters, transport output, unique session inventory, application state inventory, filtered occurrences and rendered cards. A future empty-result report can identify the exact stage that lost the result rather than guessing from source counts.

Evidence: `evidence/uploaded_search_evidence_summary.json`, `evidence/journey.json`.

## 2. Mobile is rebuilt as one consumer flow

The main screen now contains the original T-rex/logo, place, dates, distance and Find. Filters and Saved are the next actions. The native Filters dialog wraps controls vertically, and the Menu holds map, exports, settings, subscription and source evidence. Most of the retained secondary feature controls are moved rather than cloned, so their existing handlers survive.

The normal interface no longer presents the splash, rotating preview, crawl board, completeness meter, engineering self-test controls and competing status banners as customer content. Debugging information is retained behind an explicit diagnostic route. Client-side hiding is not a security boundary; secrets and private data still must never be shipped.

This release uses one explicit light theme, including native form controls and detail dialogs, regardless of the phone's OS dark preference. That is intentional. A future dark theme needs a separate acceptance matrix before reactivation. The solution is not to hide overflowing content with a root overflow rule. Tests check the bounding boxes of visible controls, the actual filter dialog, and the detail action at phone widths.

The factual event detail keeps the date/timezone, venue/address, price when known, cancellation/status, source observation, direct source/ticket link and save action. Directions open an explicit route link. The recovery does not invent a bar, accessibility, closing-door rule, travel duration or demand score. The older richer planning modules remain in source for selective reintroduction after their facts and interaction model are reviewed. The new default detail deliberately replaces their unsupported prose, rather than promising exact feature parity for every legacy planning screen.

**Measured:** 115 responsive assertions pass across 320, 390, 430, 768 and 1440 px, including dark OS preference at phone/tablet sizes. Ten additional journey checks pass for typed Geneva lookup, actual Find action, saved-view return, a failed Berlin source, successful retry and a rapid switch to Paris with a delayed superseded source. These use synthetic event responses, not real market coverage.

Evidence: `evidence/ui-final/`, `evidence/journey.json`.

## 3. Stability fixes are about ownership, not extra timers

The old page contains several search, display and enrichment controllers. The recovery gives browser venue continuation one owner. Each consumer slice can claim at most 24 programme requests and has a short deadline; the same query retains the existing 600-request programme ceiling across manual continuations. It does not reset that allowance after every slice. Pending source cursors survive a pause. A low-yield round or estimated percentage is not allowed to imply completion.

Only the active session may consume late events. If a new search is waiting for the old reader to settle, the latest waiting query resumes when the reader becomes available. Current-session guards prevent an aborted or superseded callback from contaminating another city's results. The request ceiling applies to the programme path; it is NOT asserted to count all physical requests across robots checks, initial federation, image enrichment and other independent modules. That broader accounting remains a separate engineering task.

The actual reader plus the actual recovery controller recover 600 of a 650-occurrence, 13-page synthetic Localist programme in the first slice and all 650 after continuation. Page one is not replayed on continuation. Separate controller tests validate the lifetime ceiling and queued-query transition. This proves those specific behaviours, not worldwide recall.

The heuristic that merged unrelated same-minute titles as translations is disabled. Four distinct programmes remain four; identity belongs in the common deduplicator using occurrence IDs, performance time, venue/room and language/format evidence.

Evidence: `evidence/controller.json`, `evidence/discovery_integration.json`, `evidence/current_contracts.json`.

## 4. Service-worker and version hazards

The original worker deletes all caches on the origin except its current cache name. A GitHub Pages origin can contain more than one project, so a worker must own a scoped namespace rather than treat every cache as its own. The replacement deletes only obsolete versions with this project's scope prefix. It leaves sibling-project caches and legacy unscoped caches alone. It does not forcibly activate a new worker while a user is searching.

The supplied workflow replaces `__TF_BUILD__`, yet the release HTML already contains a hardcoded build ID. It then writes a new version.json separately. That can leave mismatched identifiers. The legacy version watcher may reload the page when it sees the mismatch. Its session guard means this is not accurately described as an infinite reload every polling interval; it is still an unwanted interruption during an active visit.

The recovery replaces forced reload with an explicit update action and includes a stamping tool that writes the same ID into HTML, service worker and version JSON. VM tests cover cache ownership and the tool tests cover stamping and idempotence. A real installed-worker upgrade on the production origin remains mandatory; this environment did not run that lifecycle.

Evidence: `evidence/governance.json`, `evidence/tools_tests.json`. Integration: `docs/WORKFLOW_CHANGES.md`.

## 5. Why GitHub does not solve missing events

GitHub Pages publishes static files. It does not turn an unapproved directory entry into an executable feed or grant a browser permission to read another website. The publisher's CORS headers still govern cross-origin browser access. A generic network exception is not sufficient evidence that CORS, rather than DNS, connectivity or another cause, failed.

The current app has an in-browser virtual search transport. Its `/api`-shaped requests are intercepted and can load same-origin index shards and permitted browser feeds. It would be incorrect to diagnose every empty search as a missing server `/api/search` route. The staged typed-place test uses the actual stored directory successfully, including Geneva.

After assembling both supplied place ZIPs, all 3,043 referenced place files are present. This audit does not repeat the earlier missing-shards allegation. The problem is supply, routing and observability, not a demonstrated absence of the current place directory.

The supplied primary event snapshot remains 208 raw Zurich-area records generated on 12 November. The supplied nightly index has zero cities. A live GitHub cache could be different: no current Actions logs or exact deployed artifact hashes were supplied. Both facts must remain separate. No new real-world events were added by this recovery.

Official references: GitHub Pages overview; MDN CORS guide, listed in Sources below.

## 6. Deployment can succeed while collection failed

The uploaded workflow uses repository `site/index.html` whenever present and only downloads a release when that file is absent. An owner can therefore upload a newer release while deploying older repository files. Its release assembly merges all ZIPs and selects the first matching site tree. Source selection must become explicit and hash-checked.

Collection uses `continue-on-error`. The workflow requests 3,000 requests / 20 minutes, while the collector applies tighter limits on GitHub: 1,500 requests, 12 minutes, concurrency two and a three-second host gap. Neither configuration grants completeness. Do not 'fix' recall by silently raising those ceilings or ignoring the hosting/compliance plan.

The collector writes a global run lock before doing work and uses a 20-hour repeat guard. Retry and partial-run semantics need more acceptance tests. The recovery does not claim to have replaced that architecture. The handoff separates successful package assembly from maintained inventory, preserves last-good data, and retains diagnostic evidence rather than deleting it during recovery.

A package-only UI update can be staged while supply is being repaired, provided it retains valid production inventory and clearly reports incomplete coverage. It cannot be described as a successful worldwide event-discovery release.

## 7. Collector corrections supplied, not deployed

The guarded collector patch changes five exact behaviours: failed DNS lookup becomes fail-closed; explicit zero coordinates survive fallback; final publication uses the existing interval-overlap predicate; a 304 revalidation updates the successful-observation time; a temporary failed read records lastAttemptAt without resetting the last successful read timestamp.

The browser prefers the venue's last-good timestamp over a later failed attempt. Missing publisher observation remains unknown. A city-file generation timestamp is retained separately as snapshotAt, not relabelled as a source observation. This is the one deliberate mismatch with inherited test P24, which expects the old conflation. The inherited suite has 58 passing assertions and that one mismatch. Six new contract assertions cover the stricter provenance distinction and non-destructive tidy stage. No test file was silently rewritten to hide the discrepancy.

These collector changes have syntax and focused fragment tests. A complete external collection cycle, cancellation propagation through every provider and realistic partial-run/retry tests remain outstanding. DNS failure closure is not a complete SSRF or DNS-rebinding security certification.

## 8. Pictures and speed

The recovery disables the old name-based venue-photo fan-out and the redundant jungle/intro/phone presentation modules. A viewport-aware image loader prefers permitted event imagery, then a matched venue image, then the original mascot fallback. Artwork and venue photographs are not treated as evidence of the exact performance. Source credit and failure fallback remain.

The candidate HTML is about 1.75 MB versus 1.79 MB in this supplied release. This is a modest byte reduction, not the dramatic reduction claimed for a different earlier package. Much of this recovery's benefit is reduced UI competition and unnecessary discovery/enrichment work. No deployed performance percentage, Core Web Vitals score or median live search latency has been certified. The full minified application still has legacy modules to retire at the build layer; the module handoff prevents another uncontrolled stack of presentation overrides.

## 9. Ticketcorner, without a fictitious feed

The visitor subscription route is implemented as a direct link to Ticketcorner's official newsletter page. The user completes subscription and consent there. This does not subscribe anyone automatically and does not populate TixTerex's event database.

Ticketcorner's official partner page describes a free affiliate partnership after review and directs automated integration enquiries to redaktion@ticketcorner.ch. It requires direct links rather than an internal redirect. The package includes an inactive partner configuration, exact setup questions and an unsent application draft. No account, secret, feed URL or image licence was invented.

An approved affiliate link is not evidence of bulk feed access or image reuse rights. Map the actual authorised feed/schema, preserve publisher occurrence IDs and update/cancellation timestamps, and keep credentials out of public HTML. This is the next operator integration, not a connection already activated here.

## 10. The 100/75 acceptance path

The target remains 100% of independently enumerated top-event occurrences and at least 75% of a stated public-event sample for the same geography and fixed 14-day window. Count performances, not titles; preserve film sessions, room/language variants, sports fixtures, free/community events and multi-day occurrences according to a documented counting rule.

The package contains a 24-city registry, evidence contracts, a scoring script, explicit missed-top reasons, confidence intervals and evidence hashes. All 24 cities currently report UNMEASURED. The point target and the stricter lower-confidence-bound release gate are separately labelled. Neither source-count nor population proxies can satisfy them.

Prioritise maintained approved broad feeds and primary top-venue programmes, then independent city/community calendars to close long-tail gaps. Each missed top occurrence becomes a concrete source, access, rights, parsing, timezone, location, identity, freshness, filtering or rendering repair. The benchmark's random-sample frame must itself be described and audited; a sample cannot prove the frame includes every public event.

## 11. What is and is not verified

Verified locally: compiled-script syntax, responsive layout/control visibility in Chromium, typed local place resolution, synthetic live-provider normalisation through the actual app, saved/detail/retry/city-switch journeys, source-cursor continuation, controller cancellation and bounded claims, scoped cache logic in a VM, build stamping, data-file preservation and the new provenance contract.

Not verified: real iPhone Safari, physical Android devices, slow mobile hardware, final-origin CORS, real external image availability, installed service-worker upgrades, live push, a completed production collection run, Ticketcorner partner activation, deployed data freshness, market-wide precision or 100/75 recall. External publisher endpoints could not be read from this execution environment; attempted Geneva and Berlin API checks also failed in the web tool. These failures do not establish that the publisher is down.

The browser harness uses set_content with an opaque origin, blocks outside requests and bridges mounted local files to a synthetic same-site origin. That same-origin bridge is a documented test accommodation; it does not bypass a live publisher's permission. Screens with eight records per city contain clearly labelled synthetic fixtures. Baseline screenshots establish visual behaviour only; earlier blocked-network baseline result counts are not used as live coverage evidence.

## Sources

- Exact uploaded release, source archive, both place archives, both search JSONs and workflow. See INPUT_SHA256.json.
- Ticketcorner partner programme: https://www.b2b.ticketcorner.ch/produkte-services/affiliate-partner
- Ticketcorner newsletter: https://www.ticketcorner.ch/campaign/ticketcorner-newsletter/
- GitHub Pages overview: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- MDN CORS: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CORS

## Detailed change register

See CHANGE_REGISTER.csv and FINDINGS.json for 26 prioritised, located findings. A fixed interface does not mark outstanding supply work fixed, and a source-inspection risk is not represented as a measured production outage.
