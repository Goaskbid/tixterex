#!/usr/bin/env python3
import importlib.util,json,tempfile,copy
from pathlib import Path
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('score',root/'benchmark/score.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
scope={'place':'Fixture city','centre':{'lat':47,'lon':8},'radius':8,'timezone':'Europe/Zurich','startDate':'2026-11-24','endDate':'2026-12-07'}
e={'id':'one','title':'Synthetic fixture','sourceUrl':'https://example.test/event','start':'2026-11-25T19:00:00+01:00','venue':'Fixture hall'}
t={'scope':scope,'independentSources':['synthetic-only-test'],'topVenueInventoryComplete':True,'top':[e],'publicSample':[e],'sampling':{'design':'simple_random_without_replacement','seed':0,'frameDescription':'Synthetic frame'}}
o={'scope':scope,'events':[{'id':'obs1'}]};pairs={'pairs':[{'truthId':'one','observedId':'obs1','adjudicated':True}]};results=[]
with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 def write(a,b,c):
  for suffix,x in [('truth',a),('observed',b),('matches',c)]: (d/('fixture.'+suffix+'.json')).write_text(json.dumps(x))
 def run(name,a,b,c,valid):
  write(a,b,c)
  try:got=m.city_score(d,'fixture');ok=valid
  except ValueError as ex:got=str(ex);ok=not valid
  results.append({'name':name,'pass':ok,'actual':got})
 results.append({'name':'Missing evidence stays unmeasured','pass':m.city_score(d,'missing')['status']=='unmeasured'})
 run('Seed zero and identical top/public overlap are valid',t,o,pairs,True)
 bad=copy.deepcopy(t);bad['publicSample']*=2;run('Duplicate truth sample rejected',bad,o,pairs,False)
 bad=copy.deepcopy(t);bad['scope']['endDate']='2026-12-06';oo=copy.deepcopy(o);oo['scope']=bad['scope'];run('Non-14-day scope rejected',bad,oo,pairs,False)
 pp=copy.deepcopy(pairs);pp['precisionSample']=[{'observedId':'obs1','validOccurrence':True}]*2;run('Duplicate precision sample rejected',t,o,pp,False)
 pp=copy.deepcopy(pairs);pp['precisionSample']=[{'observedId':'obs1','validOccurrence':True}];run('Undocumented precision interval rejected',t,o,pp,False)
result={'basis':'Synthetic scorer-contract tests, not a live event benchmark.','passed':sum(r['pass'] for r in results),'failed':sum(not r['pass'] for r in results),'tests':results}
(root/'evidence/benchmark_tests.json').write_text(json.dumps(result,indent=2));print(result['passed'],result['failed']);raise SystemExit(bool(result['failed']))
