import vm from 'node:vm';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const tests=[];
function check(name,actual,expected=true){tests.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});}
const handlers={},deleted=[],skipped=[],intercepts=[];const scope='https://example.test/project/';let notified;
const ctx={URL,Response,Request,Promise,console,fetch:async()=>new Response('ok'),caches:{open:async()=>({put:async()=>{},match:async()=>null}),keys:async()=>['tixterex:%2Fproject%2F:old','tixterex:%2Fproject%2F:r91-recovery-1','tixterex:%2Fother%2F:old','other-app-cache','tf-old-unscoped'],delete:async k=>deleted.push(k)},self:{registration:{scope,showNotification:async(t,o)=>notified=o},skipWaiting:()=>skipped.push(1),clients:{claim:async()=>{},matchAll:async()=>[],openWindow:async()=>{}},addEventListener:(type,fn)=>handlers[type]=fn}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(root,'patch/modules/service-worker.js'),'utf8'),ctx);
let work;handlers.install({waitUntil:p=>work=p});await work;check('Installation does not force activation',skipped.length,0);
handlers.activate({waitUntil:p=>work=p});await work;check('Activation deletes only current-scope obsolete caches',deleted,['tixterex:%2Fproject%2F:old']);
for(const url of ['https://example.test/other/x.json','https://other.test/project/x.json','https://example.test/project/version.json','https://example.test/project2/index.html'])handlers.fetch({request:{url,method:'GET'},respondWith:p=>intercepts.push(url)});
check('Sibling, cross-origin and version fetches untouched',intercepts,[]);
handlers.message({data:{type:'ACTIVATE_UPDATE'}});check('Only explicit message activates pending update',skipped.length,1);
handlers.push({data:{json:()=>({title:'Test',url:'https://unrelated.test/x'})},waitUntil:p=>work=p});await work;check('Notification URL stays in own scope',notified.data.url,scope);
// Execute exact old/new source fragments, not a substitute implementation.
const collector=fs.readFileSync(path.join(root,'patch/collector/ingest.mjs'),'utf8');
let source=collector.slice(collector.indexOf('const H='),collector.indexOf('export const pubImg='));source+='globalThis.within=B;';
const c={Date,u:{keepDays:200}};vm.createContext(c);vm.runInContext(source,c);
check('Ongoing multi-day event remains in publication window',c.within(new Date(Date.now()-3*864e5).toISOString(),new Date(Date.now()+864e5).toISOString()));
check('Terminal collector filter uses the overlap predicate',collector.includes('n.events[e]=n.events[e].filter((e=>B(e.start,e.end)))'));
check('Explicit zero coordinates survive fallback',vm.runInNewContext('const t={lat:0,lon:0},e={lat:47,lon:8};({lat:t.lat??e.lat,lon:t.lon??e.lon})'),{lat:0,lon:0});
const keep=collector.match(/e\.lastAttemptAt=Date\.now\(\);e\.why="kept last good programme:[\s\S]*?;e\.stale=[^;]+;/)?.[0];
if(!keep)throw new Error('Retained inventory patch not found');const stale={e:{read:1000,good:1000},t:{why:'503'},Date};vm.runInNewContext(keep,stale);check('Failed fetch does not advance last successful read',stale.e.read,1000);check('Failed fetch records distinct last attempt',stale.e.lastAttemptAt>1000);
check('DNS failure returns denial rather than allowing dispatch',collector.includes('catch(e){return false}j.set(n,a);return a}'));
const result={basis:'Node VM unit tests, not real service-worker lifecycle or production collection.',passed:tests.filter(t=>t.pass).length,failed:tests.filter(t=>!t.pass).length,tests};const out=process.argv[2]||path.join(root,'evidence/governance.json');fs.writeFileSync(out,JSON.stringify(result,null,2));console.log(result.passed,result.failed);process.exitCode=+!!result.failed;
