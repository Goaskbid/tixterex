import json
from urllib.parse import urlsplit,parse_qs
def response(x,status=200):return {'body':json.dumps(x),'status':status,'type':'application/json'}
def fixtures(url):
 u=urlsplit(url);q=parse_qs(u.query)
 if u.hostname=='eventsimple.de' and u.path.startswith('/api/events'):
  lat=float(q.get('lat',['46.2044'])[0]);lon=float(q.get('lng',['6.1432'])[0]);name='Geneva' if lat<47 else 'Zurich' if lat<48 else 'Paris' if lat<50 else 'Berlin';cc='FR' if name=='Paris' else 'DE' if name=='Berlin' else 'CH'
  events=[{'id':10000+round(lat*100)+i,'title':f'{name} offline fixture {i+1}','starts_at':f'2026-11-{25+i%3:02d}T19:00:00+01:00','ends_at':f'2026-11-{25+i%3:02d}T21:00:00+01:00','all_day':False,'latitude':lat,'longitude':lon,'has_coordinates':True,'venue':f'{name} fixture hall {i%3}','city':name,'country':cc,'url':f'https://fixture.example/{name.lower()}/{i}','detail_url':f'https://eventsimple.de/event/{10000+i}','category':['concert','theatre','family','cinema'][i%4]} for i in range(8)]
  return response({'events':events,'total':8,'count':8,'truncated':False})
 if 'opendatasoft.com' in (u.hostname or ''):return response({'results':[],'total_count':0})
 if 'overpass' in (u.hostname or ''):return response({'elements':[]})
 if u.hostname=='query.wikidata.org':return response({'results':{'bindings':[]}})
 if (u.hostname or '').endswith('wikipedia.org') or u.hostname=='commons.wikimedia.org':return response({'query':{'pages':{}}})
 return None
