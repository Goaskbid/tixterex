#!/usr/bin/env python3
"""Offline browser integration through the real runtime and federation.
Fixtures are synthetic and do not measure live recall or final-origin CORS.
"""
from pathlib import Path
import sys,json,time,argparse,math
from urllib.parse import urlsplit,parse_qs
from playwright.sync_api import sync_playwright
sys.path.insert(0,str(Path(__file__).resolve().parent))
from local_harness import load
p=argparse.ArgumentParser();p.add_argument('--site',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--quick',action='store_true');args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
def response(x,status=200):return {'body':json.dumps(x),'status':status,'type':'application/json'}
def fixtures(url):
 u=urlsplit(url);q=parse_qs(u.query)
 if u.hostname=='eventsimple.de' and u.path.startswith('/api/events'):
  lat=float(q.get('lat',['46.2044'])[0]);lon=float(q.get('lng',['6.1432'])[0]);name='Geneva' if lat<47 else 'Zurich' if lat<48 else 'Paris' if lat<50 else 'Berlin';cc='FR' if name=='Paris' else 'DE' if name=='Berlin' else 'CH'
  events=[{'id':10000+round(lat*100)+i,'title':f'{name} offline fixture {i+1}','starts_at':f'2026-11-{25+i%3:02d}T19:00:00+01:00','ends_at':f'2026-11-{25+i%3:02d}T21:00:00+01:00','all_day':False,'latitude':lat,'longitude':lon,'has_coordinates':True,'venue':f'{name} fixture hall {i%3}','city':name,'country':cc,'url':f'https://fixture.example/{name.lower()}/{i}','detail_url':f'https://eventsimple.de/event/{10000+i}','category':['concert','theatre','family','cinema'][i%4]} for i in range(8)]
  return response({'events':events,'total':8,'count':8,'truncated':False})
 if 'opendatasoft.com' in (u.hostname or ''):return response({'results':[],'total_count':0})
 if 'overpass' in (u.hostname or ''):return response({'elements':[]})
 if u.hostname=='query.wikidata.org':return response({'results':{'bindings':[]}})
 if (u.hostname or '').endswith('wikipedia.org') or u.hostname=='commons.wikimedia.org':return response({'query':{'pages':{}}})
 return None
summary={'basis':'Offline, real compiled application; synthetic provider responses; no publisher network certification.','screens':[],'assertions':[]}
def check(name,actual,expected=True):summary['assertions'].append({'name':name,'actual':actual,'expected':expected,'pass':actual==expected})
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 cases=[(390,'dark')] if args.quick else [(320,'dark'),(390,'dark'),(430,'light'),(768,'dark'),(1440,'light')]
 for width,scheme in cases:
  ctx=browser.new_context(viewport={'width':width,'height':844 if width<768 else 1000},is_mobile=width<768,has_touch=width<768,color_scheme=scheme,timezone_id='Europe/Zurich',service_workers='block')
  page,errors,calls=load(ctx,args.site,fixtures=fixtures);page.wait_for_timeout(1200)
  def read():return page.evaluate('''()=>{const visible=e=>!!e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden';const rect=e=>({x:e.getBoundingClientRect().x,right:e.getBoundingClientRect().right,width:e.getBoundingClientRect().width});return{width:innerWidth,scrollWidth:document.documentElement.scrollWidth,color:getComputedStyle(document.body).color,background:getComputedStyle(document.body).backgroundColor,queryColor:getComputedStyle(document.getElementById('q')).color,queryBackground:getComputedStyle(document.getElementById('q')).backgroundColor,searchRect:rect(document.getElementById('btnGo')),visibleTechnical:['tfIntro','preview','statusbar','tfComplete','tfDeep','tfCoverageContinuation','buildTag','btnTestLab'].filter(id=>{const e=document.getElementById(id);return e&&visible(e)}),clippedControls:[...document.querySelectorAll('input,button,select,a')].filter(visible).filter(e=>{const r=e.getBoundingClientRect();return r.left<-.5||r.right>innerWidth+.5}).slice(0,30).map(e=>({id:e.id,text:e.textContent.trim().slice(0,60),...rect(e)})),text:document.body.innerText.slice(0,5000),state:typeof state!=='undefined'?{count:state.events.length,city:state.city,cc:state.cc,filters:state.filters,status:TixTerexAudit.getSession()?.status}:null,recovery:window.TTRecovery?.receipt?.()}}''')
  initial=read();page.screenshot(path=str(args.output/f'{width}-{scheme}-home.png'));check(f'{width} page fits',initial['scrollWidth']<=width+1);check(f'{width} no visitor diagnostics',initial['visibleTechnical'],[]);check(f'{width} primary controls within viewport',initial['clippedControls'],[]);check(f'{width} light surface under OS {scheme}',initial['background'],'rgb(247, 247, 242)')
  cities=[('Geneva','CH',46.2044,6.1432,'Europe/Zurich'),('Berlin','DE',52.52,13.405,'Europe/Berlin'),('Paris','FR',48.8566,2.3522,'Europe/Paris')] if width==390 else [('Geneva','CH',46.2044,6.1432,'Europe/Zurich')]
  searches=[]
  for name,cc,lat,lon,tz in cities:
   started=time.monotonic()
   page.evaluate('''o=>{document.getElementById('when').value='fortnight';document.getElementById('radius').value='8';document.getElementById('q').value=o.name;window.__auditDone=false;runSearch(o).finally(()=>window.__auditDone=true)}''',{'name':name,'city':name,'cc':cc,'country':cc,'lat':lat,'lon':lon,'timeZone':tz})
   page.wait_for_function('window.__auditDone===true',timeout=30000);page.wait_for_timeout(700)
   data=read();data['elapsedMs']=round((time.monotonic()-started)*1000);searches.append(data)
   check(f'{width} {name} actual runtime source occurrences',data['state']['count'],8)
   check(f'{width} {name} no old-city rows',all(name in r['title'] for r in data['recovery']['observations']))
   check(f'{width} {name} filtered events kept',data['recovery']['counts']['filteredOccurrences'],8)
   check(f'{width} {name} no visible technical panels',data['visibleTechnical'],[])
   check(f'{width} {name} controls fit',data['clippedControls'],[])
  page.screenshot(path=str(args.output/f'{width}-{scheme}-results.png'))
  # Actual customer button, not a direct dialog function call.
  page.locator('#grid .tf-butler').first.click();page.wait_for_timeout(250)
  check(f'{width} details action opens factual native dialog',page.locator('#r91Event').evaluate('(e)=>e.open'))
  detailText=page.locator('#r91Event').inner_text()
  check(f'{width} details retain source link',page.locator('#r91Event a').first.get_attribute('href').startswith('https://fixture.example/'))
  check(f'{width} details do not invent amenities',not any(x in detailText.lower() for x in ['bar during','doors close','built for live music','20 min early']))
  check(f'{width} detail source observation disclosed','Source observation' in detailText or 'observation time unavailable' in detailText)
  page.screenshot(path=str(args.output/f'{width}-{scheme}-detail.png'))
  check(f'{width} detail controls fit',read()['clippedControls'],[])
  page.keyboard.press('Escape');check(f'{width} details Escape restores focus',page.evaluate("document.activeElement.classList.contains('tf-butler')"))
  # Vertical scrolling must remain available without an automatic jump on repaint.
  page.evaluate('window.scrollTo(0,600)');page.wait_for_timeout(100);y=page.evaluate('scrollY')
  page.evaluate("dispatchEvent(new Event('tf:coverage-finished'))");page.wait_for_timeout(400)
  check(f'{width} scrolling survives status repaint',abs(page.evaluate('scrollY')-y)<3)
  page.evaluate('window.scrollTo(0,0)')
  page.locator('#r91FilterCount').click();page.wait_for_timeout(250);filters=read();page.screenshot(path=str(args.output/f'{width}-{scheme}-filters.png'))
  check(f'{width} filters open',page.locator('#r91Filters').evaluate('(e)=>e.open'))
  check(f'{width} filter controls accessible without horizontal scrolling',filters['clippedControls'],[])
  page.keyboard.press('Escape');check(f'{width} Escape returns filter focus',page.evaluate("document.activeElement.id"),'r91FilterCount')
  page.locator('#r91Menu').click();page.wait_for_timeout(100)
  check(f'{width} Ticketcorner subscription official link',page.locator('#r91Ticketcorner a').get_attribute('href'),'https://www.ticketcorner.ch/campaign/ticketcorner-newsletter/')
  page.keyboard.press('Escape')
  check(f'{width} no uncaught runtime errors',errors,[])
  saved={'width':width,'OS':scheme,'initial':initial,'searches':searches,'filter':filters,'errors':errors,'requests':calls}
  (args.output/f'{width}-{scheme}.json').write_text(json.dumps(saved,indent=2,ensure_ascii=False,default=str));summary['screens'].append({'width':width,'os':scheme,'errors':errors,'syntheticSearches':len(searches)})
  print(width,scheme,'events',[x['state']['count'] for x in searches],'errors',errors[:2],flush=True);ctx.close()
 browser.close()
summary['passed']=sum(x['pass'] for x in summary['assertions']);summary['failed']=len(summary['assertions'])-summary['passed'];(args.output/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False));print(summary['passed'],summary['failed']);sys.exit(bool(summary['failed']))
