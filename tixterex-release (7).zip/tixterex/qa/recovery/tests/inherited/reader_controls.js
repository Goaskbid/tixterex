async () => {
 const tests=[],evidence={},originalFetch=window.fetch,originalShipped=TFDeep.memory.shipped;
 const check=(id,name,actual,expected)=>tests.push({id,name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
 const q={lat:47.3769,lon:8.5417,radiusKm:10,timeZone:'Europe/Zurich',window:{startDate:'2026-11-24',endDate:'2026-12-07',start:'2026-11-23T23:00:00Z',end:'2026-12-07T23:00:00Z'},cc:'CH',doorsOnly:true};
 async function fixture(totalPages,venueCount,itemsPerPage,slices){
  localStorage.clear();TFDeep.cursor.clear();let calls=[];const seen=new Set();
  const venues=Array.from({length:venueCount},(_,i)=>({id:'control-'+i,name:'Control Hall',lat:q.lat,lon:q.lon,kind:'theatre',km:0,origin:'https://control-'+i+'.example',website:'https://control-'+i+'.example/programme',door:'localist'}));
  TFDeep.memory.shipped=async()=>[];for(const v of venues)TFDeep.memory.mark(v.origin,'localist',true,1,v);
  TFDeep._venues={key:q.lat.toFixed(3)+','+q.lon.toFixed(3)+','+q.radiusKm,list:venues};
  window.fetch=async input=>{const url=new URL(String(input));calls.push(url.href);const page=+url.searchParams.get('page');return new Response(JSON.stringify({events:Array.from({length:itemsPerPage},(_,i)=>{const id=(page-1)*itemsPerPage+i;return {event:{id,title:'Control '+url.hostname+' '+id,timezone:q.timeZone,location_name:'Control Hall',geo:{latitude:q.lat,longitude:q.lon},localist_url:url.origin+'/event/'+id,event_instances:[{event_instance:{id,start:'2026-11-24T20:00:00+01:00',all_day:false}}]}}}),page:{current:page,total:totalPages}}));};
  const rounds=[];
  for(let i=0;i<slices;i++){const before=calls.length;await TFDeep.run(q,rows=>rows.forEach(r=>seen.add(r.id)),()=>{},new AbortController().signal);rounds.push({requests:calls.length-before,unique:seen.size,pending:TFDeep.stats.pending||0,pages:calls.slice(before).map(u=>+new URL(u).searchParams.get('page'))})}
  return {unique:seen.size,requests:calls.length,rounds};
 }
 try {
  evidence.sevenPages=await fixture(7,1,50,1);check('C01','Direct reader recovers seven-page programme',evidence.sevenPages.unique,350);
  evidence.thirteenPages=await fixture(13,1,50,2);check('C02','Direct reader resumes page 13 when explicitly called again',evidence.thirteenPages.unique,650);
  evidence.budget=await fixture(12,60,1,1);check('C03','Single deep work slice dispatches at most 600 calendar requests',evidence.budget.requests<=600,true);
 } finally {window.fetch=originalFetch;TFDeep.memory.shipped=originalShipped;}
 return {kind:'positive controls; direct-reader calls are not scheduler or live-recall proof',tests,passed:tests.filter(t=>t.pass).length,failed:tests.filter(t=>!t.pass).length,evidence};
}
