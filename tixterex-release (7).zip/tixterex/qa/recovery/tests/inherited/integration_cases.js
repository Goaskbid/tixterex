async()=>{
 const tests=[],evidence={};const check=(id,name,actual,expected=true)=>tests.push({id,name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
 const windowScope={startDate:'2026-11-24',endDate:'2026-12-07',start:'2026-11-23T23:00:00Z',end:'2026-12-07T23:00:00Z'};
 const src={id:'fixture-ical',adapter:'ical',name:'Fixture calendar',timeZone:'Europe/Zurich',endpoint:'https://fixture.example/feed.ics',licence:'CC0',cacheSeconds:300};
 const ics=body=>'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nUID:fixture\r\nSUMMARY:Fixture\r\nLOCATION:Fixture Hall\r\nGEO:47.3769;8.5417\r\n'+body+'\r\nEND:VEVENT\r\nEND:VCALENDAR';
 const rows=(body)=>TixTerexBrowserAdapters.mapRows(ics(body),src,{},windowScope);
 let r=rows('DTSTART;TZID=Europe/Zurich:20261124T200000\r\nRRULE:FREQ=WEEKLY;COUNT=3\r\nEXDATE:20261201T190000Z');
 evidence.modernExdate=r;check('I01','Reviewed browser calendar removes equivalent UTC exclusion',r.nodes.length,1); // Nov24 and Dec1 only in this 14-day window, Dec1 excluded
 r=rows('DTSTART;TZID=Europe/Zurich:20200107T200000\r\nRRULE:FREQ=WEEKLY');evidence.modernOldSeries=r;
 check('I02','Reviewed browser calendar expands long-lived weekly series into current window',r.nodes.length,2);
 r=rows('DTSTART:20261124T190000Z\r\nDURATION:PT2H');evidence.modernDuration=r;
 check('I03','Unsupported calendar duration is explicitly reported by reviewed reader',r.issues.some(v=>/DURATION/.test(v)));
 check('I04','Reviewed browser calendar retains published GEO',r.nodes[0].node.location.geo.latitude,'47.3769');
 const loc={id:1,title:'Fixture',status:'canceled',geo:{latitude:47.3769,longitude:8.5417},location_name:'Hall',localist_url:'https://fixture.example/event',event_instances:[{event_instance:{id:2,start:'2026-11-24T20:00:00'}}]};
 r=TixTerexBrowserAdapters.mapRows({events:[{event:loc}]},{...src,adapter:'localist'});
 evidence.modernCancellation=r;check('I05','Reviewed Localist mapping carries status=canceled',String(r.nodes[0]?.node.eventStatus).includes('Cancelled'));
 // Does a coverage proxy depend on an independently counted event denominator?
 const oldSession=TixTerexAudit.getSession,oldPopulation=TFMeter.population;const fake={id:'fixture-meter',status:'done',rows:new Map(Array.from({length:20},(_,i)=>[String(i),{id:String(i),title:'Fixture '+i,sourceId:'fixture',source:'Fixture',venue:'Hall',start:'2026-11-24T20:00:00Z',lat:47.3769,lon:8.5417}]))};
 state.loc={lat:47.3769,lon:8.5417,name:'Fixture'};state.cc='CH';state.window=windowScope;state.filters.radius=100;
 TixTerexAudit.getSession=()=>fake;TFMeter.population=async()=>({pop:1000,places:1});TFMeter._last=null;
 await TFMeter.render();const node=document.getElementById('tfComplete');evidence.meter={text:node?.textContent,pct:node?.dataset.pct,found:node?.dataset.found};
 check('I06','Unmeasured search does not display a completeness percentage',!node?.dataset.pct);
 TixTerexAudit.getSession=oldSession;TFMeter.population=oldPopulation;
 // Built-in regression checker must return a report, not abort on a failed fixture.
 try{evidence.selfTest=await TF.selfTest();check('I07','Built-in self-test produces a result without throwing',true)}catch(e){evidence.selfTestError={message:e.message,stack:e.stack};check('I07','Built-in self-test produces a result without throwing',false)}
 const orig={post:TFPush.post,live:TFPush.live,supported:TFPush.supported,place:TFPush.place,key:TFPush.key};let unsub=false;
 try{TFPush.post=async()=>false;TFPush.live=()=>true;TFPush.supported=()=>true;TFPush.place=()=>({name:'Fixture',lat:47.37,lon:8.54});TFPush.key=()=> 'A'.repeat(87);Object.defineProperty(window,'Notification',{configurable:true,value:{requestPermission:async()=> 'granted'}});Object.defineProperty(navigator,'serviceWorker',{configurable:true,value:{ready:Promise.resolve({pushManager:{getSubscription:async()=>({endpoint:'https://push.example/fixture',getKey:n=>new Uint8Array(n==='auth'?16:65).buffer,unsubscribe:async()=>{unsub=true;return true}})}})}});const response=await TFPush.enable();evidence.pushFailed={response,on:TFPush.on(),unsubscribed:unsub};check('I08','Failed push registration keeps alerts off and revokes subscription',response==='failed'&&!TFPush.on()&&unsub)}finally{Object.assign(TFPush,orig)}
 evidence.unicodeFollowCandidates=TFPush.candidates({artist:'\u5b87\u591a\u7530\u30d2\u30ab\u30eb',venue:'\u6771\u4eac\u4f1a\u9928'});
 check('I09','Published Japanese artist can be offered as a follow target',evidence.unicodeFollowCandidates.length>0);
 return {kind:'cross-module integration and modern/legacy calendar distinction',tests,passed:tests.filter(t=>t.pass).length,failed:tests.filter(t=>!t.pass).length,evidence};
}
