async () => {
 const tests=[],observations={};
 const check=(id,name,actual,expected=true)=>{tests.push({id,name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});};
 const run=(id,name,fn,expected=true)=>{try{check(id,name,fn(),expected)}catch(e){tests.push({id,name,pass:false,error:e.message,expected})}};
 const q={lat:47.3769,lon:8.5417,radiusKm:10,timeZone:'Europe/Zurich',window:{startDate:'2026-11-24',endDate:'2026-12-07',start:'2026-11-23T23:00:00Z',end:'2026-12-07T23:00:00Z'},cc:'CH',doorsOnly:true};
 const v={id:'fixture-hall',name:'Fixture Hall',lat:q.lat,lon:q.lon,kind:'theatre',website:'https://venue.example/programme',origin:'https://venue.example',km:0,door:'localist'};
 const base={id:1,title:'Fixture performance',location_name:v.name,geo:{latitude:v.lat,longitude:v.lon},timezone:'Europe/Zurich',localist_url:'https://venue.example/event/1',event_instances:[{event_instance:{id:100,start:'2026-11-24T20:00:00',all_day:false}}]};
 const lc=(e=base)=>TFDeep.fromLocalist({events:[{event:e}]},v,q);
 const wp=(e={})=>TFDeep.fromTribe({events:[{id:1,title:'Fixture performance',utc_start_date:'2026-11-24 19:00:00',start_date:'2026-11-24 20:00:00',timezone:'Europe/Zurich',venue:{venue:v.name},url:'https://venue.example/event/1',...e}]},v,q);
 const raw={title:'Fixture performance',start:'2026-11-24T19:00:00Z',venue:v.name,lat:v.lat,lon:v.lon,url:'https://venue.example/event/1',sourceUrl:'https://venue.example/event/1'};
 const card=(e={})=>TFDeep.card({...raw,...e},q);
 run('P01','Localist source clock resolves to 19:00 UTC',()=>lc()[0]?.start,'2026-11-24T19:00:00.000Z');
 run('P02','Localist inclusive selected end translated to exclusive API end',()=>new URL(TFDeep.doors.localist(v.origin,q.window,1)).searchParams.get('end'),'2026-12-08');
 run('P03','Localist cancellation survives adapter',()=>lc({...base,eventStatus:'EventCancelled',status:'canceled',event_instances:[{event_instance:{...base.event_instances[0].event_instance,cancelled:true,status:'canceled'}}]})[0]?.cancelled===true);
 observations.unspecifiedWordPressCancellationFields=wp({event_status:'canceled',status:'canceled',cancelled:true})[0]?.cancelled===true;
 run('P05','Localist string false remains timed',()=>lc({...base,event_instances:[{event_instance:{...base.event_instances[0].event_instance,all_day:'false'}}]})[0]?.dateOnly,false);
 run('P06','WordPress free numeric price survives',()=>wp({cost:0})[0]?.price,0);
 run('P07','Deep card rejects out-of-range but periodic longitude',()=>card({lon:v.lon+360})===null);
 run('P08','Deep card rejects null coordinate',()=>card({lat:null})===null);
 run('P09','Deep card rejects impossible date rather than normalizing it',()=>TFDeep.zoned('2026-02-30T20:00:00','Europe/Zurich'),null);
 run('P10','Deep card flags invalid timezone instead of silently using UTC',()=>TFDeep.zoned('2026-11-24T20:00:00','Not/A_TimeZone'),null);
 run('P11','DST gap interpretation agrees with RFC 5545 pre-gap offset for this fixture',()=>TFDeep.zoned('2026-03-29T02:30:00','Europe/Zurich'),'2026-03-29T01:30:00.000Z');
 run('P12','Valid Kathmandu offset works',()=>TFDeep.zoned('2026-11-24T20:00:00','Asia/Kathmandu'),'2026-11-24T14:15:00.000Z');
 run('P13','Direct card carries subtitle distinction',()=>card({subtitles:'fr'}).subtitles==='fr'||card({subtitles:'fr'}).subtitleLanguage==='fr');
 const a=lc({...base,language:'en'})[0],bb=lc({...base,id:2,language:'de',event_instances:[{event_instance:{...base.event_instances[0].event_instance,id:101}}]})[0];
 observations.languagePair=[a,bb];
 run('P14','Different language performances remain two after complete dedupe',()=>TF.dedupe([a,bb]).length,2);
 run('P15','Different format performances remain two after complete dedupe',()=>TF.dedupe([lc({...base,format:'2D'})[0],lc({...base,id:2,format:'3D',event_instances:[{event_instance:{...base.event_instances[0].event_instance,id:101}}]})[0]]).length,2);
 run('P16','Different room performances remain two after complete dedupe',()=>TF.dedupe([lc({...base,room:'A'})[0],lc({...base,id:2,room:'B',event_instances:[{event_instance:{...base.event_instances[0].event_instance,id:101}}]})[0]]).length,2);
 run('P17','Japanese events have different deep occurrence IDs',()=>card({title:'\u6625\u306e\u97f3\u697d\u4f1a',venue:'\u6771\u4eac\u4f1a\u9928'}).id!==card({title:'\u79cb\u306e\u6f14\u5287',venue:'\u6771\u4eac\u4f1a\u9928'}).id);
 run('P18','Distinct Japanese venue names are not treated as equal',()=>TFDeep.sameVenue('\u6771\u4eac\u4f1a\u9928','\u5927\u962a\u4f1a\u9928'),false);
 run('P19','Distinct Russian event names have different deep occurrence IDs',()=>card({title:'\u041a\u043e\u043d\u0446\u0435\u0440\u0442',venue:'\u0414\u043e\u043c \u043a\u0443\u043b\u044c\u0442\u0443\u0440\u044b'}).id!==card({title:'\u041b\u0435\u043a\u0446\u0438\u044f',venue:'\u0414\u043e\u043c \u043a\u0443\u043b\u044c\u0442\u0443\u0440\u044b'}).id);
 run('P20','Base Unicode normalizer retains Japanese',()=>TF.norm('\u6771\u4eac\u4f1a\u9928'),'\u6771\u4eac\u4f1a\u9928');
 run('P21','Ingest observedUnknown retained through hydration',()=>{
  const r=TFIngest.cards([{city:{tz:q.timeZone},venues:[{id:'v',name:v.name,lat:v.lat,lon:v.lon,site:v.origin}],events:{v:[raw]}}],q)[0];
  const h=TixTerexAudit.hydrate(r);observations.unknownVenue={raw:r,hydrated:h}; return h.observedAt===null&&h.observationUnknown===true;
 });
 run('P22','Ingest feed without observation does not invent current time',()=>{
  const r=TFIngest.cards([{city:{tz:q.timeZone},venues:[],feeds:{tm:{name:'Ticketmaster'}},events:{tm:[raw]}}],q)[0];
  observations.unknownFeed=r;return r.observedAt==null;
 });
 run('P23','ISO observation timestamp is accepted by saved reader',()=>TFIngest.seenAt('2026-11-12T12:00:00Z'),'2026-11-12T12:00:00.000Z');
 run('P24','Old saved observation is not reset',()=>TFIngest.cards([{city:{tz:q.timeZone},at:Date.parse('2026-11-12T12:00:00Z'),venues:[{id:'v',name:v.name,lat:v.lat,lon:v.lon,site:v.origin}],events:{v:[raw]}}],q)[0].observedAt,'2026-11-12T12:00:00.000Z');
 run('P25','Saved calendar dateOnly string false is not all-day',()=>TFIngest.cards([{city:{tz:q.timeZone},at:Date.parse('2026-11-12T12:00:00Z'),venues:[{id:'v',name:v.name,lat:v.lat,lon:v.lon,site:v.origin}],events:{v:[{...raw,dateOnly:'false'}]}}],q)[0].dateOnly,false);
 const meta={pageUrl:'https://venue.example/calendar.ics',sourceId:'fixture',label:'Fixture',venueName:v.name,lat:v.lat,lon:v.lon,geoApprox:false,timeZone:q.timeZone,observedAt:'2026-11-24T08:00:00Z'};
 const ics=(body)=>'BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VEVENT\r\nUID:fixture\r\nSUMMARY:Fixture\r\n'+body+'\r\nEND:VEVENT\r\nEND:VCALENDAR';
 const parse=(body,m=meta)=>TF.parseICS(ics(body),m);
 run('P26','EXDATE in same timezone removes intended occurrence',()=>parse('DTSTART;TZID=Europe/Zurich:20261124T200000\r\nRRULE:FREQ=WEEKLY;COUNT=3\r\nEXDATE;TZID=Europe/Zurich:20261201T200000').length,2);
 run('P27','EXDATE equivalent UTC instant removes local occurrence',()=>parse('DTSTART;TZID=Europe/Zurich:20261124T200000\r\nRRULE:FREQ=WEEKLY;COUNT=3\r\nEXDATE:20261201T190000Z').length,2);
 run('P28','Calendar GEO supplies authoritative point',()=>parse('DTSTART:20261124T190000Z\r\nGEO:47.3769;8.5417',{...meta,lat:undefined,lon:undefined,geoApprox:undefined})[0]?.lat,47.3769);
 run('P29','Calendar DURATION gives published finish',()=>parse('DTSTART:20261124T190000Z\r\nDURATION:PT2H')[0]?.end?.toISOString(),'2026-11-24T21:00:00.000Z');
 run('P30','Long-lived weekly series reaches November 2026 search window',()=>parse('DTSTART;TZID=Europe/Zurich:20200107T200000\r\nRRULE:FREQ=WEEKLY',{...meta,window:q.window}).some(r=>r.start>=new Date(q.window.start)&&r.start<new Date(q.window.end)));
 run('P31','Calendar cancellation is retained',()=>parse('DTSTART:20261124T190000Z\r\nSTATUS:CANCELLED')[0]?.cancelled,true);
 run('P32','Missing event title is rejected',()=>card({title:''})===null);
 run('P33','Unsafe URL removed by final hydration',()=>TixTerexAudit.hydrate({...raw,url:'javascript:alert(1)'}).url,null);
 run('P34','Untrusted upstream ID sanitized',()=>/^[A-Za-z0-9_.:|\-]+$/.test(TixTerexAudit.hydrate({...raw,id:'x" onfocus="alert(1)'}).id));
 run('P35','Noncommercial licence rejected on allowed government host',()=>TFPolicy.admit({...raw,sourceUrl:'https://data.bs.ch/event/x',licence:'CC BY-NC 4.0',description:'not allowed for commercial reuse'})===false);
 run('P36','Explicit publisher opt-out rejects calendar',()=>{TFPolicy.optout.add('optout.example');return TFPolicy.admit({...raw,sourceUrl:'https://optout.example/event/x'})},false);
 run('P37','Facts-only admission scrubs body and poster',()=>{const r={...raw,description:'licensed words',image:'https://venue.example/a.jpg'};TFPolicy.admit(r);return !r.description&&!r.image});
 run('P38','Source-private contentURL image is scrubbed in facts-only record',()=>{const r={...raw,licence:'facts only',pubImg:'https://venue.example/photo.jpg'};TFPolicy.admit(r);observations.factsPubImg=r;return !r.pubImg});
 observations.sourceGraphEmbedded=!!window.TixTerexSourceGraph||!!document.getElementById('tf-sourcegraph');
 run('P40','Import preserves leading digit in artist name',()=>TTImport.parse('50 Cent\n2Pac').map(r=>r.name),['50 Cent','2Pac']);
 run('P41','Music import supports followed artists JSON list',()=>TTImport.parse(JSON.stringify({artists:[{name:'Artist Alpha'},{name:'Artist Beta'}]})).map(r=>r.name),['Artist Alpha','Artist Beta']);
 run('P42','Plain artist list imports Unicode',()=>TTImport.parse('\u5b87\u591a\u7530\u30d2\u30ab\u30eb\n\u041c\u0435\u043b\u044c\u043d\u0438\u0446\u0430').map(r=>r.name),['\u5b87\u591a\u7530\u30d2\u30ab\u30eb','\u041c\u0435\u043b\u044c\u043d\u0438\u0446\u0430']);
 run('P43','Japanese follow is accepted',()=>TFPeers.addFollow('\u5b87\u591a\u7530\u30d2\u30ab\u30eb'));
 run('P44','Still-time list excludes unresolved event time',()=>{
  state.events=[{...raw,id:'unresolved-time',start:new Date('2026-11-24T10:00:00Z'),km:1,timeUnresolved:true,timeZone:q.timeZone}];const original=window.filteredEvents;window.filteredEvents=()=>state.events;
  try{return TTMore.reach().length}finally{window.filteredEvents=original}
 },0);
 run('P45','Facts card preserves explicit cancelled status',()=>card({cancelled:true,eventStatus:'EventCancelled'})?.cancelled===true);
 run('P46','Deep request cap stays at existing 600',()=>TFDeep.reqCap(),600);
 run('P47','80 percent proxy does not terminate digging',()=>TFDig.decide(80,0,0,0,true),null);
 run('P48','Dry rounds do not terminate with remaining sources',()=>TFDig.decide(null,0,2,20,true),null);
 run('P49','Core matcher distinguishes audioLanguage',()=>TixTerexRecall.sameOccurrence({...raw,audioLanguage:'en'},{...raw,audioLanguage:'de'}),false);
 observations.directionalGroundTruthMatching={unlabelledTruth:TixTerexRecall.sameOccurrence(raw,{...raw,language:'de'}),labelledTruth:TixTerexRecall.sameOccurrence({...raw,language:'de'},raw)};
 // Unknown timestamp handling in current build is legitimate. Never require dropping
 // a record merely because an older audit asserted that as the only acceptable fix.
 return {kind:'controlled final-runtime function tests',clock:'2026-11-24T09:00:00Z',tests,passed:tests.filter(t=>t.pass).length,failed:tests.filter(t=>!t.pass).length,observations};
}
