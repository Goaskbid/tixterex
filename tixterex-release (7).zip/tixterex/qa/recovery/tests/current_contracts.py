from pathlib import Path
import argparse,json
from playwright.sync_api import sync_playwright
from local_harness import load
p=argparse.ArgumentParser();p.add_argument('--site',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--case',type=Path,default=Path(__file__).with_suffix('.js'));a=p.parse_args()
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);c=b.new_context();page,errors,calls=load(c,a.site,timers=False);r=page.evaluate(a.case.read_text());r['pageErrors']=errors;a.output.write_text(json.dumps(r,indent=2));print(r['passed'],r['failed']);c.close();b.close()
