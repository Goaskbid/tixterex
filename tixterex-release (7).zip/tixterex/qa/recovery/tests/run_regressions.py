#!/usr/bin/env python3
"""Retain the supplied function/calendar tests without equating them to a live search audit."""
import sys,json,argparse,subprocess,tempfile
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
from local_harness import load
p=argparse.ArgumentParser();p.add_argument('--site',type=Path,required=True);p.add_argument('--cases',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);summary={}
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for name in ['pure_cases','integration_cases','reader_controls']:
  c=b.new_context(timezone_id='UTC');page,errors,calls=load(c,a.site,timers=False);page.clock.set_system_time('2026-11-24T09:00:00Z');r=page.evaluate((a.cases/(name+'.js')).read_text());r['pageErrors']=errors;(a.output/(name+'.json')).write_text(json.dumps(r,indent=2,ensure_ascii=False,default=str));summary[name]={'passed':r['passed'],'failed':r['failed'],'pageErrors':errors};print(name,summary[name],flush=True);c.close()
 b.close()
syntax=[]
with tempfile.TemporaryDirectory() as tmp:
 for i,sc in enumerate(BeautifulSoup((a.site/'index.html').read_text(),'html.parser').find_all('script')):
  if sc.get('src') or sc.get('type','').lower() not in ('','text/javascript','application/javascript','module'):continue
  code=sc.string or sc.get_text()
  if not code.strip():continue
  f=Path(tmp)/f'check-{i}.js';f.write_text(code);r=subprocess.run(['node','--check',str(f)],capture_output=True,text=True,timeout=10);syntax.append({'script':sc.get('id') or str(i),'pass':r.returncode==0,'error':r.stderr})
summary['syntax']={'checked':len(syntax),'failed':sum(not x['pass'] for x in syntax)};(a.output/'syntax.json').write_text(json.dumps(syntax,indent=2));(a.output/'summary.json').write_text(json.dumps(summary,indent=2));print(summary['syntax'])
