#!/usr/bin/env python3
import sys,json,tempfile,shutil,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'patch/tools'));from stamp_build import stamp
checks=[]
def check(name,actual,expected=True):checks.append({'name':name,'actual':actual,'expected':expected,'pass':actual==expected})
with tempfile.TemporaryDirectory() as t:
 site=Path(t)
 for n in ['index.html','sw.js','version.json']:shutil.copy(ROOT/'patch/website'/n,site/n)
 stamp(site,'release-20261124-reviewed');s=(site/'index.html').read_text();sw=(site/'sw.js').read_text()
 check('HTML build stamped','content="release-20261124-reviewed"' in s);check('Worker build stamped',"const BUILD='release-20261124-reviewed';" in sw);check('Version build stamped',json.loads((site/'version.json').read_text())['build'],'release-20261124-reviewed')
 before={n:(site/n).read_bytes() for n in ['index.html','sw.js','version.json']};stamp(site,'release-20261124-reviewed');check('Stamping idempotent',all(before[n]==(site/n).read_bytes() for n in before))
 try:stamp(site,"x';alert(1)");bad=False
 except ValueError:bad=True
 check('Reject unsafe build identifier',bad)
result={'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'tests':checks};(ROOT/'evidence/tools_tests.json').write_text(json.dumps(result,indent=2));print(result['passed'],result['failed'])
