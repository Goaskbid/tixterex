#!/usr/bin/env python3
from pathlib import Path
import sys,json,time,argparse
from playwright.sync_api import sync_playwright
from local_harness import load
from fixtures import fixtures as base_fixtures, response
mode={"fail":False,"delay":False}
def fixtures(url):
 if "eventsimple.de/api/events" in url and mode["fail"]:return response({"error":"controlled upstream failure"},503)
 value=base_fixtures(url)
 if value and mode["delay"] and "eventsimple.de/api/events" in url and "46.22" in url:value["delayMs"]=700
 return value
p=argparse.ArgumentParser();p.add_argument('--site',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.parent.mkdir(parents=True,exist_ok=True)
tests=[];debug={}
def ck(name,actual,expected=True):print('CHECK',name,actual,flush=True);tests.append({'name':name,'actual':actual,'expected':expected,'pass':actual==expected})
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,color_scheme='dark',timezone_id='Europe/Zurich');page,errors,calls=load(c,a.site,fixtures=fixtures)
 print('LOADED',flush=True);page.set_default_timeout(5000);page.locator('#q').fill('Geneva, CH');print('TYPED',flush=True);page.wait_for_timeout(1200)
 debug['suggestions']=page.evaluate("[...document.querySelectorAll('.geo-suggest button')].map(e=>e.textContent)")
 print('SUGGESTIONS',debug['suggestions'],flush=True);page.locator('#btnGo').click();print('CLICKED FIND',flush=True);page.wait_for_function("typeof state!=='undefined'&&state.events.length===8&&!state.searching",timeout=30000);page.wait_for_timeout(400)
 ck('Typed Geneva plus Find uses stored place directory',page.evaluate("state.cc==='CH'&&state.loc.lat>46&&state.loc.lat<47"))
 ck('Typed search renders all eight fixture results',page.locator('#grid article.tix').count(),8)
 # Saved list and detail actions must retain a path back to the regular results.
 page.locator('#grid .tf-save').first.click();page.wait_for_timeout(150);page.locator('#r91Saved').click();page.wait_for_timeout(250)
 ck('Saved view contains saved occurrence',page.locator('#grid article.tix').count(),1)
 page.locator('#r91Saved').click();page.wait_for_timeout(250);ck('Leaving saved view restores results',page.locator('#grid article.tix').count(),8)
 # Force a scope-specific temporary upstream failure at a new location so no prior cached response masks it.
 mode["fail"]=True
 page.evaluate("""()=>{window.__done=false;runSearch({name:'Berlin',city:'Berlin',cc:'DE',country:'DE',lat:52.52,lon:13.405,timeZone:'Europe/Berlin'}).finally(()=>__done=true)}""")
 page.wait_for_function('__done',timeout=30000);page.wait_for_timeout(500);debug['failure']=page.evaluate('TTRecovery.receipt()');debug['failureText']=page.locator('#r91ResultSummary').inner_text()
 ck('Upstream failure does not retain old-city events',page.evaluate('state.events.length'),0)
 ck('Upstream failure is not labelled full local absence','no events exist' not in debug['failureText'].lower())
 ck('Retry control remains available',page.locator('#r91Retry').is_visible())
 print('START RETRY',flush=True);mode["fail"]=False;page.clock.set_system_time('2026-11-24T18:05:00Z');page.locator('#r91Retry').click();page.wait_for_function('state.events.length===8',timeout=30000);page.wait_for_timeout(350)
 ck('Healthy retry produces Berlin fixture events without page reload',page.evaluate("state.events.every(e=>e.title.startsWith('Berlin'))"))
 # Geography switch with deliberately late superseded source response.
 mode["delay"]=True
 page.evaluate("""()=>{runSearch({name:'Geneva slow',city:'Geneva slow',cc:'CH',country:'CH',lat:46.22,lon:6.15,timeZone:'Europe/Zurich'});setTimeout(()=>runSearch({name:'Paris',city:'Paris',cc:'FR',country:'FR',lat:48.8566,lon:2.3522,timeZone:'Europe/Paris'}),100)}""")
 page.wait_for_function("state.events.length===8&&state.events.every(e=>e.title.startsWith('Paris'))",timeout=30000);page.wait_for_timeout(1500)
 ck('Late superseded city cannot contaminate current results',page.evaluate("state.events.every(e=>e.title.startsWith('Paris'))"));ck('No uncaught journey errors',errors,[])
 debug['final']=page.evaluate('TTRecovery.receipt()');debug['requests']=calls;c.close();b.close()
r={'basis':'Actual customer controls plus real runtime, offline synthetic providers. Network/CORS not certified.','passed':sum(t['pass'] for t in tests),'failed':sum(not t['pass'] for t in tests),'tests':tests,'evidence':debug};a.output.write_text(json.dumps(r,indent=2,ensure_ascii=False,default=str));print(r['passed'],r['failed']);raise SystemExit(bool(r['failed']))
