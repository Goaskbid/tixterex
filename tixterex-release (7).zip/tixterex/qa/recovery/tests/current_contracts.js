async()=>{
 const tests=[];const check=(name,actual,expected=true)=>tests.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
 const q={lat:47.3769,lon:8.5417,radiusKm:10,timeZone:'Europe/Zurich',window:{startDate:'2026-11-24',endDate:'2026-12-07',start:'2026-11-23T23:00:00Z',end:'2026-12-07T23:00:00Z'}};
 const row={title:'Published performance',start:'2026-11-25T19:00:00Z',venue:'Hall',lat:q.lat,lon:q.lon,url:'https://fixture.example/event'};
 const snapshot=Date.parse('2026-11-12T12:00:00Z');const c=TFIngest.cards([{city:{tz:q.timeZone},at:snapshot,venues:[{id:'v',name:'Hall',lat:q.lat,lon:q.lon,site:'https://fixture.example'}],events:{v:[row]}}],q)[0];
 check('City snapshot time is not publisher observation',c.observedAt,null);check('Old snapshot timestamp retained separately',c.snapshotAt,'2026-11-12T12:00:00.000Z');
 const g=TFIngest.cards([{city:{tz:q.timeZone},at:Date.now(),venues:[{id:'v',name:'Hall',lat:q.lat,lon:q.lon,site:'https://fixture.example',read:Date.now(),good:snapshot}],events:{v:[row]}}],q)[0];check('Last good publisher observation beats later failed attempt',g.observedAt,'2026-11-12T12:00:00.000Z');
 const rows=Array.from({length:4},(_,i)=>({...row,title:'Independent programme '+i,id:'p'+i}));check('Four simultaneous distinct titles stay four',TTTidy.tidy(rows).length,4);
 check('Normal source discovery disables broad catalogue research',TTSourceMode.catalogueResearch,false);
 const before=JSON.stringify(TTTidy.tidy(rows).map(e=>e.id));check('Non-destructive tidy keeps occurrence IDs',before,JSON.stringify(rows.map(e=>e.id)));
 return {basis:'Recovery contracts, including stricter observation semantics than legacy P24.',tests,passed:tests.filter(x=>x.pass).length,failed:tests.filter(x=>!x.pass).length};
}
