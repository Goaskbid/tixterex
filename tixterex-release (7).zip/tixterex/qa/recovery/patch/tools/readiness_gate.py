#!/usr/bin/env python3
"""Check deployability separately from supply and the unmeasured 100/75 claim."""
from pathlib import Path
import json,re,argparse,hashlib

def assess(site):
 rows=[]
 def add(id,ok,detail,scope='package'):rows.append({'id':id,'pass':bool(ok),'detail':detail,'scope':scope})
 def data(path,default=None):
  try:return json.loads((site/path).read_text())
  except (ValueError,OSError):return default
 html=(site/'index.html').read_text() if (site/'index.html').exists() else ''
 add('INDEX_PRESENT',bool(html),'Main HTML exists')
 m=re.search(r'<meta name="tf-build" content="([^"]+)"',html);build=m[1] if m else None
 sw=(site/'sw.js').read_text() if (site/'sw.js').exists() else ''
 m=re.search(r"const BUILD='([^']+)'",sw);swbuild=m[1] if m else None;version=data('version.json',{}).get('build')
 add('BUILD_ALIGNMENT',bool(build and build==swbuild==version),{'html':build,'sw':swbuild,'version':version})
 places=data('data/places.json',{});refs=set(places.get('parts',{}).values())|{x['url'] for x in places.get('spatial',[]) if 'url' in x}
 missing=sorted(x for x in refs if not (site/'data'/x).is_file());add('PLACE_FILES_COMPLETE',bool(refs) and not missing,{'referenced':len(refs),'missing':missing})
 ingest=data('data/ingest/index.json',{});cities=ingest.get('cities',[])
 add('COLLECTED_CITY_INVENTORY',any(int(x.get('events') or 0)>0 for x in cities),{'cities':len(cities),'eventCounts':sum(int(x.get('events') or 0) for x in cities)},'supply')
 # No estimates or UI fixture results substitute for independent benchmark evidence.
 add('100_75_MEASURED',False,'Not measured by this package gate. Submit independent per-city event ground truth and production-origin observations.','claim')
 return {'schema':'tixterex-readiness/1','packageReady':all(x['pass'] for x in rows if x['scope']=='package'),'supplyReady':all(x['pass'] for x in rows if x['scope']=='supply'),'claim10075Ready':False,'checks':rows,'indexSha256':hashlib.sha256(html.encode()).hexdigest()}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('site',type=Path);p.add_argument('--mode',choices=['package','supply','claim'],default='package');p.add_argument('--output',type=Path);a=p.parse_args();r=assess(a.site);txt=json.dumps(r,indent=2,ensure_ascii=False);print(txt)
 if a.output:a.output.write_text(txt)
 raise SystemExit(0 if r[{'package':'packageReady','supply':'supplyReady','claim':'claim10075Ready'}[a.mode]] else 1)
