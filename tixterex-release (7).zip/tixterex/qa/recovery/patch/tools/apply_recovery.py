#!/usr/bin/env python3
"""Apply reviewed compiled-module replacements to the exact uploaded A90 build.
Does not collect events, deploy, overwrite data, or alter credentials.
"""
from pathlib import Path
import argparse, hashlib, json, re, sys
HERE=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--site',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 source=args.site/'index.html';text=source.read_text();sha=hashlib.sha256(source.read_bytes()).hexdigest()
 expected=json.loads((HERE/'baseline.json').read_text())['index_sha256']
 if sha!=expected:raise SystemExit('Refusing a different compiled input. Rebase the named module changes, then rerun the tests. Expected '+expected)
 changes=[]
 def replace_module(id,code):
  nonlocal text
  pattern=r'(<script\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>)[\s\S]*?(</script>)'
  text,n=re.subn(pattern,lambda m:m[1]+code+m[2],text,count=1)
  if n!=1:raise ValueError('Expected one script '+id)
  changes.append(id)
 modules=HERE/'modules'
 for id in ['tt-a89-plants','tt-a79-intro','tf-a25-intro-boot','tt-a79-look','tt-a80-phone','tt-a80-pics']:
  replace_module(id,'/* Disabled by recovery: duplicate presentation / intro / auto-scroll / picture owner. */')
 replace_module('tf-a53-premium',(modules/'recovery-media.js').read_text())
 replace_module('tt-a84-tidy-js',(modules/'recovery-tidy.js').read_text())
 replace_module('tf-a30-dig',(modules/'recovery-discovery.js').read_text())
 # Remove the second autonomous venue-discovery controller; the replacement above is the sole owner.
 text,n=re.subn(r'<script>(?:(?!</script>)[\s\S])*?s\.id="tfDeep"(?:(?!</script>)[\s\S])*?</script>','<script>/* Autonomous legacy deep-search UI removed; r91 owns continuation. */</script>',text,count=1)
 changes.append('anonymous-deep-controller:'+str(n))
 # Programme-request claims occur immediately before dispatch, not after an asynchronous batch.
 def edit_module(id,fn):
  m=re.search(r'(<script\b[^>]*\bid="'+re.escape(id)+r'"[^>]*>)([\s\S]*?)(</script>)',text)
  if not m:raise ValueError(id)
  replace_module(id,fn(m[2]))
 def deep(code):
  code=code.replace('async function getJSON(e,r={},n){','async function getJSON(e,r={},n){if(t._budget&&!t._budget.take())throw Object.assign(new Error("Programme request budget paused"),{kind:"budget"});',1)
  code=code.replace('async function getText(e,r){','async function getText(e,r){if(t._budget&&!t._budget.take())throw Object.assign(new Error("Programme request budget paused"),{kind:"budget"});',1)
  code=code.replace('if(e.status===429||e.status>=500||e.name==="AbortError"||e.kind==="timeout")','if(e.kind==="budget"||e.status===429||e.status>=500||e.name==="AbortError"||e.kind==="timeout")',1)
  # Keep every mapped venue on a shared programme origin. Fetch once, parse against each known identity.
  old='for(const e of m.concat(i)){if(!e.origin||p.has(e.origin))continue;'
  new='const originVenues=new Map;for(const v of m.concat(i)){if(v.origin){if(!originVenues.has(v.origin))originVenues.set(v.origin,[]);if(!originVenues.get(v.origin).some(x=>t.sameVenue(x.name,v.name)))originVenues.get(v.origin).push(v)}}for(const e of m.concat(i)){if(!e.origin||p.has(e.origin))continue;'
  if old not in code:raise ValueError('Shared-origin rebase required')
  code=code.replace(old,new,1)
  old='n+=out(a==="tribe"?t.fromTribe(u,e,r):t.fromLocalist(u,e,r));'
  new='const mapped=new Map;for(const v of originVenues.get(e.origin)||[e])for(const row of(a==="tribe"?t.fromTribe(u,v,r):t.fromLocalist(u,v,r)))mapped.set(row.occurrenceId||row.id,row);n+=out([...mapped.values()]);'
  if old not in code:raise ValueError('Calendar mapping rebase required')
  return code.replace(old,new,1)
 edit_module('tf-browser-deep',deep)
 def atlas(code):
  # Screen at scheduling, not after spending a visitor's budget checking a dataset.
  old='if(!e?.key||!a.families[e.fam]||g.knownDatasets.includes(e.key))return;'
  new='if(!e?.key||!a.families[e.fam]||g.knownDatasets.includes(e.key))return;if(a.productionMode&&(!a.datasetGrant(e).ok||!near(e)))return;'
  if old not in code:raise ValueError('Atlas schedule rebase required')
  return code.replace(old,new,1)
 edit_module('tf-coverage-repair',atlas)
 # Preserve successful observation time, not the collector's latest failed attempt.
 def ingest(code):
  code=code.replace('t.seenAt(n.read||e.at)','t.seenAt(n.good||n.read)',2)
  code=code.replace('u.checkedAt=typeof n.read==="number"?n.read:e.at','u.checkedAt=typeof n.good==="number"?n.good:typeof n.read==="number"?n.read:null')
  code=code.replace('t.seenAt(n&&n.at||e.at)','t.seenAt(n&&n.at)',1)
  code=code.replace('if(u){u.licence="Facts only','if(u){u.snapshotAt=t.seenAt(e.at);u.observationBasis=u.observedAt?"venue_timestamp":"unknown_publisher_observation";u.licence="Facts only',1)
  old='if(u&&/cancel/i.test(String(c.status||"")))'
  code=code.replace(old,'if(u&&!t.seenAt(n&&n.at)){u.observedAt=null;u.observedUnknown=true}'+old,1)
  return code
 edit_module('tf-a36-ingest',ingest)
 # Image aliases must follow the same facts-only policy.
 edit_module('tf-a33-policy',lambda code:code.replace('thumbnailurl|img|imgs|gallery|media','thumbnailurl|pubImg|venueImg|img|imgs|gallery|media'))
 # No automatic population-derived completeness work or weather enrichment on every city change.
 edit_module('tf-a29-meter',lambda code:code.replace('setInterval((()=>{t.render().catch((()=>{}))}),1500)','/* Visitor completeness estimate disabled: no independent denominator. */')+';if(window.TFMeter)window.TFMeter.render=async function(){document.getElementById("tfComplete")?.remove();};')
 edit_module('tf-a44-overtake',lambda code:code.replace('t.loadWx().then(t.flagCards)','/* Weather is requested only from an explicit planning action. */'))
 # No automatic full-page reload while a person searches, scrolls, or opens an event.
 edit_module('tf-a43-follow',lambda code:code.replace('location.reload();return true','window.dispatchEvent(new CustomEvent("tf:update-available",{detail:{build:n.build}}));return true'))
 # Browser reference manifest is approved locally; generic catalogue research is operator-only.
 marker='<script id="tf-coverage-control">'
 text=text.replace(marker,'<script id="r91-source-mode">'+(modules/'recovery-atlas.js').read_text()+'</script>'+marker,1)
 text=text.replace('<html lang="en">','<html lang="en" class="r91" data-theme="light">',1)
 # Claims in structured data follow the same scope as the visitor interface.
 def structured(m):
  try: data=json.loads(m[2])
  except ValueError:return m[0]
  for item in data.get('@graph',[]):
   if item.get('@type')=='FAQPage':item['mainEntity']=[{'@type':'Question','name':'Where do events come from?','acceptedAnswer':{'@type':'Answer','text':'Connected publisher calendars and stored programmes. Coverage varies by place, category and date; verify changes and tickets on the linked event source.'}}]
  return m[1]+json.dumps(data,ensure_ascii=False,separators=(',',':'))+m[3]
 text=re.sub(r'(<script type="application/ld\+json">)([\s\S]*?)(</script>)',structured,text,count=1)

 text=re.sub(r'(<meta name="tf-build" content=")[^"]+',r'\g<1>r91-recovery-1',text,count=1)
 extra='<style id="r91-consumer-css">@layer tixRecovery {'+(modules/'recovery.css').read_text()+'}</style><script id="r91-links">'+(modules/'recovery-links.js').read_text()+'</script><script id="r91-consumer-ui">'+(modules/'recovery-ui.js').read_text()+'</script>'
 pos=text.rfind('</body>')
 if pos<0:raise ValueError('Missing document body close')
 text=text[:pos]+extra+text[pos:]
 out=args.output;out.mkdir(parents=True,exist_ok=True);(out/'index.html').write_text(text)
 (out/'sw.js').write_text((modules/'service-worker.js').read_text())
 (out/'version.json').write_text(json.dumps({'build':'r91-recovery-1'}))
 (out/'RECOVERY_BUILD.json').write_text(json.dumps({'schema':'tixterex-recovery-build/1','base_sha256':sha,'build':'r91-recovery-1','modulesChanged':changes,'scope':'Staging candidate; no new event inventory or live recall certification'},indent=2))
 print(json.dumps({'output':str(out),'indexBytes':len(text.encode()),'base_sha256':sha,'changes':changes},indent=2))
if __name__=='__main__':main()
