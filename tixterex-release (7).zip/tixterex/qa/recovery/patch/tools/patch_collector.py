#!/usr/bin/env python3
"""Targeted, checksum-guarded collector patch. Does not run collection or deploy."""
import argparse,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
def apply(src,out):
 raw=src.read_bytes();expected=json.loads((HERE/'baseline.json').read_text())['collector_sha256']
 if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Collector differs from audited input. Rebase explicitly.')
 text=raw.decode();changes=[
 ('catch(e){a=true}j.set(n,a);return a}', 'catch(e){return false}j.set(n,a);return a}'),
 ('lat:t.lat||e.lat,lon:t.lon||e.lon','lat:t.lat??e.lat,lon:t.lon??e.lon'),
 ('n.events[e]=n.events[e].filter((e=>H(e.start)))','n.events[e]=n.events[e].filter((e=>B(e.start,e.end)))'),
 ('if(t.unchanged){e.read=Date.now();','if(t.unchanged){e.read=Date.now();e.good=e.read;delete e.stale;'),
 ('e.read=Date.now();e.why="kept last good programme: "+(t.why||"temporary failure");e.stale=e.stale||e.good||e.read;',
  'e.lastAttemptAt=Date.now();e.why="kept last good programme: "+(t.why||"temporary failure");e.stale=e.stale||e.good||e.read||null;')]
 for old,new in changes:
  if text.count(old)!=1:raise ValueError('Rebase required for '+old[:70])
  text=text.replace(old,new,1)
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(text);return {'changes':len(changes),'baseSha256':expected,'outputSha256':hashlib.sha256(text.encode()).hexdigest()}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();print(json.dumps(apply(a.input,a.output),indent=2))
