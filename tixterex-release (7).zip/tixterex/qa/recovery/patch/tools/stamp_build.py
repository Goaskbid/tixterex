#!/usr/bin/env python3
"""Stamp all three build identifiers in an assembled staging site. No deployment."""
import argparse,json,re,os,tempfile
from pathlib import Path
def stamp(site,build):
 if not re.fullmatch(r'[A-Za-z0-9._-]{1,100}',build):raise ValueError('Unsafe build identifier')
 html=(site/'index.html').read_text();sw=(site/'sw.js').read_text()
 html,n=re.subn(r'(<meta\s+name="tf-build"\s+content=")[^"]*(")',lambda m:m[1]+build+m[2],html,count=1)
 if n!=1:raise ValueError('Missing unique tf-build meta')
 sw,n=re.subn(r"(const BUILD=')[^']*(';)",lambda m:m[1]+build+m[2],sw,count=1)
 if n!=1:raise ValueError('Use the recovery service worker before stamping')
 for name,body in [('index.html',html),('sw.js',sw),('version.json',json.dumps({'build':build})+'\n')]:
  path=site/name;fd,tmp=tempfile.mkstemp(dir=site,prefix='.stamp-')
  with os.fdopen(fd,'w') as f:f.write(body)
  os.replace(tmp,path)
 return build
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('site',type=Path);p.add_argument('build');a=p.parse_args();print(stamp(a.site,a.build))
