/* One owner for browser venue continuation. Limits apply across slices of the same search. */
(function(w){'use strict';const deep=w.TFDeep;if(!deep)return;const api=w.TFDig=w.TFDig||{};
 api.limits={maxRequests:600,gapMs:1500,dryRounds:null};api.jobs=new Map;api.state=null;
 const live=j=>w.TixTerexAudit?.getSession?.()===j.session&&!j.session.controller.signal.aborted;
 const hasPending=j=>(deep.cursor?.size||0)>0||(j.stats?.deferred||0)>0;
 api.decide=(_pct,_gain,_dry,used,pending)=>!pending?'nothing left to read':used>=api.limits.maxRequests?'fair-use ceiling reached':null;
 function getJob(session){let j=api.jobs.get(session.id);if(!j){j={session,id:session.id,offset:0,used:0,rounds:0,status:'ready',stats:null,aborted:false,controller:null};api.jobs.set(session.id,j);while(api.jobs.size>4)api.jobs.delete(api.jobs.keys().next().value);}return j;}
 api.pause=()=>{api.queued=null;for(const j of api.jobs.values()){if(j.status==='running'){j.aborted=true;j.controller?.abort('user_paused');j.status='paused';}}};
 api.run=async function(session,manual=false){if(!session)return;const j=getJob(session);if(j.status==='running'||!live(j))return;const s=typeof state!=='undefined'?state:w.state;if(!s?.loc||!s.window)return;
  if(j.used>=api.limits.maxRequests){j.status='budget_exhausted';return j;}
  try{if(localStorage.getItem('tfd:on')==='0')return j;}catch(_){}
  if(deep._busy){j.status='waiting';api.queued={session,manual};return j;}
  const scope={lat:+s.loc.lat,lon:+s.loc.lon,radiusKm:+s.filters.radius||8,window:{...s.window},timeZone:s.timeZone,cc:String(s.cc||s.loc.cc||'').toUpperCase(),place:String(s.loc.city||s.loc.name||'').split(',')[0]};
  j.aborted=false;j.status='running';j.controller=new AbortController;const parentAbort=()=>j.controller.abort('search_superseded');session.controller.signal.addEventListener('abort',parentAbort,{once:true});
  // A short mobile-safe slice. Unfinished source cursors are retained for the next slice.
  const deadline=Date.now()+(manual?14000:9000);let slice=0;const take=()=>{if(!live(j)||j.controller.signal.aborted||Date.now()>=deadline||slice>=24||j.used>=api.limits.maxRequests)return false;slice++;j.used++;return true;};
  const timer=setTimeout(()=>j.controller.abort('slice_deadline'),Math.max(0,deadline-Date.now()));
  deep._budget={take};const oldCap=deep.reqCap;deep.reqCap=()=>24;const workers=deep.limits.workers;deep.limits.workers=Math.min(workers,matchMedia('(max-width:760px)').matches?2:4);
  try{const stats=await deep.run({...scope,doorsOnly:j.rounds>0,probeOffset:j.offset},rows=>{if(!live(j)||j.aborted)return;w.TixTerexAudit.consume({type:'events',events:rows},session);try{render();}catch(_){}},()=>{},j.controller.signal);j.stats={...stats};j.rounds++;j.offset+=deep.limits.probes;
   if(j.used>=api.limits.maxRequests)j.status='budget_exhausted';else if(hasPending(j)||j.controller.signal.aborted||stats.retryLater)j.status='paused';else j.status='sources_exhausted';
  }catch(e){j.status=live(j)?'paused':'superseded';j.error=e.message;}finally{clearTimeout(timer);session.controller.signal.removeEventListener('abort',parentAbort);deep._budget=null;deep.reqCap=oldCap;deep.limits.workers=workers;api.state={session:j.id,rounds:j.rounds,requests:j.used,status:j.status,pendingPages:deep.cursor?.size||0,deferred:j.stats?.deferred||0};w.dispatchEvent(new CustomEvent('tf:discovery-progress',{detail:api.state}));const queued=api.queued;api.queued=null;if(queued&&queued.session===w.TixTerexAudit?.getSession?.()&&!queued.session.controller.signal.aborted)setTimeout(()=>api.run(queued.session,queued.manual).catch(()=>{}),0);}
  return j;
 };
 // Permission-blocked sports/archive sources do not consume a visitor's discovery slice.
 deep.LEAGUES={};deep.EUROPE=new Set;deep.limits.archive=0;
 w.addEventListener('tf:search-start',()=>{api.pause();deep.cursor?.clear();});
 w.addEventListener('tf:search-finished',()=>{const session=w.TixTerexAudit?.getSession?.();setTimeout(()=>{if(session===w.TixTerexAudit?.getSession?.())api.run(session).catch(()=>{});},0);});
 w.addEventListener('tf:search-stop',api.pause);
})(window);
