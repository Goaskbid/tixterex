/* Do not perform open-ended catalogue research in a visitor's search. */
(function(w){'use strict';const a=w.TFDeep?.atlas;if(!a)return;
 const debug=new URLSearchParams(location.search).get('operatorDiscovery')==='1';
 a.productionMode=!debug;
 if(!debug){const load=a.load;const portals=a.portalsFor;
  if(load)a.load=async function(){const doc=await load.apply(this,arguments);return {...doc,hubs:[],portals:[],_recoveryMode:'reviewed-datasets-only'};};
  if(portals)a.portalsFor=()=>[];
  // Previous versions cached hundreds of unreviewed catalogue candidates. Reset only this module's cursor namespace.
  try{if(localStorage.getItem('tixterex:atlas-recovery')!=='1'){a.clearCoverageState?.();localStorage.setItem('tixterex:atlas-recovery','1');}}catch(_){}
 }
 w.TTSourceMode={catalogueResearch:debug,normalSearch:'reviewed scoped datasets',liveRecall:null};
})(window);
