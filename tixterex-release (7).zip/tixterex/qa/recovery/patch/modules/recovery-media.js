/* One visual/image owner. No collector caps, event limits or credentials change. */
(function (w) {
  'use strict';
  const d = document, api = w.TTComicFast = {version:'comic-fast-1',stats:{imageLoads:0,lookups:0,metadataRequests:0,cacheHits:0}};
  // The single consumer theme owns presentation.
  const stateOf = () => { try { return typeof state !== 'undefined' ? state : w.state; } catch (_) { return w.state; } };
  const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safe = value => {try {const u=new URL(String(value),d.baseURI);return u.protocol==='https:'&&!u.username&&!u.password?u.href:null;}catch(_){return null;}};
  const norm = v => String(v||'').normalize('NFKD').replace(/\p{M}/gu,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
  const getEvent = id => (stateOf()?.events||[]).find(e=>String(e.id)===id||String(e.occurrenceId)===id);
  const palette={music:'#f4d975',stage:'#f4c2c4',sport:'#bde7d2',film:'#cbd8f1',family:'#f4d6a6',food:'#f2cfaa',market:'#ebd5a9',art:'#c2e4dd',festival:'#f7d480',party:'#dfd0ef'};
  const labels={music:'Music',stage:'On stage',sport:'Sport',film:'Cinema',family:'Family',food:'Food',market:'Markets',art:'Art',festival:'Festivals',party:'Nightlife'};
  api.fallback=function(e={},kind){const cat=e.cat||kind||'other',pose=w.TFDino?.forKind(cat,e.id||e.title||'')||'ticket',src=w.TFDino?.rexSrc(pose)||'';return '<span class="tt-comic-fallback" style="--tt-fallback:'+(palette[cat]||'#d2eedd')+'" aria-hidden="true"><small>'+esc(labels[cat]||'Explore')+'</small><img alt="" src="'+esc(src)+'" width="112" height="112" decoding="async" loading="lazy"></span>';};
  if(w.A17)w.A17.cover=api.fallback;
  // Illustrations never masquerade as event photographs. Existing licensed media wins.
  const rights=e=>!e.factsOnly && !/\bnc\b|\bnd\b|non.?commercial|all rights reserved/i.test(e.imgLicence||'') && (e.mediaRights?.reuseAllowed===true || /^(Ticketmaster Discovery API|SeatGeek API)/i.test(e.licence||'') || /cc0|public domain|cc[- ]?by|creative commons/i.test(e.imgLicence||''));
  api.imageCandidate=function(e){
    if(!e||e.factsOnly)return null;
    const media=e.media;
    if(media&&media.reuseAllowed===true&&safe(media.url)&&safe(media.sourcePage))return {src:safe(media.url),page:safe(media.sourcePage),by:media.creator||media.provider||'Publisher',license:media.license||'Permission recorded',kind:media.kind||'event',width:+media.width||0,height:+media.height||0,variants:Array.isArray(media.variants)?media.variants:[]};
    if(rights(e)&&safe(e.pubImg||e.image)&&safe(e.imageSourceUrl||e.sourceUrl||e.url))return {src:safe(e.pubImg||e.image),page:safe(e.imageSourceUrl||e.sourceUrl||e.url),by:e.imgAuthor||e.pubImgBy||e.imgProv||'Publisher',license:e.imgLicence||e.licence||'',kind:e.imageType==='poster'?'poster':'event',width:+e.imageWidth||0,height:+e.imageHeight||0};
    return null;
  };
  api.chooseVariant=(media,target)=>{const choices=(media.variants||[]).filter(v=>safe(v.url)&&Number(v.width)>0).sort((a,b)=>a.width-b.width);return choices.find(v=>v.width>=target)||choices.at(-1)||{url:media.src,width:media.width};};
  const cacheKey='tt:venue-media:v1', inflight=new Map(), cache=new Map();
  try {for(const [k,v]of Object.entries(JSON.parse(localStorage.getItem(cacheKey)||'{}')))if(v&&v.until>Date.now())cache.set(k,v);}catch(_){}
  function put(k,value){cache.set(k,{value,until:Date.now()+(value?7*86400000:300000)});while(cache.size>128)cache.delete(cache.keys().next().value);try{localStorage.setItem(cacheKey,JSON.stringify(Object.fromEntries(cache)));}catch(_){}return value;}
  async function json(url){api.stats.metadataRequests++;const c=new AbortController(),timer=setTimeout(()=>c.abort(),4500);try{const r=await fetch(url,{signal:c.signal,credentials:'omit',referrerPolicy:'no-referrer'});if(!r.ok)throw Error('Image metadata HTTP '+r.status);return await r.json();}finally{clearTimeout(timer);}}
  const km=(a,b,c,e)=>{const r=Math.PI/180;return 12742*Math.asin(Math.sqrt(Math.sin((c-a)*r/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin((e-b)*r/2)**2));};
  const generic=new Set('the le la les de der die das of in at a an'.split(' '));
  const tokens=v=>norm(v).split(' ').filter(s=>s.length>=3&&!generic.has(s));
  api.matchesVenue=(venue,title)=>{if(norm(venue)===norm(title))return true;const a=tokens(venue),b=new Set(tokens(title));if(!a.length)return false;const n=a.filter(x=>b.has(x)).length;return n>=Math.min(2,a.length)&&n/a.length>=.75;};
  const plain=value=>{const t=d.createElement('template');t.innerHTML=String(value||'');return(t.content.textContent||'').trim();};
  api.commonsMedia=async function(filename,kind='venue'){
    if(!filename||/[<>]/.test(filename))return null;
    const u='https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&prop=imageinfo&iiprop=url%7Csize%7Cextmetadata&iiurlwidth=640&titles='+encodeURIComponent('File:'+filename.replace(/^File:/,''));
    const j=await json(u),p=Object.values(j.query?.pages||{})[0],i=p?.imageinfo?.[0],m=i?.extmetadata||{},license=plain(m.LicenseShortName?.value||'');
    if(!i||!/^(CC0|CC BY|CC-BY|Public domain|PD)/i.test(license)||/\bNC\b|\bND\b|non.?commercial/i.test(license))return null;
    const src=safe(i.thumburl||i.url),page=safe(i.descriptionurl);if(!src||!page||new URL(src).hostname!=='upload.wikimedia.org')return null;
    return {src,page,by:plain(m.Artist?.value)||'Wikimedia Commons contributor',license,licenseUrl:safe(m.LicenseUrl?.value),kind,width:i.thumbwidth||i.width,height:i.thumbheight||i.height};
  };
  api.findVenue=function(e){
    const valid=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(+v);
    if(!e.venue||!valid(e.lat)||!valid(e.lon)||e.geoApprox||e.online)return Promise.resolve(null);
    const key=norm(e.venue)+'@'+(+e.lat).toFixed(4)+','+(+e.lon).toFixed(4)+'|'+(e.venueImg||'');
    const hit=cache.get(key);if(hit&&hit.until>Date.now()){api.stats.cacheHits++;return Promise.resolve(hit.value);}
    if(inflight.has(key))return inflight.get(key);
    if(navigator.connection?.saveData||api.stats.lookups>=8)return Promise.resolve(null);
    api.stats.lookups++;
    const promise=(async()=>{
      try{
        if(e.venueImg)return put(key,await api.commonsMedia(e.venueImg));
        const cc=String(e.cc||stateOf()?.cc||'').toUpperCase(),lang=({CH:'de',DE:'de',AT:'de',FR:'fr',IT:'it',ES:'es',JP:'ja',KR:'ko',CN:'zh',TW:'zh',BR:'pt'})[cc]||'en';
        const u='https://'+lang+'.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=geosearch&ggscoord='+encodeURIComponent(+e.lat+'|'+ +e.lon)+'&ggsradius=300&ggslimit=12&prop=pageimages%7Ccoordinates&piprop=name%7Cthumbnail&pilicense=free&pithumbsize=640';
        const j=await json(u),p=Object.values(j.query?.pages||{}).filter(p=>p.pageimage&&p.coordinates?.[0]&&api.matchesVenue(e.venue,p.title)&&km(+e.lat,+e.lon,p.coordinates[0].lat,p.coordinates[0].lon)<=.3).sort((a,b)=>Number(norm(b.title)===norm(e.venue))-Number(norm(a.title)===norm(e.venue)))[0];
        if(!p)return put(key,null);return put(key,await api.commonsMedia(p.pageimage));
      }catch(_){return put(key,null);}
    })().finally(()=>inflight.delete(key));inflight.set(key,promise);return promise;
  };
  const queue=[];let running=0;const queued=new WeakSet();
  function enqueue(card){if(!card?.isConnected||queued.has(card))return;queued.add(card);queue.push(card);pump();}
  function pump(){while(running<2&&queue.length){const card=queue.shift();if(!card.isConnected)continue;running++;serve(card).catch(()=>{}).finally(()=>{running--;pump();});}}
  async function attach(card,pic,m){
    if(!card.isConnected||!m?.src)return false;
    const img=new Image(),rect=pic.getBoundingClientRect(),wanted=Math.ceil(rect.width*Math.min(devicePixelRatio||1,2)),variant=api.chooseVariant(m,wanted);
    img.className='tt-photo'+(m.kind==='poster'?' tt-poster':'');img.style.visibility='hidden';img.alt=m.kind==='venue'?'Venue: '+(getEvent(card.dataset.ev)?.venue||''):'Event image: '+(getEvent(card.dataset.ev)?.title||'');
    img.decoding='async';img.loading=rect.top<innerHeight?'eager':'lazy';img.fetchPriority=rect.top<innerHeight?'auto':'low';img.referrerPolicy='no-referrer';img.width=m.width||640;img.height=m.height||480;
    if(m.variants?.length){const v=m.variants.filter(v=>safe(v.url)&&+v.width>0);img.srcset=v.map(v=>safe(v.url)+' '+v.width+'w').join(', ');img.sizes='(max-width:760px) 108px,184px';}
    api.stats.imageLoads++;
    return await new Promise(resolve=>{
      let done=false;const finish=v=>{if(done)return;done=true;clearTimeout(timer);resolve(v);};
      const timer=setTimeout(()=>{img.remove();finish(false);},8000);
      img.onerror=()=>{img.remove();finish(false);};
      img.onload=()=>{
        if(!card.isConnected||!img.naturalWidth){img.remove();finish(false);return;}
        if(img.naturalWidth<wanted*.75)img.classList.add('tt-small');
        pic.querySelectorAll('.tt-photo,.tt-photo-credit,.a27-photo,.a53-photo,.a27-cred,.a53-cred').forEach(n=>{if(n!==img)n.remove();});
        img.style.visibility='visible';pic.classList.add('tt-photo-ready');
        if(m.page){const a=d.createElement('a');a.className='tt-photo-credit';a.href=m.page;a.target='_blank';a.rel='noopener';a.textContent=m.kind==='venue'?'Venue photo':'Event image';a.title=m.by+(m.license?' | '+m.license:'');a.setAttribute('aria-label',a.textContent+'. '+a.title+'. Open source and licence');a.addEventListener('click',event=>event.stopPropagation());pic.append(a);}
        finish(true);
      };
      // Set handlers first. Failed images leave the original illustration visible.
      img.src=safe(variant.url)||m.src;pic.append(img);
    });
  }
  async function serve(card){const pic=card.querySelector('.pic'),e=getEvent(card.dataset.ev);if(!pic||!e)return;
    const direct=api.imageCandidate(e);if(direct&&await attach(card,pic,direct))return;
    if(pic.querySelector('img:not(.tt-photo):not(.tt-comic-fallback img)')&&!pic.classList.contains('nopic'))return;
    const venue=await api.findVenue(e);if(venue)await attach(card,pic,venue);
  }
  const io='IntersectionObserver'in w?new IntersectionObserver(entries=>{for(const x of entries)if(x.isIntersecting){io.unobserve(x.target);enqueue(x.target);}},{rootMargin:'160px 0px'}):null;
  const scanned=new WeakSet();function scan(root){const cards=root.matches?.('article.tix[data-ev]')?[root]:root.querySelectorAll?.('article.tix[data-ev]')||[];for(const card of cards){if(scanned.has(card))continue;scanned.add(card);io?io.observe(card):enqueue(card);}}
  function settingsDialog(){const el=d.getElementById('settings'),opener=d.getElementById('btnSettings');if(!el||!opener)return;el.setAttribute('role','dialog');el.setAttribute('aria-modal','true');el.setAttribute('aria-label','Settings');let prior=null,was=false;
    new MutationObserver(()=>{const open=el.classList.contains('open');if(open===was)return;was=open;if(open){prior=d.activeElement;const first=el.querySelector('button,input,select,[tabindex="0"]');first?.focus();}else (prior?.isConnected?prior:opener).focus();}).observe(el,{attributes:true,attributeFilter:['class']});
    d.addEventListener('keydown',ev=>{if(!el.classList.contains('open')||ev.key!=='Tab')return;const all=[...el.querySelectorAll('button,a[href],input,select,textarea,[tabindex="0"]')].filter(n=>!n.disabled&&n.getClientRects().length);if(!all.length)return;const first=all[0],last=all.at(-1);if(ev.shiftKey&&(d.activeElement===first||!el.contains(d.activeElement))){ev.preventDefault();last.focus();}else if(!ev.shiftKey&&(d.activeElement===last||!el.contains(d.activeElement))){ev.preventDefault();first.focus();}},true);
  }
  function mount(){
    const grid=d.getElementById('grid');if(grid){scan(grid);new MutationObserver(records=>{for(const r of records)for(const n of r.addedNodes)if(n.nodeType===1)scan(n);}).observe(grid,{childList:true,subtree:true});}
    settingsDialog();
    // No lookups run solely because a card exists off-screen.
    w.addEventListener('tf:search-start',()=>{api.stats.lookups=0;queue.length=0;});
  }
  w.TFPremium={on:true,photo:card=>enqueue(card),paint:()=>{const g=d.getElementById('grid');if(g)scan(g);},fixAll:()=>0};
  if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})(window);
