/* TixTerex recovery candidate. Reuses existing search, filters, saved items and detail handlers. */
(function (w,d) {
 'use strict';
 const api=w.TTRecovery={version:'r91-recovery-1',stages:[],debug:new URLSearchParams(location.search).get('debug')==='1'};
 const $=id=>d.getElementById(id),ST=()=>typeof state!=='undefined'?state:w.state;
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let queued=false,previousSession=null,previousPlace=null;
 function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;arrange();paint();});}
 function node(tag,id,cls,text){const e=d.createElement(tag);if(id)e.id=id;if(cls)e.className=cls;if(text)e.textContent=text;return e;}
 function showDialog(id,opener){const e=$(id);if(!e)return;e._return=opener||d.activeElement;try{e.showModal();}catch(_){e.setAttribute('open','');}e.querySelector('button,input,select,a[href]')?.focus();}
 function dialog(id,title){const e=node('dialog',id,'r91-dialog');const head=node('div',null,'r91-dialog-head');const h=node('h2',id+'Title',null,title);const close=node('button',null,'r91-close','Close');close.type='button';close.setAttribute('aria-label','Close '+title);close.onclick=()=>e.close();head.append(h,close);e.append(head,node('div',id+'Body','r91-dialog-body'));e.setAttribute('aria-labelledby',h.id);e.addEventListener('close',()=>{if(e._return?.isConnected)e._return.focus();});e.addEventListener('click',ev=>{if(ev.target===e){const r=e.getBoundingClientRect();if(ev.clientX<r.left||ev.clientX>r.right||ev.clientY<r.top||ev.clientY>r.bottom)e.close();}});d.body.append(e);return e;}
 function move(id,target){const el=$(id);if(el&&target&&!target.contains(el)&&!el.contains(target))target.append(el);}
 function arrange(){
  const f=$('r91FiltersBody'),m=$('r91ToolsBody');if(!f||!m)return;
  // Move the existing nodes, never clone controls or discard their event handlers.
  for(const id of ['a21Picks','a9Quick','rail','tfx','tfPicks','tf17CinemaFilters','tf16SearchTools','tf18OpenInbox'])move(id,f);
  for(const e of [...d.querySelectorAll('.search-card>.precats,.search-card>.tf16-search-tools,.search-card>.tf14-tools,.search-card>.tf16-intent')])f.append(e);
  for(const id of ['btnIcs','btnIcsPlan','btnSharePlan','btnMap','btnMapTop','btnSettings'])move(id,m);
  const extra=$('r91ExtraBody');for(const id of ['a16Discover','ttToday','ttPassport','ttFollow','seasonAhead','houseStrip','marquee','tf16City','tf16Supplement','tfVenues','ttTonight','ttWeekend'])move(id,extra);
  move('ttAbout',$('r91Source'));move('tfLocationPrivacy',$('r91Source'));if($('tfLocationPrivacy'))$('tfLocationPrivacy').textContent='The place and dates go to the connected calendars used for this search. Opening publisher links or third-party travel tools contacts those services. Saved preferences stay in this browser. Approved affiliate links, when configured, are marked sponsored.';
  d.querySelectorAll('#grid .tix').forEach(card=>{const back=card.querySelector('.tback,.a17-back');if(back)back.inert=!card.classList.contains('flipped');const detail=card.querySelector('.tf-butler');if(detail&&detail.textContent!=='Details')detail.textContent='Details';const trust=card.querySelector('.a76-trust');if(trust&&!trust.dataset.r91){trust.dataset.r91='1';trust.textContent=trust.textContent.replace(/^\s*\u2713\s*From/i,'Source:');}});
  const diagnostics=$('r91DebugBody');if(api.debug)for(const id of ['statusbar','tfDeep','tfCoverageContinuation','tfComplete','tfIndexStatus','tfDiscovery','tf17Directory'])move(id,diagnostics);
  // New controls can be created after the first event arrives. Dialog content must wrap, not scroll sideways.
  f.querySelectorAll('.rail,.rail-row,.a21-row,.a73-g,.tfx-days').forEach(e=>{e.classList.add('r91-wrap');});
 }
 function receipt(){const s=ST(),session=w.TixTerexAudit?.getSession?.(),transport=w.TixTerexBrowser?.lastReceipt;let visible=[];try{visible=typeof filteredEvents==='function'?filteredEvents():s?.events||[];}catch(_){}
  return {schema:'tixterex-recovery-evidence/1',build:d.querySelector('meta[name="tf-build"]')?.content,at:new Date().toISOString(),pageOrigin:location.origin,sessionId:session?.id??null,status:session?.status??'idle',scope:s?.loc?{place:s.loc,window:s.window,timeZone:s.timeZone,radiusKm:+s.filters?.radius}:null,filters:s?.filters||{},counts:{transportEmitted:transport?.count??null,sessionUnique:session?.rows?.size??null,stateEvents:s?.events?.length??0,filteredOccurrences:visible.length,renderedCards:d.querySelectorAll('#grid article[data-ev]').length},observations:visible.map(e=>({id:e.id,occurrenceId:e.occurrenceId,title:e.title,venue:e.venue,start:e.start,end:e.end,lat:e.lat,lon:e.lon,sourceUrl:e.sourceUrl||e.url,sourceId:e.sourceId,observedAt:e.observedAt,cancelled:!!e.cancelled})),sources:session?.sources||[],transport,discovery:w.TFDeep?.stats||null,recall:{top:null,public:null,reason:'Independent ground truth not attached'}};
 }
 api.receipt=receipt;
 function download(){const body=JSON.stringify(receipt(),null,2),u=URL.createObjectURL(new Blob([body],{type:'application/json'}));const a=node('a');a.href=u;a.download='tixterex-recovery-evidence.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),2000);}
 function paint(){const s=ST();if(!s)return;const session=w.TixTerexAudit?.getSession?.();const r=receipt(),n=r.counts.filteredOccurrences,acquired=r.counts.stateEvents;
  const place=String(s.loc?.city||s.loc?.name||s.city||'').split(',')[0];const busy=!!s.searching||session?.status==='searching';
  $('r91ResultTitle').textContent=place?('Events in '+place):'Find your next event';
  const status=$('r91Status');status.textContent=busy?(n?`${n} matching occurrences so far. Checking more sources.`:'Checking available event sources...'):session?(n?`${n} matching occurrences. Coverage can be incomplete.`:acquired?'No matches with these filters. Your search returned '+acquired+' occurrences.':'No verified events loaded for this search. This does not mean nothing is happening.'):'Choose a place and dates to start.';
  $('r91Stop').hidden=!busy;$('r91Retry').hidden=!session||busy||n>0;$('r91Clear').hidden=!session||busy||n>0;
  $('r91SourceNote').textContent=session?'Event facts come from the linked publishers and stored programmes. A successful request is not proof of complete local coverage.':'Sources and freshness appear after your search.';
  const b=$('r91FilterCount');const f=s.filters||{};const active=[f.cat&&f.cat!=='all',!!f.q,!!f.free,!!f.savedOnly,!!f.timeOfDay&&f.timeOfDay!=='all'].filter(Boolean).length;b.textContent=active?'Filters ('+active+')':'Filters';
  if(previousSession!==session?.id){previousSession=session?.id;api.stages.push({session:previousSession,at:new Date().toISOString(),status:session?.status});api.stages=api.stages.slice(-20);}
  if(previousPlace!==place){previousPlace=place;const tc=$('r91Ticketcorner');if(tc)tc.hidden=!!s.cc&&String(s.cc).toUpperCase()!=='CH';}
  const job=w.TFDig?.state;if($('r91CheckMore'))$('r91CheckMore').hidden=busy||!job||!['paused','waiting'].includes(job.status);
  const empty=$('r91Empty');empty.hidden=!session||busy||n>0;
  // Do not override a user's scroll position when results stream in or a source finishes.
 }
 function eventDetails(id){
  const s=ST(),all=s?.events||[];let event=all.find(e=>String(e.id)===String(id)||String(e.occurrenceId)===String(id));
  if(!event){try{event=saved.list().find(e=>String(e.id||e.k)===String(id));}catch(_){}}
  if(!event)return;const box=$('r91EventBody');box.replaceChildren();$('r91EventTitle').textContent=event.title||'Event';
  const safe=u=>{try{const p=new URL(u);return /^https?:$/.test(p.protocol)&&!p.username&&!p.password?p.href:null;}catch(_){return null;}};
  const tz=s?.timeZone||event.timeZone||'UTC';let time='Time not published';
  try{const date=event.dateOnly?new Date((event.localDate||String(event.start).slice(0,10))+'T12:00:00Z'):new Date(event.start);time=new Intl.DateTimeFormat('en-GB',{timeZone:event.dateOnly?'UTC':tz,dateStyle:'full',...event.dateOnly?{}:{timeStyle:'short'}}).format(date)+(event.dateOnly?' (time not published)':' ('+tz.replaceAll('_',' ')+')');}catch(_){}
  const price=event.free===true||event.price===0?'Free':event.price!=null&&Number.isFinite(+event.price)?String(event.cur||'')+' '+event.price:event.priceText||'See publisher';
  const facts=[['When',time],['Where',[event.venue,event.room,event.address].filter(Boolean).join(', ')||'Location not published'],['Price',price],['Status',event.cancelled?'Cancelled':event.postponed?'Postponed or rescheduled':event.soldOut?'Sold out':event.eventStatus?String(event.eventStatus).split('/').pop().replace(/^Event/,''):'See publisher for changes']];
  const dl=node('dl',null,'r91-facts');for(const [label,value]of facts){const div=node('div');div.append(node('dt',null,null,label),node('dd',null,null,value));dl.append(div);}box.append(dl);
  const target=safe(event.ticketUrl)||safe(event.url)||safe(event.sourceUrl);if(target){const a=node('a',null,'r91-link',event.ticketUrl?'Open ticket page':'Open event source');a.href=target;a.target='_blank';a.rel='noopener';box.append(a);}
  if(event.lat!=null&&event.lon!=null&&Number.isFinite(+event.lat)&&Number.isFinite(+event.lon)&&!event.geoApprox){const a=node('a',null,'r91-link','Plan a route');const u=new URL('https://www.google.com/maps/dir/');u.searchParams.set('api','1');u.searchParams.set('destination',event.lat+','+event.lon);a.href=u.href;a.rel='noopener';a.target='_blank';box.append(a);}
  const save=node('button',null,null,'Save event');save.type='button';const drawSave=()=>{try{save.textContent=saved.has(event)?'Remove saved event':'Save event';save.setAttribute('aria-pressed',String(saved.has(event)));}catch(_){}};drawSave();save.onclick=()=>{try{saved.toggle({...event,start:new Date(event.start)});drawSave();render();}catch(_){}paint();};box.append(save);
  if(event.desc&&!event.factsOnly){const detail=node('details');detail.append(node('summary',null,null,'Publisher description'),node('p',null,null,String(event.desc).replace(/<[^>]*>/g,'').slice(0,3000)));box.append(detail);}
  const stamp=Date.parse(event.observedAt);box.append(node('p',null,'r91-help',Number.isFinite(stamp)&&stamp<=Date.now()+300000?'Source observation: '+new Date(stamp).toISOString().replace('T',' ').replace('.000Z',' UTC')+'. Verify changes on the linked page.':'Publisher observation time unavailable. Verify details on the linked page.'));
  showDialog('r91Event',d.activeElement);
 }
 function start(){
  if($('r91Toolbar'))return;const root=d.documentElement;root.classList.add('r91');root.classList.remove('tt-anim');root.dataset.theme='light';root.dataset.layout='auto';
  const background=()=>{if(d.body.style.getPropertyValue('background-color')!=='rgb(247, 247, 242)')d.body.style.setProperty('background-color','rgb(247, 247, 242)','important');};background();new MutationObserver(background).observe(d.body,{attributes:true,attributeFilter:['style']});
  d.querySelector('meta[name="theme-color"]')?.setAttribute('content','#f7f7f2');
  // Honest appearance policy: this release offers one tested light theme, regardless of OS preference.
  try{localStorage.setItem('tf59:theme','light');localStorage.setItem('tt:motion','off');}catch(_){}
  dialog('r91Filters','Filters');dialog('r91Tools','Your tools');dialog('r91Event','Event');api.legacyButler=w.openButler;w.openButler=eventDetails;if(w.TFT)w.TFT.venuePhoto=()=>Promise.resolve(null);if(typeof venuePhotoByName==='function')venuePhotoByName=()=>Promise.resolve(null);if(typeof workPhotoByTitle==='function')workPhotoByTitle=()=>Promise.resolve(null);
  const menu=$('r91ToolsBody');menu.innerHTML='<p class="r91-help">Your saved events, map, calendar exports and settings stay available here.</p><section id="r91Ticketcorner"><h3>Ticketcorner alerts</h3><p>Subscribe on Ticketcorner. Their newsletter is separate from TixTerex event coverage.</p><a class="r91-link" href="https://www.ticketcorner.ch/campaign/ticketcorner-newsletter/" target="_blank" rel="noopener">Open official subscription page</a></section><details id="r91Extra"><summary>More planning tools</summary><div id="r91ExtraBody"></div></details><details id="r91Source"><summary>Sources and search evidence</summary><p id="r91SourceNote"></p><button id="r91Export" type="button">Export this search evidence</button></details>';
  $('r91Export').onclick=download;
  const policy=$('tfPolicy');if(policy){const details=node('details','r91PolicyDetails');details.append(node('summary',null,null,'Source credits and privacy'),node('div','r91PolicyBody'));while(policy.firstChild)$('r91PolicyBody')?$('r91PolicyBody').append(policy.firstChild):details.lastChild.append(policy.firstChild);policy.append(details);}
  w.addEventListener('tf:update-available',()=>{let b=$('r91Update');if(!b){b=node('button','r91Update',null,'Update available: reload when ready');b.type='button';b.onclick=()=>location.reload();menu.prepend(b);}});
  if(api.debug){const det=node('details','r91Debug');det.append(node('summary',null,null,'Developer diagnostics'),node('div','r91DebugBody'));menu.append(det);}
  const top=d.querySelector('.top-inner');const open=node('button','r91Menu','r91-primary-menu','Menu');open.type='button';open.onclick=()=>showDialog('r91Tools',open);top?.append(open);
  const hero=d.querySelector('.hero');const h=hero?.querySelector('h1');if(h)h.textContent='Find something worth going to.';const subtitle=hero?.querySelector(':scope>p');if(subtitle)subtitle.textContent='Pick a place and dates. See the event. Open its official page.';
  const card=d.querySelector('.search-card'),sg=card?.querySelector('.search-grid');if(sg){const fields=sg.querySelectorAll('.field');[['Place',fields[0]],['Dates',fields[1]],['Distance',fields[2]]].forEach(([label,e])=>{if(!e)return;const input=e.querySelector('input,select');const l=node('label',null,'r91-label',label);if(input)l.htmlFor=input.id;e.prepend(l);});}
  const tb=node('div','r91Toolbar');const filters=node('button','r91FilterCount',null,'Filters');filters.type='button';filters.onclick=()=>showDialog('r91Filters',filters);
  const savedButton=node('button','r91Saved',null,'Saved');savedButton.type='button';savedButton.onclick=()=>{const s=ST();s.filters.savedOnly=!s.filters.savedOnly;s.shown=24;savedButton.setAttribute('aria-pressed',String(s.filters.savedOnly));try{render();}catch(_){}paint();};savedButton.setAttribute('aria-pressed','false');
  const more=node('button','r91CheckMore',null,'Check more sources');more.type='button';more.hidden=true;more.onclick=()=>w.TFDig?.run?.(w.TixTerexAudit?.getSession?.(),true);
  const stop=node('button','r91Stop',null,'Stop');stop.type='button';stop.hidden=true;stop.onclick=()=>{w.TixTerexAudit?.getSession?.()?.cancel('user_stopped');if(ST())ST().searching=false;paint();};
  tb.append(filters,savedButton,stop,more);card?.after(tb);
  const result=node('section','r91ResultSummary');result.setAttribute('aria-label','Search summary');result.append(node('h2','r91ResultTitle',null,'Find your next event'));const status=node('p','r91Status');status.setAttribute('role','status');status.setAttribute('aria-live','polite');result.append(status);
  const empty=node('div','r91Empty');empty.hidden=true;empty.innerHTML='<p>Try a wider date range or another place. Check the source link before making plans.</p>';
  const clear=node('button','r91Clear',null,'Reset display filters');clear.type='button';clear.hidden=true;clear.onclick=()=>{const s=ST();Object.assign(s.filters,{cat:'all',q:'',free:false,savedOnly:false,timeOfDay:'all',intent:'all'});s.shown=24;for(const id of ['kw','filterQ'])if($(id))$(id).value='';$('r91Saved').setAttribute('aria-pressed','false');try{render();}catch(_){}paint();};
  const retry=node('button','r91Retry',null,'Retry this search');retry.type='button';retry.hidden=true;retry.onclick=()=>{const s=ST(),loc=s?.loc;if(loc)runSearch({...loc,cc:s.cc,timeZone:s.timeZone});else $('btnGo')?.click();};
  result.append(empty,clear,retry);$('resultsSec')?.before(result);
  const about=$('ttAbout');if(about){about.innerHTML='<details><summary>About TixTerex</summary><p>Find public events from connected calendars and stored publisher programmes. Availability varies by place and category. Dates, changes and tickets are confirmed on each event\'s linked source.</p><p>Saved events stay in this browser. Ticketcorner subscriptions are managed by Ticketcorner.</p></details>';}
  // Remove debug-only settings from the customer dialog, without deleting the retained controls.
  const settings=$('settings');if(settings){settings.dataset.recovery='1';for(const id of ['setRelay','setTm','setSync','setCrawl','setContrib','btnRelayTest','relayTestOut','lnkRelayHelp','lnkIndexHelp','btnTestLab']){const el=$(id);if(el){el.closest('label')?.classList.add('r91-engineering');el.classList.add('r91-engineering');d.querySelector('label[for="'+id+'"]')?.classList.add('r91-engineering');}}}
  for(const el of d.querySelectorAll('#settings .hint'))if(/relay|worldwide|index|key|five minutes|free forever/i.test(el.textContent))el.classList.add('r91-engineering');
  const settingsOpener=$('btnSettings');if(settingsOpener){settingsOpener.textContent='Settings';settingsOpener.addEventListener('click',()=>{$('r91Tools').close();},{capture:true});}
  for(const id of ['btnMap','btnMapTop'])if($(id)){$(id).addEventListener('click',()=>{$('r91Tools').close();},{capture:true});}
  // The original grid remains the only event renderer and retains its native save, details and ticket actions.
  const grid=$('grid');if(grid){new MutationObserver(schedule).observe(grid,{childList:true});if(grid.parentNode)new MutationObserver(schedule).observe(grid.parentNode,{childList:true});}
  const search=d.querySelector('.search-card');if(search)new MutationObserver(schedule).observe(search,{childList:true});
  ['tf:search-start','tf:search-finished','tf:search-stop','tf:location','tf:coverage-finished','tf:discovery-progress','tf:follow'].forEach(name=>w.addEventListener(name,schedule));
  d.addEventListener('click',ev=>{if(ev.target.closest('#r91Filters,#grid .tix'))setTimeout(schedule,0);},true);
  // Controls created by deferred feature modules are moved once after their scheduled mount, not polled forever.
  [0,500,1600,3500].forEach(ms=>setTimeout(schedule,ms));
  arrange();paint();api.ready=true;
 }
 if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',()=>setTimeout(start,0),{once:true});else start();
})(window,document);
