(function(w){'use strict';
 const online=e=>/^(online|virtual|virtuell|digital)\b|webinar|livestream/i.test(String(e.venue||''))||/OnlineEventAttendanceMode|^online$/i.test(String(e.eventAttendanceMode||e.attendanceMode||''));
 const tidy=list=>{if(!Array.isArray(list))return[];const out=list.slice();for(const e of out)if(online(e)){e.online=true;if(e.km!=null){e._ttKm=e.km;e.km=null;}}return out.filter(e=>!e.online).concat(out.filter(e=>e.online));};
 // Translation hypotheses must never erase independent performances, rooms or languages.
 // Exact occurrence identity is already handled by the common deduplicator.
 w.TTTidy={tidy,isOnline:online};
 const start=()=>{const original=w.filteredEvents;if(typeof original!=='function'||original._r91Tidy)return;const f=function(){return tidy(original.apply(this,arguments));};Object.assign(f,original);f._r91Tidy=true;w.filteredEvents=f;};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})(window);
