(function(w,d){'use strict';
 function safe(u){try{const x=new URL(u,location.href);return x.protocol==='https:'&&!x.username&&!x.password?x:null;}catch(_){return null;}}
 function config(){try{return JSON.parse(d.querySelector('meta[name="tf-aff"]')?.content||'{}');}catch(_){return{};}}
 const out=input=>{const u=safe(input);if(!u)return null;let sponsored=false;for(const [host,p] of Object.entries(config())){if(u.hostname!==host&&!u.hostname.endsWith('.'+host))continue;
  // Ticketcorner requires a direct shop link. Accept only configured partner query parameters, never a redirect template.
  if(/^[\w-]{1,32}=[\w.-]{1,64}(&[\w-]{1,32}=[\w.-]{1,64})*$/.test(p)){for(const [k,v] of new URLSearchParams(p))u.searchParams.set(k,v);sponsored=true;}
  else if(!/(^|\.)ticketcorner\.ch$/.test(u.hostname)&&typeof p==='string'&&p.includes('{url}')){const wrapped=safe(p.replace('{url}',encodeURIComponent(u.href)));if(wrapped)return{url:wrapped.href,sponsored:true};}
 }return{url:u.href,sponsored};};
 w.TTLead={out,brand:()=> 'tixterex',affFor:host=>config()[host]||null};
 const decorate=ev=>{const a=ev.target.closest?.('a[href]');if(!a||a.dataset.r91Link)return;const r=out(a.href);if(r){a.href=r.url;a.rel='noopener'+(r.sponsored?' sponsored':'');a.dataset.r91Link='1';}};
 d.addEventListener('click',decorate,true);d.addEventListener('auxclick',decorate,true);
})(window,document);
