# TixTerex recovery package

Start with AUDIT.html and docs/HANDOFF_TO_CLAUDE.md.

This is a reviewed staging overlay for the exact uploaded A90 build, not a complete website ZIP and not a 100/75 certification. Keep all existing public assets and newer data. No production account or deployment was changed.

- patch/website: changed app and service-worker files.
- patch/modules: readable recovery implementations.
- patch/collector: narrowly patched collector; needs the existing tools/lib directory.
- patch/tools: checksum guards, stamping and readiness checks.
- tests and evidence: offline verification, synthetic fixtures and screenshots.
- ticketcorner: official subscription route, inactive partner setup and unsent request.
- benchmark: 24-city evidence contract and scorer; currently all unmeasured.

Do not copy tests, evidence, benchmark inputs or internal tools into the public website. No font files are included.
