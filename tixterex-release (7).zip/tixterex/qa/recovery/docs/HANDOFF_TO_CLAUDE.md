# TixTerex recovery handoff

## Decision

Stop adding visual layers and unqualified source directories. Integrate the supplied recovery candidate in staging. Preserve the current production site until the final-origin acceptance run passes. Do not claim 100/75 from this package.

The audited release is `a90-202611241341`, index SHA-256 `9cc30c6c80eb7a69f642822824810e2ad3cba696cfb3f8883c8b91c4486c6bb7`. The source archive's compiled `site/index.html` has a placeholder build identifier. Several loose source modules differ from the compiled bundle. Rebuilding the old loose modules without porting the recovery changes can undo the fixes.

## Deliverable boundaries

`patch/website/` is an overlay, not a complete standalone site. It changes index.html, sw.js and version metadata. It deliberately contains no event data, place directory or font files. The supplied release plus BOTH place ZIPs supply the existing assets. Never overwrite a newer production event snapshot with the old bundled November 12 snapshot.

`patch/collector/ingest.mjs` is a targeted collector candidate. It belongs beside the existing `tools/lib/` directory. It has not performed a production collection run. The changes have fragment/unit tests and syntax checks, not a full external-website collection certification.

## Integration order

1. Assemble a staging tree from the exact release and both place ZIPs. Confirm all 3,043 referenced locality files are present. Apply the guarded browser patch or use the prebuilt overlay. Keep all current data, legal pages, site icons and approved image assets.
2. Port the named module replacements to the actual source/build inputs. Retire the disabled old modules instead of appending another override after them. Keep the built artifact SHA in your release manifest. Rebuild, then compare the effective compiled scripts with the tested candidate.
3. Merge the collector changes separately. Keep publisher facts, last-good observations, explicit zero coordinates and ongoing events. Preserve collection state transactionally. Do not enlarge the existing collection limits or reintroduce large GitHub collection jobs.
4. Integrate the build-stamping script and package gate below. Fix artifact-source selection. Keep production data unchanged if collection fails. Surface the collection failure in the deployment report; a green UI deployment is not a green supply run.
5. Validate the deployed staging URL on real Android Chrome and iPhone Safari. Test the root/custom-domain route AND any GitHub project subpath. The local browser tests cannot certify CORS, service-worker upgrade, real push delivery or final-origin data access.
6. Activate Ticketcorner only after the actual partner authorisation/feed/schema is supplied. The consumer newsletter link in the UI is not an event-feed connection.
7. Complete the independent 24-city benchmark. The generated report currently records all 24 as UNMEASURED.

## Commands

```sh
python patch/tools/apply_recovery.py --site STAGING_SITE --output OVERLAY
# Copy only OVERLAY's files onto the staging site. Preserve all existing data/assets.
python patch/tools/patch_collector.py --input CURRENT_TOOLS/ingest.mjs --output REVIEWED_TOOLS/ingest.mjs
python patch/tools/stamp_build.py STAGING_SITE release-20261124-reviewed
python patch/tools/readiness_gate.py STAGING_SITE --mode package
python patch/tools/readiness_gate.py STAGING_SITE --mode supply
python tests/ui_recovery.py --site STAGING_SITE --output ui-results
python tests/journey.py --site STAGING_SITE --output journey-results.json
python tests/current_contracts.py --site STAGING_SITE --output contracts-results.json
python tests/run_regressions.py --site STAGING_SITE --cases tests/inherited --output regression-results
node tests/governance.mjs
node tests/controller.mjs
python tests/tools_test.py
python tests/benchmark_test.py
python benchmark/score.py --directory benchmark/input --output benchmark-result.json
```

Requirements: Python, Playwright, BeautifulSoup4, Node and installed Chromium. Tests use `/usr/bin/chromium`; adjust that path if necessary. The local harness blocks external requests and explicitly bridges mounted local files and synthetic provider responses. It is not a live benchmark. A browser engine other than Chromium remains untested here.

## Visitor-facing behaviour to retain

One light theme. One primary search form: place, dates, radius, Find. Filters open a vertically scrolling, wrapping modal. Saved events have a clear return path. Tools contain map, calendar export, subscription link, source evidence and retained planning controls. Technical boards remain outside normal visitor flow. A thin-results state never claims that no events exist locally.

Cards retain actual occurrence identity. The detail dialog shows sourced facts and direct links, without guessed venue amenities, urgency, demand or arrival rules. A missing image remains an honest mascot fallback. The original T-rex is branding, not a background animation system.

No page-wide horizontal clipping to conceal inaccessible controls. No forced reload during search. No unscoped cache deletion. No generic catalogue exploration during a consumer search. No population-derived completeness score. No high-recall badge without independent measurement.

## Mandatory live acceptance record

For Geneva, Berlin, Paris, a non-European city and Meilen, record: exact URL and build, selected place ID and coordinates, destination timezone, date interval, radius, active filters, source request/response status, source records, unique admitted occurrences, date/geo/policy removals, filtered occurrences and rendered cards. Use Menu > Sources and search evidence > Export. Attach console/network evidence for failures that JavaScript cannot distinguish.

Repeat with slow network, offline transition, blocked provider, healthy retry, cold/warm cache, returning service worker, background-tab restoration and rapid place changes. Save an event, open its detail, go back, open filters and scroll. Ensure the keyboard does not cover the primary action, native pickers remain usable, focus is restored and the page does not jump.

## Remaining work, not hidden by passing tests

The supplied nightly index is empty and the stored main snapshot is Zurich-area data. Populate approved non-Zurich supply and verify final-origin readers. The patch does not manufacture that inventory. Automatic venue probing has hard coverage limits and must not be substituted for maintained primary venue programmes and authorised broad feeds.

The collector still has a global 20-hour run lock and adaptive per-venue intervals. Audit its allocation and retry semantics with realistic partial-run fixtures. The local HTTP 451 generated by policy is still described as a publisher error in the legacy source receipt. Fix that attribution rather than retrying a deliberately blocked source.

Inherited test P24 expects a city-file timestamp to become the publisher observation. The recovery deliberately returns unknown publisher observation and keeps that timestamp separately as `snapshotAt`. Do not restore the unsafe conflation simply to make the old test green. The new provenance tests validate this distinction.
