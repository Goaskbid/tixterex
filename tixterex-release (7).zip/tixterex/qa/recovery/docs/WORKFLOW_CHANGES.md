# Deployment and collection are different jobs

Basis: the uploaded `tixterex (1).yml`, not live GitHub Actions logs. No repository setting, secret, DNS record or deployed workflow was changed by this audit.

| Location in supplied YAML | Old behaviour | Required new behaviour | Reason |
|---|---|---|---|
| Lines 77-89 | Release archives are used only when repository `site/index.html` is absent. All ZIPs are merged and the first matching site is selected. | Choose repository or a specific release tag explicitly. Read only the release manifest's exact site/place assets. Fail on competing main HTML or mismatched hashes. | A newer release can otherwise be ignored or mixed with another source tree. |
| Lines 116-129 | Collection is skipped under 20 hours; collection failure is non-fatal. | Preserve the previous valid snapshot; record collection status separately. Mark an initial empty or wholly failed collection unready. Do not rewrite a successful-observation timestamp on failure. | Deployment success does not demonstrate fresh event supply. |
| Lines 149-152 | Replace `__TF_BUILD__` even though the shipped release embeds a hardcoded build ID. | Use the robust stamp tool on HTML, worker and version JSON together. | Prevent metadata divergence and automatic reloads. |
| Line 168 | GitHub-only public-output gate errors become warnings. | Fail the package gate before uploading. Report supply and benchmark gates separately. | A public site must not publish missing or private assets merely because the host is GitHub. |
| Lines 181-186 | Save collection state even after failed work. | Save a validated last-good state plus failure metadata; do not replace it with an empty or corrupt working copy. | Avoid making a temporary provider problem persistent. |
| Lines 251-256 | Broad release, run and cache deletion. | Do not delete diagnostic evidence during recovery. Later scope retention to this workflow's named artifacts and caches. | Keep rollback and failure evidence. |

Replace placeholder-only stamping with the following after assembly, using the reviewed recovery worker:

```yaml
- name: Stamp and validate assembled package
  run: |
    python3 tools/recovery/stamp_build.py _site "${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"
    python3 tools/recovery/readiness_gate.py _site --mode package --output package-health.json
- name: Report collection health separately
  run: |
    python3 tools/recovery/readiness_gate.py _site --mode supply --output supply-health.json
```

Copy the two reviewed Python scripts into `tools/recovery/`. Decide explicitly whether a failed supply gate blocks a production rollout or allows a labelled UI-only staging deployment that retains current production inventory. Do not hide it with a generic `continue-on-error` and then describe the run as coverage-ready.

Do not run broad collection in a browser request. Do not create an unauthenticated open proxy. Keep collection separate from static delivery, run it only in the authorised operating environment, validate publisher permissions, retain per-source checkpoints and publish immutable, scoped results with observation times. No hosting or cost guarantee is made by these snippets. The existing shared Cloudflare/GitHub plan remains an owner decision, not something this patch silently replaces.
