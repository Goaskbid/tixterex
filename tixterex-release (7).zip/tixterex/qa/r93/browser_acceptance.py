from pathlib import Path
import sys,json,argparse
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'qa/recovery/tests'))
from local_harness import load
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
checks=[]
def check(name,value):checks.append(dict(name=name,pass_=bool(value)));print(name,value,flush=True)
def fixtures(url):
 if 'opendatasoft' in url:return {'body':'{"results":[],"total_count":0}','type':'application/json'}
 if 'overpass' in url:return {'body':'{"elements":[]}','type':'application/json'}
 if 'wikidata' in url:return {'body':'{"results":{"bindings":[]}}','type':'application/json'}
 if 'wikipedia' in url or 'commons.wikimedia' in url:return {'body':'{"query":{"pages":{}}}','type':'application/json'}
 if 'eventsimple.de/api/events' in url:return {'body':'{"events":[],"total":0,"count":0,"truncated":false}','type':'application/json'}
 return None
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [320,390,430,768,1440]:
  ctx=b.new_context(viewport={'width':width,'height':844},is_mobile=width<768,has_touch=width<768,color_scheme='dark',timezone_id='America/New_York',service_workers='block')
  page,errors,calls=load(ctx,ROOT/'site',fixtures=fixtures);page.clock.set_system_time('2026-11-25T05:10:00Z')
  check(f'{width}: starts at top',page.evaluate('scrollY===0'))
  check(f'{width}: static animations',page.evaluate('document.getAnimations().filter(x=>x.playState==="running").length===0'))
  check(f'{width}: no jungle rendered',page.evaluate('!document.querySelector("#ttJungle")||getComputedStyle(document.querySelector("#ttJungle")).display==="none"'))
  page.evaluate("()=>{document.getElementById('when').value='fortnight';document.getElementById('radius').value='20';window.__done=false;runSearch({name:'New York City',city:'New York City',cc:'US',country:'US',lat:40.714,lon:-74.006,timeZone:'America/New_York'}).finally(()=>__done=true)}")
  page.wait_for_function('__done',timeout=30000);page.evaluate('TTReviewedProgrammes.run()');page.wait_for_timeout(1000)
  info=page.evaluate('''()=>({events:state.events.map(e=>({title:e.title,start:e.start,cat:e.cat,observedAt:e.observedAt,source:e.source,url:e.url,reviewed:e.reviewedSnapshot})),receipt:TTReviewedProgrammes.receipt,recovery:TTRecovery.receipt(),overflow:document.documentElement.scrollWidth>innerWidth+1,rows:document.querySelectorAll('#grid article.tix').length,scrolling:[...document.querySelectorAll('body *')].filter(e=>e.getClientRects().length&&['auto','scroll'].includes(getComputedStyle(e).overflowX)&&e.scrollWidth>e.clientWidth+1).map(e=>e.id||e.className)})''')
  (a.output/f'{width}-nyc.json').write_text(json.dumps(info,indent=2,default=str))
  check(f'{width}: 22 real dated snapshot occurrences',len(info['events'])==22)
  check(f'{width}: sports present',any(e['cat']=='sport' for e in info['events']))
  check(f'{width}: concerts present',any(e['cat']=='music' for e in info['events']))
  check(f'{width}: Hamilton present',any(e['title']=='Hamilton' for e in info['events']))
  check(f'{width}: source observations not refreshed on reading',all(e['observedAt'] for e in info['events']))
  check(f'{width}: page has no horizontal overflow',not info['overflow'])
  check(f'{width}: no horizontal scroll containers',not info['scrolling'])
  page.screenshot(path=str(a.output/f'{width}-nyc.png'))
  page.evaluate('scrollTo(0,650)');page.wait_for_timeout(200)
  check(f'{width}: back-to-top visible',page.locator('#ttBackTop').is_visible())
  pos=page.evaluate('scrollY');page.evaluate("dispatchEvent(new Event('tf:inventory-updated'))");page.wait_for_timeout(250)
  check(f'{width}: repaint preserves scrolling',abs(page.evaluate('scrollY')-pos)<2)
  page.locator('#ttBackTop').click();page.wait_for_timeout(150);check(f'{width}: button returns to top',page.evaluate('scrollY===0'))
  page.evaluate("scrollTo(0,500);dispatchEvent(new PageTransitionEvent('pageshow',{persisted:true}))");page.wait_for_timeout(150);check(f'{width}: back-cache return starts at top',page.evaluate('scrollY===0'))
  check(f'{width}: one back-to-top button',page.locator('#ttBackTop').count()==1)
  page.locator('#r91FilterCount').click();page.wait_for_timeout(150)
  d=page.evaluate('''()=>{const x=document.querySelector('#r91Filters');return{x:x.getBoundingClientRect().x,right:x.getBoundingClientRect().right,overflow:x.scrollWidth>x.clientWidth+1,children:[...x.querySelectorAll('*')].filter(e=>e.getClientRects().length&&['auto','scroll'].includes(getComputedStyle(e).overflowX)&&e.scrollWidth>e.clientWidth+1).length}}''')
  check(f'{width}: filters fit vertically',d['x']>=0 and d['right']<=width+1 and not d['overflow'] and not d['children'])
  page.keyboard.press('Escape');page.wait_for_timeout(100)
  media=page.evaluate("(()=>{const m={page:'https://commons.wikimedia.org/wiki/File:fixture',kind:'venue'};return [TTComicFast.claimVenueImage(m,'a'),TTComicFast.claimVenueImage(m,'a'),TTComicFast.claimVenueImage(m,'b')]})()")
  check(f'{width}: repeated venue photo restricted to its first event',media==[True,True,False])
  page.clock.set_system_time('2026-12-01T10:00:00Z');page.evaluate('TTReviewedProgrammes.run()');check(f'{width}: stale snapshot expires',page.evaluate("TTReviewedProgrammes.receipt.status==='expired'"))
  check(f'{width}: no uncaught page errors',errors==[])
  ctx.close()
 b.close()
result={'basis':'Chromium actual application, real manually checked NYC records, empty mocked external feeds. Not live network/CORS or recall certification.','passed':sum(x['pass_'] for x in checks),'failed':sum(not x['pass_'] for x in checks),'checks':checks}
(a.output/'summary.json').write_text(json.dumps(result,indent=2));print(result['passed'],result['failed']);raise SystemExit(bool(result['failed']))
