import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import dns from 'node:dns';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'r93-collector-'));
const mode=process.argv[2]||'ny',dest=process.argv[3]||'collector.json';
const city=mode==='ch'?{name:'Zurich',cc:'CH',lat:47.37,lon:8.54,tz:'Europe/Zurich',slug:'zurich-ch',pop:400000}:{name:'New York City',cc:'US',lat:40.714,lon:-74.006,tz:'America/New_York',slug:'new-york-city-us',pop:8800000};
fs.writeFileSync(path.join(dir,'cities.json'),JSON.stringify([city]));
const calls=[];dns.promises.lookup=async()=>[{address:'93.184.216.34',family:4}];
const tomorrow=new Date(Date.now()+864e5).toISOString().slice(0,10);
global.fetch=async input=>{const url=String(input);calls.push(url);const u=new URL(url);let body,headers={'content-type':'application/json'};
 if(u.pathname==='/robots.txt'){body='User-agent: *\nAllow: /\n';headers={'content-type':'text/plain'};}
 else if(u.hostname==='alpglow.ch'){body=JSON.stringify({events:[{id:'fixture-api',title:'Synthetic Alpglow fixture',start:tomorrow+'T20:00:00',lat:47.37,lon:8.54,venue:'Fixture Hall',url:'https://alpglow.ch/e/fixture-api',genre:'concert'}],total:1,truncated:false});}
 else if(u.hostname.includes('wikidata'))body=JSON.stringify({results:{bindings:[]}});
 else if(u.hostname.includes('overpass'))body=JSON.stringify({elements:[]});
 else {const kind=/barclays|madison/.test(url)?'SportsEvent':/hamilton|wicked|opernhaus|maag|radio-city/.test(url)?'TheaterEvent':'MusicEvent';body='<html><script type="application/ld+json">'+JSON.stringify({'@type':kind,name:'Synthetic primary '+u.hostname+u.pathname,startDate:tomorrow+'T19:00:00Z',url:u.origin+'/event/synthetic-'+u.pathname.replaceAll('/','-'),location:{'@type':'Place',name:'Fixture venue',geo:{'@type':'GeoCoordinates',latitude:city.lat,longitude:city.lon}}})+'</script></html>';headers={'content-type':'text/html'};}
 return new Response(body,{status:200,headers});
};
process.argv=['node','fixture','--out',path.join(dir,'out'),'--cities',path.join(dir,'cities.json'),'--only-city',city.slug,'--max-requests','50','--max-minutes','.4','--artist-share','0'];
const mod=await import('../../tools/ingest.mjs');const result=await mod.run();const record=JSON.parse(fs.readFileSync(path.join(dir,'out/cities',city.slug+'.json')));
const checks=[];const check=(name,pass)=>checks.push({name,pass:!!pass});
check('focused city written',record.city.slug===city.slug);check('primary targets survive without Overpass',record.venues.filter(v=>v.pinned).length===(mode==='ch'?6:8));
check('no first-pass map request',!calls.some(u=>u.includes('overpass')));check('no first-pass Wikidata event sweep',!calls.some(u=>u.includes('wikidata')));
check('actual primary programmes persisted',Object.entries(record.events).filter(([k,v])=>k.startsWith('priority:')&&v.length>0).length===(mode==='ch'?6:8));
check('sports,stage,music supply reporting exists',!!record.categorySupply&&record.categorySupply.topEventRecall===null);
check('pinned read receipts persisted',record.categorySupply.prioritySources.every(s=>s.status==='read'&&s.n>0));
check('index contains collected occurrences',result.totals.events>0);check('request budget enforced',result.run.requests<=50);
check('spatial tile written',fs.existsSync(path.join(dir,'out/near',Math.floor(city.lat/5)+'_'+Math.floor(city.lon/5)+'.json')));
if(mode==='ch'){check('Alpglow actually invoked by collector, not just registered',calls[0]?.startsWith('https://alpglow.ch/api/events?'));check('Alpglow actual normalized record persisted',record.events.alpglow?.length===1);check('Alpglow attribution persisted',record.feeds.alpglow.licence.includes('Alpglow'));}
else {check('New York all three critical categories present', ['sport','stage','music'].every(k=>record.categorySupply.categories[k]>0));check('primary MSG first request',calls[0]?.startsWith('https://www.msg.com/'));}
const report={basis:'Actual run(), safe transport, primary parsers and publication path; synthetic HTTP responses and public-DNS fixture. No external publisher contact.',passed:checks.filter(x=>x.pass).length,failed:checks.filter(x=>!x.pass).length,checks,calls,index:result,city:record};fs.writeFileSync(dest,JSON.stringify(report,null,2));console.log(JSON.stringify({mode,passed:report.passed,failed:report.failed,requests:result.run.requests,occurrences:result.totals.events},null,2));fs.rmSync(dir,{recursive:true,force:true});process.exitCode=report.failed?1:0;
