from pathlib import Path
import sys,json,os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent/'evidence/extra';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(Path(__file__).resolve().parent));from local_harness import load
checks=[]
def ck(name,value,expected=True):
 ok=value==expected;checks.append({'name':name,'actual':value,'expected':expected,'pass':ok});print(('PASS ' if ok else 'FAIL ')+name+' '+str(value)[:300],flush=True)
def fixtures(u):
 if 'opendatasoft' in u:return {'body':'{"results":[],"total_count":0}','type':'application/json'}
 if 'overpass' in u:return {'body':'{"elements":[]}','type':'application/json'}
 if 'wikidata' in u:return {'body':'{"results":{"bindings":[]}}','type':'application/json'}
 if 'wikipedia' in u or 'commons.wikimedia' in u:return {'body':'{"query":{"pages":{}}}','type':'application/json'}
 if 'eventsimple.de/api/events' in u:return {'body':'{"events":[],"total":0,"count":0,"truncated":false}','type':'application/json'}
 return None
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in [int(x) for x in os.environ.get('TEST_WIDTHS','320,390,1440').split(',')]:
  c=b.new_context(viewport={'width':width,'height':900},color_scheme='dark',is_mobile=width<700,has_touch=width<700,timezone_id='America/New_York',service_workers='block');p,errs,calls=load(c,ROOT/'site',fixtures=fixtures);p.set_default_timeout(7000)
  p.clock.set_system_time('2026-11-25T05:10:00Z')
  p.evaluate("()=>{window.__done=false;runSearch({name:'New York City',city:'New York City',cc:'US',country:'US',lat:40.714,lon:-74.006,timeZone:'America/New_York'}).finally(()=>__done=true)}")
  p.wait_for_function('__done',timeout=30000);p.evaluate('TTReviewedProgrammes.run()');p.wait_for_timeout(500)
  p.locator('#grid .tf-butler').first.click();p.locator('.r95-planner>summary').click();p.wait_for_timeout(800)
  ck(f'{width} original planner sections',p.evaluate("['tix','day','wx','exp','food','go','park','dress','chk','venue','share'].every(k=>!!document.querySelector('.r95-planner .b19-'+k))"))
  ck(f'{width} no invented venue bar',not p.locator('.r95-planner').inner_text().find('Foyer bar opens')>=0)
  ck(f'{width} weather state available',p.locator('.r95-planner #b19Wx').count(),1)
  ck(f'{width} checklist restored',p.locator('.r95-planner .b19-check input').count()>0)
  ck(f'{width} share controls restored',p.locator('.r95-planner #b19Copy').count(),1)
  ck(f'{width} route links restored',p.locator('.r95-planner a[href*="maps/dir"]').count()>=1)
  ck(f'{width} planner fits',p.evaluate("(()=>{const e=document.getElementById('r91Event');return e.scrollWidth<=e.clientWidth+1})()"))
  p.screenshot(path=str(OUT/f'{width}-planner.png'))
  p.keyboard.press('Escape');p.locator('#btnSettings').click();p.locator('#r95AdvancedSettings>summary').click();p.wait_for_timeout(150)
  ck(f'{width} API configuration reachable',p.locator('#setTm').is_visible())
  ck(f'{width} settings fits',p.evaluate("(()=>{const e=document.querySelector('#settings .mcard');const r=e.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1&&e.scrollWidth<=e.clientWidth+1})()"))
  p.screenshot(path=str(OUT/f'{width}-settings.png'));p.keyboard.press('Escape')
  p.locator('#r91Menu').click();p.locator('#r91Debug>summary').click();p.wait_for_timeout(100)
  ck(f'{width} original source log accessible',p.locator('#r91DebugBody').is_visible())
  ck(f'{width} menu fits',p.evaluate("(()=>{const e=document.getElementById('r91Tools');return e.scrollWidth<=e.clientWidth+1})()"))
  p.locator('#r95WelcomeOpen').click();p.wait_for_timeout(100)
  ck(f'{width} original welcome artwork accessible',p.locator('#r95Welcome #tfIntro .tt-jungle').is_visible())
  ck(f'{width} welcome fits',p.evaluate("(()=>{const e=document.getElementById('r95Welcome');return e.scrollWidth<=e.clientWidth+1})()"))
  p.screenshot(path=str(OUT/f'{width}-welcome.png'));p.keyboard.press('Escape')
  ck(f'{width} no uncaught errors',errs,[])
  c.close()
 b.close()
r={'basis':'Actual application with local assets, supplied dated snapshot and mocked/blocked external responses. No live collection.','passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks};(OUT/('summary-'+os.environ.get('TEST_WIDTHS','320,390,1440').replace(',','-')+'.json')).write_text(json.dumps(r,indent=2));print('TOTAL',r['passed'],r['failed']);sys.exit(bool(r['failed']))
