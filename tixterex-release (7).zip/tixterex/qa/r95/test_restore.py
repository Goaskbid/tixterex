from pathlib import Path
import sys,json,hashlib,zipfile,subprocess,re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent/'evidence/final';OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(Path(__file__).resolve().parent));from local_harness import load
import os
WIDTHS=[int(x) for x in os.environ.get("TEST_WIDTHS","320,390,430,768,1440").split(",")]
checks=[]
def ck(name,actual,expected=True):
 ok=actual==expected;checks.append(dict(name=name,actual=actual,expected=expected,passed=ok));print(('PASS ' if ok else 'FAIL ')+name+' '+str(actual)[:250],flush=True)
def fixtures(u):
 if 'opendatasoft' in u:return {'body':'{"results":[],"total_count":0}','type':'application/json'}
 if 'overpass' in u:return {'body':'{"elements":[]}','type':'application/json'}
 if 'wikidata' in u:return {'body':'{"results":{"bindings":[]}}','type':'application/json'}
 if 'wikipedia' in u or 'commons.wikimedia' in u:return {'body':'{"query":{"pages":{}}}','type':'application/json'}
 if 'eventsimple.de/api/events' in u:return {'body':'{"events":[],"total":0,"count":0,"truncated":false}','type':'application/json'}
 return None
OVERFLOW='''()=>({page:document.documentElement.scrollWidth>innerWidth+1,scrolls:[...document.querySelectorAll('body *')].filter(e=>{const s=getComputedStyle(e);return e.getClientRects().length&&s.visibility!=='hidden'&&['auto','scroll'].includes(s.overflowX)&&e.scrollWidth>e.clientWidth+1}).map(e=>e.id||String(e.className))})'''
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in WIDTHS:
  c=b.new_context(viewport={'width':width,'height':900},color_scheme='dark',is_mobile=width<700,has_touch=width<700,timezone_id='America/New_York',service_workers='block')
  p,errs,calls=load(c,ROOT/'site',fixtures=fixtures);p.set_default_timeout(7000);p.wait_for_timeout(1800)
  ck(f'{width} starts at top',p.evaluate('scrollY===0'))
  ck(f'{width} original jungle visible',p.evaluate("document.querySelectorAll('#ttJungle .tt-gate').length>=3 && Number(getComputedStyle(document.querySelector('#ttJungle .tt-gate[data-layer=\"0\"]')).opacity)>.4"))
  ck(f'{width} original logo loaded',p.evaluate("brandLogo.naturalWidth>0 && !!brandLogo.dataset.ttl"))
  ck(f'{width} original category panels visible',p.locator('#a16Discover .a16-cats').is_visible())
  ck(f'{width} readable light theme with dark OS',p.evaluate("document.documentElement.dataset.theme==='light' && getComputedStyle(document.body).color==='rgb(11, 34, 70)'"))
  ck(f'{width} no running animations',p.evaluate('document.getAnimations().filter(x=>x.playState==="running").length'),0)
  ov=p.evaluate(OVERFLOW);ck(f'{width} home no sideways overflow',not ov['page'] and not ov['scrolls'])
  p.screenshot(path=str(OUT/f'{width}-home.png'))
  p.clock.set_system_time('2026-11-25T05:10:00Z')
  p.evaluate("()=>{window.__done=false;runSearch({name:'New York City',city:'New York City',cc:'US',country:'US',lat:40.714,lon:-74.006,timeZone:'America/New_York'}).finally(()=>__done=true)}")
  p.wait_for_function('__done',timeout=30000);p.evaluate('TTReviewedProgrammes.run()');p.wait_for_timeout(700)
  ck(f'{width} bundled snapshot unchanged',p.evaluate('state.events.length'),22)
  ck(f'{width} actual event cards rendered',p.locator('#grid article.tix').count(),22)
  ck(f'{width} original rich scene covers',p.locator('#grid .tt-pic').count()>0)
  ov=p.evaluate(OVERFLOW);ck(f'{width} results no sideways overflow',not ov['page'] and not ov['scrolls'])
  p.locator('#r91FilterCount').click();p.wait_for_timeout(150)
  info=p.evaluate("(()=>{const e=document.getElementById('r91Filters'),r=e.getBoundingClientRect();return{fits:r.left>=0&&r.right<=innerWidth+1&&e.scrollWidth<=e.clientWidth+1,focus:e.contains(document.activeElement)}})()")
  ck(f'{width} filter dialog fits',info['fits']);ck(f'{width} filter focus captured',info['focus']);p.screenshot(path=str(OUT/f'{width}-filters.png'))
  p.keyboard.press('Escape');p.wait_for_timeout(150);ck(f'{width} filter focus returned',p.evaluate("document.activeElement.id==='r91FilterCount'"))
  first=p.locator('#grid .tf-butler').first;first.click();p.wait_for_timeout(150)
  ck(f'{width} detail dialog opens',p.locator('#r91Event').is_visible())
  ck(f'{width} original mascot in detail',p.evaluate("!!document.querySelector('#r91Event .r95-detail-art img')"))
  ck(f'{width} details no sideways overflow',p.evaluate("(()=>{const e=document.getElementById('r91Event');return e.scrollWidth<=e.clientWidth+1})()"))
  p.screenshot(path=str(OUT/f'{width}-detail.png'));p.keyboard.press('Escape');p.wait_for_timeout(100)
  if width<=760:
   p.locator('.c12-dock [data-a=filters]').click();ck(f'{width} restored dock filters work',p.locator('#r91Filters').is_visible());p.keyboard.press('Escape')
  p.locator('#grid article.tix').first.scroll_into_view_if_needed();p.wait_for_timeout(300)
  p.screenshot(path=str(OUT/f'{width}-tickets.png'))
  p.evaluate('scrollTo(0,700)');p.wait_for_timeout(200)
  ck(f'{width} back to top visible',p.locator('#ttBackTop').is_visible())
  p.locator('#ttBackTop').click();p.wait_for_timeout(100);ck(f'{width} back to top works',p.evaluate('scrollY===0'))
  ck(f'{width} no page exceptions',errs,[])
  ck(f'{width} no new running animations',p.evaluate('document.getAnimations().filter(x=>x.playState==="running").length'),0)
  c.close()
 b.close()
report={'basis':'Actual R95 application in Chromium using supplied local assets, bundled dated NYC snapshot and blocked or mocked external feeds. Not a live event coverage test.','passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks}
(OUT/('summary-'+ '-'.join(map(str,WIDTHS))+'.json')).write_text(json.dumps(report,indent=2));print('TOTAL',report['passed'],report['failed']);raise SystemExit(bool(report['failed']))
