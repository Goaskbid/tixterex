from pathlib import Path
from urllib.parse import urlsplit,unquote
import json,mimetypes,base64,re,hashlib
FIXED='2026-11-24T18:00:00Z'
def load(ctx,root,html_name='index.html',timers=True,fixtures=None):
 p=ctx.new_page();errors=[];calls=[]
 p.on('pageerror',lambda e:errors.append(str(e)));p.route('**/*',lambda r:r.abort())
 p.clock.set_system_time(FIXED)
 def local(u):
  url=urlsplit(u)
  if fixtures:
   val=fixtures(u)
   if val is not None:
    calls.append({'url':u,'fixture':True,'status':val.get('status',200)})
    return val
  if url.scheme and url.netloc not in ['tixterex.audit.test','tixterex.invalid','']:
   calls.append({'url':u,'external':True});return None
  rel=unquote(url.path).lstrip('/')
  if rel.startswith('repo/'):rel=rel[5:]
  f=Path(root)/rel
  if '..' in Path(rel).parts or not f.is_file():
   calls.append({'url':u,'status':404});return {'status':404,'body':'not found','type':'text/plain'}
  calls.append({'url':u,'local':True,'status':200})
  return {'status':200,'body':base64.b64encode(f.read_bytes()).decode(),'b64':True,'type':mimetypes.guess_type(f)[0] or 'application/octet-stream'}
 p.expose_function('__auditFile',local)
 p.expose_function('__auditDigest',lambda xs:list(hashlib.sha256(bytes(xs)).digest()))
 p.evaluate("if(!crypto.subtle)Object.defineProperty(crypto,'subtle',{value:{digest:async(a,b)=>Uint8Array.from(await __auditDigest([...new Uint8Array(b)])).buffer}})")
 p.evaluate('''timers=>{if(!timers)setInterval=()=>0;const m={};Object.defineProperty(window,'localStorage',{value:{getItem:k=>m[k]??null,setItem:(k,v)=>m[k]=String(v),removeItem:k=>delete m[k],clear:()=>Object.keys(m).forEach(k=>delete m[k]),key:i=>Object.keys(m)[i],get length(){return Object.keys(m).length}}});window.fetch=async(input,opt={})=>{const u=String(input instanceof Request?input.url:input);if(opt.signal?.aborted)throw new DOMException('Aborted','AbortError');const v=await window.__auditFile(u);if(!v)throw new TypeError('Network unavailable in offline audit');if(v.delayMs)await new Promise(r=>setTimeout(r,v.delayMs));const body=v.b64?Uint8Array.from(atob(v.body),x=>x.charCodeAt(0)):v.body;return new Response(body,{status:v.status,headers:{'content-type':v.type}})}}''',timers)
 html=(Path(root)/html_name).read_text()
 # Inline only the existing local pictures for a visually faithful offline render. No external image lookup.
 def sub(m):
  f=Path(root)/m[2]
  if f.is_file() and f.suffix in ['.png','.webp','.svg','.jpg']:
   return m[1]+'data:'+(mimetypes.guess_type(f)[0] or 'image/png')+';base64,'+base64.b64encode(f.read_bytes()).decode()
  return m[0]
 html=re.sub(r'''(["'(])((?:img/[a-zA-Z0-9_./-]+|favicon-32|icon-192|icon-512|apple-touch-icon|icon)\.(?:svg|png|webp|jpg))(?=["')])''',sub,html)
 rex={f.stem:'data:image/webp;base64,'+base64.b64encode(f.read_bytes()).decode() for f in (Path(root)/'img/rex').glob('*.webp')}
 logos={f.stem:'data:image/webp;base64,'+base64.b64encode(f.read_bytes()).decode() for f in (Path(root)/'img/logos').glob('*.webp')}
 html=html.replace('<head>','<head><script>window.__TF_REX='+json.dumps(rex)+';window.__TF_LOGOS='+json.dumps(logos)+';</script>',1)
 # set_content has an opaque origin. Treat the synthetic local-file origin as same-site,
 # exactly as production's location.hostname check would. No external permission is changed.
 origin_bridge='''<script>if(window.TFPolicy){const original=TFPolicy.verdict;TFPolicy.verdict=function(input){try{const u=new URL(input,'https://tixterex.invalid/');if(['tixterex.invalid','tixterex.audit.test'].includes(u.hostname))return{ok:true,why:'same site'};}catch(_){}return original(input)}}</script>'''
 html=re.sub(r'(<script id="tf-a33-policy">[\s\S]*?</script>)',lambda m:m[0]+origin_bridge,html,count=1)
 p.set_content(html,wait_until='domcontentloaded');p.wait_for_timeout(1200)
 return p,errors,calls
