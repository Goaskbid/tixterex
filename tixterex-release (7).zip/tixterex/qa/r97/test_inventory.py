from pathlib import Path
import importlib.util,json,tempfile,unittest,sys,copy
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('assembly',ROOT/'tools/release/assemble.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def event(id,status=None):return {'id':id,'title':id,'start':'2026-12-01T19:00:00Z','observedAt':'2026-11-20T10:00:00Z',**({'status':status} if status else {})}
def doc(at,groups,complete=()):return {'city':{'slug':'test-ch','name':'Test','lat':47.3,'lon':8.5,'cc':'CH'},'at':at,'venues':[],'feeds':{k:{'name':k,'at':at,'n':len(v),'enumerationComplete':k in complete} for k,v in groups.items()},'events':groups}
class Inventory(unittest.TestCase):
 def merge(self,a,b):return m.merge_city(a,b,[],'test-ch')
 def test_missing_source_retained(self):
  a=doc(100,{'theatre':[event('A')],'sport':[event('B')]});b=doc(200,{'theatre':[event('C')]});r=self.merge(a,b);self.assertEqual(set(r['events']),{'theatre','sport'});self.assertEqual(r['events']['sport'][0]['id'],'B')
 def test_partial_source_union(self):self.assertEqual({x['id'] for x in self.merge(doc(100,{'a':[event('1')]}),doc(200,{'a':[event('2')]}))['events']['a']},{'1','2'})
 def test_complete_source_replaces(self):self.assertEqual(self.merge(doc(100,{'a':[event('1')]}),doc(200,{'a':[event('2')]},['a']))['events']['a'],[event('2')])
 def test_complete_empty_is_respected(self):self.assertEqual(self.merge(doc(100,{'a':[event('1')]}),doc(200,{'a':[]},['a']))['events']['a'],[])
 def test_unconfirmed_empty_keeps_observation(self):
  r=self.merge(doc(100,{'a':[event('1')]}),doc(200,{'a':[]}));self.assertEqual(len(r['events']['a']),1);self.assertEqual(r['feeds']['a']['at'],100)
 def test_failed_refresh_cannot_reuse_old_complete_flag(self):
  b=doc(200,{'a':[]},['a']);b['feeds']['a']['error']='HTTP 503';r=self.merge(doc(100,{'a':[event('1')]}),b);self.assertEqual(len(r['events']['a']),1);self.assertEqual(r['feeds']['a']['at'],100)
 def test_failed_status_cannot_clear_good_records(self):
  b=doc(200,{'a':[]},['a']);b['feeds']['a']['status']='failed';self.assertEqual(len(self.merge(doc(100,{'a':[event('1')]}),b)['events']['a']),1)
 def test_explicit_retirement_overrides_old_error(self):
  b=doc(200,{'a':[]});b['feeds']['a'].update(retired=True,error='old error');self.assertEqual(self.merge(doc(100,{'a':[event('1')]}),b)['events']['a'],[])
 def test_older_source_cannot_overwrite(self):
  a=doc(200,{'a':[event('new')], 'b':[]});b=doc(300,{'a':[event('old')]},['a']);b['feeds']['a']['at']=100;r=self.merge(a,b);self.assertEqual(r['events']['a'][0]['id'],'new')
 def test_cancel_update_same_id(self):
  r=self.merge(doc(100,{'a':[event('1')]}),doc(200,{'a':[event('1','EventCancelled')]}));self.assertEqual(len(r['events']['a']),1);self.assertEqual(r['events']['a'][0]['status'],'EventCancelled')
 def test_retired_source_empty(self):
  b=doc(200,{'a':[]});b['feeds']['a']['retired']=True;self.assertEqual(self.merge(doc(100,{'a':[event('1')]}),b)['events']['a'],[])
 def test_invalid_snapshot_time_does_not_crash(self):self.assertEqual(self.merge(doc(100,{'a':[event('1')]}),doc('not-a-time',{'a':[]}))['events']['a'],[event('1')])
 def test_iso_timestamp(self):self.assertGreater(m.numeric_stamp('2026-11-25T00:00:00Z'),0)
 def test_nonfinite_time(self):self.assertEqual(m.numeric_stamp('NaN'),0);self.assertEqual(m.numeric_stamp('inf'),0)
 def test_bad_metadata_rejected(self):
  d=doc(100,{});d['feeds']=['wrong'];self.assertFalse(m.valid_city(d,'test-ch'))
 def test_coordinate_zero_accepted(self):
  d=doc(100,{});d['city'].update(lat=0,lon=0);self.assertTrue(m.valid_city(d,'test-ch'))
 def test_coordinate_boolean_rejected(self):
  d=doc(100,{});d['city']['lat']=False;self.assertFalse(m.valid_city(d,'test-ch'))
 def test_assembly_indexes_orphan_city(self):
  with tempfile.TemporaryDirectory() as t:
   site=Path(t)/'site';cache=Path(t)/'cache';m.write(cache/'cities/test-ch.json',doc(100,{'a':[event('1')]}));r=m.merge_inventory(site,cache);self.assertEqual(r['cities'],1);self.assertTrue((site/'data/ingest/near/9_1.json').exists())
 def test_base_path_idempotent(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'index.html').write_text('<a href="/tixterex/about.html">A</a><a href="/about.html">B</a><script>const p="/api";</script>');m.write(p/'site.webmanifest',{'icons':[{'src':'/tixterex/icon.png'}]});m.apply_base(p,'/tixterex/','https://u.github.io/tixterex/');self.assertNotIn('/tixterex/tixterex/',(p/'index.html').read_text());self.assertEqual(m.read(p/'site.webmanifest')['icons'][0]['src'],'/tixterex/icon.png');self.assertIn('const p="/api"',(p/'index.html').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
