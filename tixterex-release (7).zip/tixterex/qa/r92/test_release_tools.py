from pathlib import Path
import importlib.util,json,tempfile,copy,zipfile,sys,subprocess
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent/'evidence';OUT.mkdir(exist_ok=True)
def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
mod=load('assemble',ROOT/'tools/release/assemble.py');verify=load('verify',ROOT/'tools/release/verify_inputs.py');tests=[]
def ck(name,ok,detail=None):tests.append({'name':name,'pass':bool(ok),'detail':detail})
def doc(at=100,count=1):return {'city':{'slug':'test-fr','name':'Test','cc':'FR','lat':48.8,'lon':2.3},'at':at,'venues':[],'feeds':{'official':{'name':'Official','at':90,'n':count}},'events':{'official':[{'title':'Fixture','start':'2026-12-01T19:00:00Z','observedAt':'2026-11-01T10:00:00Z'} for _ in range(count)]}}
with tempfile.TemporaryDirectory() as td:
 t=Path(td);site=t/'site';cache=t/'cache';base=site/'data/ingest';(base/'cities').mkdir(parents=True);(cache/'cities').mkdir(parents=True)
 def reset(a,b):
  mod.write(base/'index.json',{'cities':[]});mod.write(base/'cities/test-fr.json',a);mod.write(cache/'cities/test-fr.json',b)
 reset(doc(100),doc(200,2));r=mod.merge_inventory(site,cache)
 ck('newer valid inventory from prior cache preserved',r['occurrences']==2)
 ck('orphaned city file is indexed',r['cities']==1)
 ck('spatial lookup tile rebuilt',(base/'near/9_0.json').exists())
 saved=mod.read(base/'cities/test-fr.json');ck('publisher observation unchanged',saved['events']['official'][0]['observedAt']=='2026-11-01T10:00:00Z')
 reset(doc(100),doc(200,0));r=mod.merge_inventory(site,cache);ck('failed empty cache does not erase last good data',r['occurrences']==1)
 complete=doc(300,0);complete['feeds']['official']['enumerationComplete']=True;reset(doc(100),complete);r=mod.merge_inventory(site,cache);ck('explicit complete empty refresh is respected',r['occurrences']==0)
 reset(doc(200,2),doc(100,1));r=mod.merge_inventory(site,cache);ck('older cached data cannot replace newer release inventory',r['occurrences']==2)
 bad=doc(300,3);bad['city']['lat']=None;reset(doc(100),bad);r=mod.merge_inventory(site,cache);ck('invalid cached city is rejected',r['occurrences']==1)
 (site/'index.html').write_text('<a href="/about.html">About</a><script>const sample="/example";</script>');mod.write(site/'site.webmanifest',{'icons':[{'src':'/icon-192.png'}]});mod.apply_base(site,'/repo','https://owner.github.io/repo/')
 ck('project subpath applied to navigation','href="/repo/about.html"' in (site/'index.html').read_text())
 ck('script example strings untouched','const sample="/example"' in (site/'index.html').read_text())
 manifest=mod.read(site/'site.webmanifest');ck('PWA scope stays within project',manifest['scope']=='/repo/' and manifest['icons'][0]['src']=='/repo/icon-192.png')
 archive=t/'bad.zip'
 for name in ['tixterex/../../evil','/tmp/evil','other/site/index.html']:
  with zipfile.ZipFile(archive,'w') as z:z.writestr(name,'bad')
  try:verify.extract(archive,t/'unpack');rejected=False
  except ValueError:rejected=True
  ck('unsafe ZIP member rejected: '+name,rejected)
 symlink=zipfile.ZipInfo('tixterex/link');symlink.external_attr=(0o120777<<16)
 with zipfile.ZipFile(archive,'w') as z:z.writestr(symlink,'/etc/passwd')
 try:verify.extract(archive,t/'unpack');rejected=False
 except ValueError:rejected=True
 ck('symlink ZIP member rejected',rejected)
 workflow=(ROOT/'.github/workflows/tixterex.yml').read_text()
 ck('workflow selects exact release files','--pattern "$ASSET"' in workflow and "--pattern '*.zip'" not in workflow)
 ck('workflow does not silently prefer old repository site','if [ ! -f site/index.html ]' not in workflow)
 ck('workflow has no broad GitHub crawl invocation','run: node tools/ingest.mjs' not in workflow and '--max-requests 3000' not in workflow)
 ck('workflow keeps diagnostic artifacts','actions/upload-artifact@v4' in workflow and 'supply-health.json' in workflow)
 ck('workflow does not delete existing releases/caches','gh release delete' not in workflow and 'gh api -X DELETE' not in workflow)
 ck('workflow does not clear DNS','dnsclear' not in workflow)
 ck('workflow reports empty supply separately','EVENT SUPPLY NOT READY' in workflow)
 ck('canonical source rebuild is deterministic',subprocess.run([sys.executable,str(ROOT/'tools/build_site.py'),'--check'],capture_output=True).returncode==0)
result={'passed':sum(x['pass'] for x in tests),'failed':sum(not x['pass'] for x in tests),'tests':tests};(OUT/'release-tools-tests.json').write_text(json.dumps(result,indent=2));print(result['passed'],result['failed']);sys.exit(bool(result['failed']))
