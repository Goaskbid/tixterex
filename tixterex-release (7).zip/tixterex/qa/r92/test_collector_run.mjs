import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import dns from 'node:dns';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tt-r92-collector-'));
const city={name:'Paris',cc:'FR',lat:48.8566,lon:2.3522,tz:'Europe/Paris',slug:'paris-fr',pop:2000000};
fs.writeFileSync(path.join(dir,'cities-config.json'),JSON.stringify([city]));fs.mkdirSync(path.join(dir,'out/cities'),{recursive:true});
fs.writeFileSync(path.join(dir,'out/ledger.json'),JSON.stringify({lastRun:Date.now()})); // The previous implementation froze this empty state for 20h.
fs.writeFileSync(path.join(dir,'out/index.json'),JSON.stringify({cities:[],totals:{events:0}}));
const calls=[];dns.promises.lookup=async()=>[{address:'93.184.216.34',family:4}];
const tomorrow=new Date(Date.now()+86400000).toISOString().slice(0,10);
global.fetch=async(input)=>{const url=String(input);calls.push(url);let body={};
 if(url.includes('opendata.paris.fr'))body={total_count:1,results:[{id:'fixture-paris-1',title:'Synthetic Paris collector acceptance event',date_start:tomorrow+'T18:00:00+01:00',date_end:tomorrow+'T20:00:00+01:00',url:'https://paris.example/fixture',address_name:'Fixture Hall',address_city:'Paris',lat_lon:{lat:48.8566,lon:2.3522},occurrences:JSON.stringify([{start:tomorrow+'T18:00:00+01:00',end:tomorrow+'T20:00:00+01:00'}])}]};
 else if(url.includes('overpass'))body={elements:[]};else if(url.includes('wikidata'))body={results:{bindings:[]}};
 return new Response(JSON.stringify(body),{status:200,headers:{'content-type':'application/json'}});
};
process.argv=['node','acceptance-test','--out',path.join(dir,'out'),'--cities',path.join(dir,'cities-config.json'),'--max-requests','25','--max-minutes','.05','--artist-share','0'];
const mod=await import('../../tools/ingest.mjs');
const result=await mod.run();const cityFile=JSON.parse(fs.readFileSync(path.join(dir,'out/cities/paris-fr.json')));
const checks=[
 {name:'recent empty run is retried',pass:!result.run?.skipped},
 {name:'official Paris feed is first network request',pass:!!calls[0]?.includes('opendata.paris.fr')},
 {name:'official feed occurrence persisted to city',pass:cityFile.events['fr-paris']?.length===1},
 {name:'index counts persisted occurrence',pass:result.totals.events===1},
 {name:'run counts persisted occurrence',pass:result.run.events===1},
 {name:'city spatial tile created',pass:fs.existsSync(path.join(dir,'out/near/9_0.json'))},
 {name:'requests stay below cap',pass:result.run.requests<=25},
 {name:'first feed completed before any venue discovery',pass:calls.findIndex(x=>x.includes('opendata.paris.fr'))<calls.findIndex(x=>x.includes('overpass'))}
];
const out={basis:'Actual collector and parsers with synthetic publisher responses and stubbed public DNS. No external websites contacted.',passed:checks.filter(x=>x.pass).length,failed:checks.filter(x=>!x.pass).length,checks,result,calls};
fs.writeFileSync(new URL('./evidence/collector-integration.json',import.meta.url),JSON.stringify(out,null,2));
console.log(JSON.stringify({passed:out.passed,failed:out.failed,firstRequests:calls.slice(0,3)},null,2));fs.rmSync(dir,{recursive:true,force:true});process.exitCode=out.failed?1:0;
