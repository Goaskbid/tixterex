# TixTerex R93: source and mobile repair

## Upload
1. Keep the R92 build/test/deploy workflow. A copy is supplied as tixterex.yml. Replace the existing .github/workflows/tixterex.yml only if the older nightly-crawl workflow is still installed. Do not enable two deploy workflows.
2. Publish a new GitHub release with these three attachments, unextracted: tixterex-release.zip, tixterex-places-1.zip, tixterex-places-2.zip. The place ZIPs are unchanged and still required. The release trigger selects the exact tag.
3. The source backup is optional, not a fourth required release attachment.

## What this is
An integrated repair based on R92, not instructions for another programmer. UI source rebuilds exactly. All modifications are in the source backup. No live site, credentials, DNS, billing or repository were changed here.

## Mobile and navigation
The main page is light before its first paint. The animation layer is off, including card animations. All filters wrap vertically. Category highlight cards that duplicate the same events no longer precede the actual list. A 44px Back to top action appears after scrolling. Initial loads and browser back-cache returns start at the top. Results repaint does not move the user. Common top/back-to-top code also accompanies 35 static HTML pages.

## Sources actually connected to collection
The collector reads tools/calendar_sources.json and inserts its priority venues before open-map discovery. It preserves last-good programmes and the existing 3,000-request/20-minute ceiling. New York has MSG, Barclays, Hamilton's producer, Wicked's producer, Beacon, Radio City, Lincoln Center and Carnegie Hall. Zurich has Hallenstadion, MAAG, Opernhaus, Tonhalle, Kaufleuten and Rote Fabrik. Similar primary targets are Southbank Centre, Royal Albert Hall, Sydney Opera House, United Center and Scotiabank Arena. A primary URL in the queue is not proof that its current HTML exposes all dates. Carnegie's waiting room and dynamic producer calendars remain explicit risks, not bypassed access controls.

Alpglow: documented GET /api/events, one Swiss city, next 14 days, limit 50. Exact event links and attribution retained. Photos and descriptions are not copied. Missing coordinates are held rather than placed at the town centre. Unknown schema is an error, not an empty successful calendar. Truncated/unknown enumeration stays partial and preserves prior observations. The documentation was read; a live API JSON response could not be fetched in this environment, so schema and final-origin transport remain unqualified.

Oazis: retained as a lead to original producers. Its terms prohibit mass scraping. MAAG and Hallenstadion upstream sources are connected instead. Bulk Oazis access needs a partner agreement. The Broadway League table is likewise not bulk-scraped; its terms restrict automated reuse. No blanket permission is fabricated.

## Real New York data included
site/data/reviewed-programmes.json holds 22 individual dated performances checked against MSG, Barclays and authorized Broadway.com performance pages on 25 November 2026: 7 sports, 4 concerts and 11 stage performances (including four Hamilton performances). These are manual source observations, not a completed live crawl or a representative benchmark. They are separate from the existing inventory and do not overwrite newer collected events. Their freshness expires after 72 hours; the UI then excludes them. Expired event starts are excluded as time advances. Publisher changes still require refreshing the source.

## Images
Permitted event images win. A venue photo is used only for the first matching occurrence rather than repeated across a page. Remaining cards use varied category/pose artwork labelled Illustration. No new rights to real event photographs were obtained. This prevents inaccurate generic photos, not magically obtaining every poster.

## Running real collection
GitHub remains build/test/deploy only. On the approved collection machine, from the extracted source directory:

    python tools/collect_snapshot.py --city "New York City" --retry
    python tools/collect_snapshot.py --city "Zurich" --retry

Use the exact configured name or slug (the Swiss city is named Zuerich with an umlaut in tools/ingest_cities.json, so the collector also matches its normalized Zurich form). Collection writes tixterex-inventory.zip only when there are collected occurrences. Attach that inventory ZIP alongside the three release files for publication. There is no approved always-on collection runtime activated in this delivery. The code change alone does not schedule nightly refresh. It introduces no proxy, paid service or secret. API keys for existing Ticketmaster and other authorized integrations remain operator-controlled.

## Acceptance
TEST_REPORT.json counts completed tests only. The dedicated R93 browser suite covers 320, 390, 430, 768 and 1440 pixels under dark operating-system preference. External network responses in collector tests are fixtures. The real reviewed New York snapshot passes through the actual app. The 100% top-event / 75% public-event benchmark is still unmeasured. Source counts, fixtures and 22 example performances cannot establish it.
