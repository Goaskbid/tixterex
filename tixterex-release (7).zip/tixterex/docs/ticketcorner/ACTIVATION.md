# Ticketcorner: two different connections

## Implemented visitor subscription route

The Menu contains a direct link to the official Ticketcorner newsletter subscription page:
https://www.ticketcorner.ch/campaign/ticketcorner-newsletter/

No visitor is subscribed automatically. No email address or account credential is sent by this patch. Ticketcorner handles the subscription and its own consent process.

## Operator data / affiliate integration

Official partner information, checked 24 November 2026:
https://www.b2b.ticketcorner.ch/produkte-services/affiliate-partner

The page describes a free partnership after review. It requests direct shop links, not internal redirects, and directs automated link integration enquiries to redaktion@ticketcorner.ch. This does not establish unrestricted access to a public event API or permission to copy images.

`partner-config.DISABLED.json` is deliberately inactive. No feed URL, credential, approval or schema has been invented. Obtain the actual approved delivery channel and sample before writing a production adapter. Keep provider credentials on the approved server/collector, not in the public HTML or GitHub artifact.

The feed mapping must preserve publisher occurrence ID, event-series ID, performance start with timezone, all-day/time-unknown distinction, end time, cancellation/reschedule status, venue ID and coordinates, room/language/format, official ticket URL, availability observation, price/currency basis, image-specific reuse permission and attribution, and source observation timestamp. Do not label partner data CC0. Do not add Ticketcorner wholesale to a permissive domain allowlist merely because an affiliate link works.

The recovery link decorator preserves explicitly configured partner parameters on direct Ticketcorner links. It refuses an internal redirect-template route. It does not invent affiliate IDs or generic tracking tags.

## Draft request, not sent

To: redaktion@ticketcorner.ch
Subject: TixTerex: partner application and authorised event-data integration

Hello Ticketcorner team,

I operate TixTerex, an event-discovery website based in Switzerland. I would like to apply for your affiliate programme and discuss authorised automated integration of your event listings and direct ticket links.

Please confirm the available feed or API, onboarding process, permitted commercial use, geographic and category coverage, refresh limits, stable occurrence identifiers, cancellation and reschedule updates, and whether event artwork may be displayed with attribution. A current sample payload and pagination or delivery documentation would let us implement the integration correctly.

We will use direct Ticketcorner links without an internal redirect and keep any private credentials outside our public website files. Please also identify any required attribution and approved affiliate parameters.

Best regards,
Torsten Sauter
TixTerex
