@echo off
cd /d "%~dp0"
python tools\collect_snapshot.py --city "New York City" --retry
if errorlevel 1 (echo Collection did not complete. No ready inventory is implied. & pause & exit /b 1)
echo Upload tixterex-inventory.zip with the release.
pause
