/* Scope-owned caches only. A sibling GitHub Pages project is not this application's cache. */
const BUILD='r97-quality-20261125';
const SCOPE=new URL(self.registration.scope).pathname;
const PREFIX='tixterex:'+encodeURIComponent(SCOPE)+':';
const CACHE=PREFIX+BUILD;
const SHELL=['./','index.html','site.webmanifest','icon-192.png','icon-512.png'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(async c=>{await Promise.all(SHELL.map(async p=>{try{const u=new URL(p,self.registration.scope),r=await fetch(u,{cache:'reload'});if(r.ok)await c.put(u,r);}catch(_){}}));}));/* No forced activation while a search is open. */});
self.addEventListener('message',event=>{if(event.data?.type==='ACTIVATE_UPDATE')self.skipWaiting();});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{const r=event.request,u=new URL(r.url),base=new URL(self.registration.scope);
 if(r.method!=='GET'||u.origin!==base.origin||!u.pathname.startsWith(base.pathname)||u.pathname.endsWith('/version.json'))return;
 const image=/\.(png|webp|svg|ico)$/.test(u.pathname);const localAsset=image||/\/data\/(?:places|localities|places-near)\//.test(u.pathname)||u.pathname.endsWith('/data/places.json');
 event.respondWith((async()=>{const c=await caches.open(CACHE);if(image){const hit=await c.match(r);if(hit)return hit;}
  try{const res=await fetch(r,{cache:'no-cache'});if(res.ok&&(r.mode==='navigate'||localAsset))await c.put(r,res.clone());return res;}
  catch(error){const hit=await c.match(r);if(hit)return hit;if(r.mode==='navigate'){const shell=await c.match(new URL('index.html',self.registration.scope));if(shell)return shell;}return Response.error();}
 })());
});
self.addEventListener('push',event=>{let m={};try{m=event.data?.json()||{};}catch(_){}let u=new URL('./',self.registration.scope);try{const p=new URL(m.url,self.registration.scope);if(p.origin===u.origin&&p.pathname.startsWith(SCOPE))u=p;}catch(_){}
 event.waitUntil(self.registration.showNotification(String(m.title||'TixTerex: new event').slice(0,120),{body:String(m.body||'Open TixTerex for details.').slice(0,300),icon:new URL('icon-192.png',self.registration.scope).href,tag:String(m.tag||'tixterex-follow'),data:{url:u.href}}));});
self.addEventListener('notificationclick',event=>{event.notification.close();let target=new URL('./',self.registration.scope);try{const u=new URL(event.notification.data?.url);if(u.origin===target.origin&&u.pathname.startsWith(SCOPE))target=u;}catch(_){}
 event.waitUntil(self.clients.matchAll({type:'window'}).then(async pages=>{for(const page of pages)if(page.url.startsWith(self.registration.scope)){await page.navigate(target.href);return page.focus();}return self.clients.openWindow(target.href);}));});
