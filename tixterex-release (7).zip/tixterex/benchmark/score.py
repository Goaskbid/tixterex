#!/usr/bin/env python3
"""Score independently collected evidence. Missing evidence remains unmeasured, never zero.
Matching pairs are human-adjudicated. This script verifies structure, not the truth of an adjudication.
Use a simple random sample of the documented public-event frame for the Wilson interval.
"""
import argparse,json,math,hashlib
from pathlib import Path
from datetime import date
from zoneinfo import ZoneInfo

def wilson(k,n,z=1.95996398454):
 if not n:return None
 p=k/n;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
 return [max(0,c-h),min(1,c+h)]

def city_score(directory,city):
 files=[directory/(city+'.'+suffix+'.json') for suffix in ['truth','observed','matches']]
 if not all(f.exists() for f in files):return {'city':city,'status':'unmeasured','topRecall':None,'publicSampleRecall':None,'precision':None,'missing':[f.name for f in files if not f.exists()]}
 truth,obs,mapping=[json.loads(f.read_text()) for f in files]
 if truth.get('scope')!=obs.get('scope'):raise ValueError(city+': search scopes differ')
 scope=truth.get('scope') or {}
 if any(k not in scope for k in ['place','centre','radius','timezone','startDate','endDate']):raise ValueError(city+': incomplete query scope')
 if (date.fromisoformat(scope['endDate'])-date.fromisoformat(scope['startDate'])).days!=13:raise ValueError(city+': expected 14 inclusive local dates')
 try:ZoneInfo(scope['timezone'])
 except Exception as e:raise ValueError(city+': invalid destination timezone') from e
 if not isinstance(scope['radius'],(int,float)) or isinstance(scope['radius'],bool) or scope['radius']<=0:raise ValueError(city+': invalid radius')
 if not truth.get('independentSources') or truth.get('topVenueInventoryComplete') is not True:raise ValueError(city+': independent top-venue ground-truth evidence absent')
 sampling=truth.get('sampling',{})
 if sampling.get('design')!='simple_random_without_replacement' or not sampling.get('frameDescription') or sampling.get('seed') is None:raise ValueError(city+': unsupported or undocumented sampling design')
 tops=truth.get('top',[]);sample=truth.get('publicSample',[])
 for label,items in [('top',tops),('publicSample',sample)]:
  if len({e['id'] for e in items})!=len(items):raise ValueError(city+': duplicate '+label+' truth IDs')
 combined={}
 for e in tops+sample:
  if e['id'] in combined and combined[e['id']]!=e:raise ValueError(city+': conflicting repeated truth occurrence')
  combined[e['id']]=e
 seen={e['id']:e for e in obs.get('events',[])};alltruth={e['id']:e for e in tops+sample}
 if not tops or not sample or len(seen)!=len(obs.get('events',[])):raise ValueError(city+': empty ground truth or duplicate observed IDs')
 if any(not e.get('sourceUrl') or not e.get('start') or not e.get('venue') for e in alltruth.values()):raise ValueError(city+': truth lacks occurrence evidence')
 pairs=mapping.get('pairs',[]);matched=set();used=set()
 for p in pairs:
  if p['truthId'] not in alltruth or p['observedId'] not in seen or p['truthId'] in matched or p['observedId'] in used or p.get('adjudicated') is not True:raise ValueError(city+': invalid, duplicate or unadjudicated pair')
  matched.add(p['truthId']);used.add(p['observedId'])
 reasons=mapping.get('missReasons',{});missed=[e for e in tops if e['id'] not in matched]
 if any(not reasons.get(e['id']) for e in missed):raise ValueError(city+': missed top event has no reason')
 k=sum(e['id'] in matched for e in sample);n=len(sample);ci=wilson(k,n);tk=sum(e['id'] in matched for e in tops)
 precisionRows=mapping.get('precisionSample',[]);precision=None
 if precisionRows:
  if len({e['observedId'] for e in precisionRows})!=len(precisionRows):raise ValueError(city+': duplicate precision sample ID')
  ps=mapping.get('precisionSampling',{})
  if ps.get('design')!='simple_random_without_replacement' or ps.get('seed') is None or not ps.get('frameDescription'):raise ValueError(city+': undocumented precision sampling design')
  if any(e.get('observedId') not in seen or not isinstance(e.get('validOccurrence'),bool) for e in precisionRows):raise ValueError(city+': invalid precision sample')
  pk=sum(e['validOccurrence'] for e in precisionRows);pn=len(precisionRows);precision={'sample':pn,'estimate':pk/pn,'ci95':wilson(pk,pn)}
 return {'city':city,'status':'measured_against_documented_frame','topRecall':tk/len(tops),'topFound':tk,'topTotal':len(tops),'publicSampleRecall':k/n,'publicSampleSize':n,'publicSampleCi95':ci,'precision':precision,'pointTargetMet':tk==len(tops) and k/n>=.75,'conservativeGateMet':tk==len(tops) and ci[0]>=.75,'missedTopEvents':[{'id':e['id'],'title':e.get('title'),'reason':reasons[e['id']]} for e in missed],'evidenceSha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files},'scope':truth['scope'],'limitation':'Public sample estimates the stated sampling frame. It does not prove that the frame contains every public event.'}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--directory',type=Path,required=True);p.add_argument('--cities',type=Path,default=Path(__file__).with_name('cities.json'));p.add_argument('--output',type=Path,required=True);a=p.parse_args();rows=[]
 for c in json.loads(a.cities.read_text()):
  try:rows.append(city_score(a.directory,c['id']))
  except (ValueError,KeyError,TypeError,OSError) as e:rows.append({'city':c['id'],'status':'invalid_evidence','error':str(e)})
 result={'schema':'tixterex-10075/1','cities':rows,'measured':sum(r['status']=='measured_against_documented_frame' for r in rows),'unmeasured':sum(r['status']=='unmeasured' for r in rows),'claimReady':all(r.get('conservativeGateMet') for r in rows),'basis':'No population proxy, source-count proxy, synthetic fixtures or provider-only denominator.'};a.output.write_text(json.dumps(result,indent=2));print(result['measured'],result['unmeasured'],result['claimReady'])
