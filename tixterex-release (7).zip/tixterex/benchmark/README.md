# What 100/75 must mean

100% means every independently enumerated top-event occurrence within a fixed place, radius and 14-day local-date window. Include every performance at the city's declared top venues and major festivals. An empty venue list is not a 100% result.

75% means a measured recall estimate against an independently assembled public-event frame, with a stated random sampling method and confidence interval. A directory of sources, population estimate, venue count, number of records emitted or one provider's own catalogue is not this denominator.

The 24-place list covers six inhabited continents and includes Meilen as the small-town candidate. Verify its population criterion against a current official source before treating that requirement as satisfied. None of the 24 has a completed live benchmark in this delivery.

Use the same fixed 14-day window for all cities, expressed in each destination's local dates. For the initial recovery comparison use 24 November to 7 December 2026 inclusive. Re-freeze the window for a later actual live run; never compare a new production search with old ground truth.

## Input contract per city

Create `<city>.truth.json`, `<city>.observed.json` and `<city>.matches.json` in `input/`.

Truth must contain `scope` (place, centre, radius in kilometres, timezone, startDate, endDate), `independentSources`, `topVenueInventoryComplete`, arrays `top` and `publicSample`, and `sampling` with design `simple_random_without_replacement`, seed and frameDescription. Each occurrence needs id, title, start, venue and sourceUrl. Save the primary-source evidence independently of TixTerex. Record the publisher time, retrieved time and a content hash in the evidence archive.

Observed must contain the IDENTICAL scope and `events` with unique IDs, exported from the final production-origin interface, not just an acquisition adapter. Include active filters and the visible-result stage counts.

Matches must contain reviewed `pairs` of truthId, observedId and adjudicated=true. Each missed top truth ID needs an explicit `missReasons` value. Optional `precisionSample` items contain observedId and validOccurrence; include `precisionSampling` with design `simple_random_without_replacement`, seed and frameDescription. The scorer rejects duplicate IDs within each sample and conflicting occurrence evidence. An occurrence may appear in both top and public samples only with identical evidence. Human adjudication must verify title/performer, performance time, venue, room and language. This script cannot establish that a human's match decision is correct.

The scorer reports top recall, public-sample recall, a 95% Wilson interval, precision when labelled evidence is supplied, missed-top reasons and hashes of all three inputs. The point target is 100% / at least 75%. The separately labelled conservative release gate requires the public-sample lower confidence bound to be at least 75%. This is stricter than merely obtaining a 75% point estimate.

A sample estimates its frame. It does not prove the frame contains every informal/publicly advertised event. Describe omissions such as poster-only or private-platform-only programmes rather than hiding them.

## Acquisition work before the benchmark

Connect approved market-level supply where available, then complete each declared top venue's primary programme with per-source pagination and update handling. Add independent city calendars for community, library, museum, food and small-venue events. Keep cinema showtimes as performance occurrences, not a single film listing. Keep sports fixtures tied to actual local venues. Retain every missed top event as a repair task with a specific cause: source absent, access unavailable, unqualified rights, parsing, time/location, dedupe, freshness, filter or rendering.

Run the same collection limits and client search settings as production. Never increase limits just for the benchmark. Export source request counts and per-source continuation state. A passing city is not evidence that unmeasured cities pass.
