#!/usr/bin/env python3
"""Rebuild the exact reviewed application from canonical source. No network or dependencies."""
from pathlib import Path
import argparse,json,hashlib,re

def build(root:Path,check=False):
 src=root/'src';manifest=json.loads((src/'manifest.json').read_text());text=(src/'page.html.in').read_text()
 for part in manifest['parts']:
  if text.count(part['marker'])!=1:raise ValueError('Missing/duplicate source marker: '+part['marker'])
  file=src/part['path']
  if src.resolve() not in file.resolve().parents:raise ValueError('Source path escapes src')
  text=text.replace(part['marker'],part['open']+file.read_text()+part['close'])
 if '<!--TT-SOURCE:' in text:raise ValueError('Unresolved source marker')
 target=root/'site/index.html'
 if check:
  if target.read_text()!=text:raise ValueError('site/index.html differs from canonical source. Rebuild before release.')
 else:target.write_text(text)
 return {'sha256':hashlib.sha256(text.encode()).hexdigest(),'bytes':len(text.encode()),'parts':len(manifest['parts']),'reproducible':True}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--check',action='store_true');a=p.parse_args();print(json.dumps(build(a.root,a.check),indent=2))
