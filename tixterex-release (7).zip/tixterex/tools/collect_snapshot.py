#!/usr/bin/env python3
"""Run the capped local collector and package its actual output for the release workflow."""
from pathlib import Path
import argparse, json, os, subprocess, sys, zipfile
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--state',type=Path,default=ROOT/'collection-state');p.add_argument('--cities',type=Path,default=ROOT/'tools/ingest_cities.json');p.add_argument('--output',type=Path,default=ROOT/'tixterex-inventory.zip');p.add_argument('--retry',action='store_true');p.add_argument('--city',default='',help='Exact city name or slug; comma-separated supported');a=p.parse_args()
 if os.environ.get('GITHUB_ACTIONS')=='true':raise SystemExit('This launcher does not run third-party collection on GitHub. Use an approved local/collection environment.')
 a.state.mkdir(parents=True,exist_ok=True)
 cmd=['node',str(ROOT/'tools/ingest.mjs'),'--out',str(a.state.resolve()),'--cities',str(a.cities.resolve()),'--optout',str(ROOT/'site/data/optout.json'),'--partners',str(ROOT/'site/data/partners.json'),'--max-requests','3000','--max-minutes','20','--artist-share','0']
 if a.retry:cmd.append('--force')
 if a.city:cmd+=['--only-city',a.city]
 subprocess.run(cmd,cwd=ROOT,check=True)
 index=json.loads((a.state/'index.json').read_text());count=sum(int(c.get('events') or 0) for c in index.get('cities',[]))
 if count==0:raise SystemExit('Collection produced no event inventory. No inventory ZIP was published. Existing site data remains unchanged; inspect collection-state/index.json.')
 allowed={'index.json','catimg.json'}
 a.output.parent.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(a.output,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
  for f in a.state.rglob('*'):
   if not f.is_file():continue
   rel=f.relative_to(a.state)
   if f.name in allowed or rel.parts[0] in ['cities','near','ics']:
    z.write(f,'tixterex/site/data/ingest/'+rel.as_posix())
 print(f'Created {a.output}. {count} stored occurrences. This is an inventory count, not a recall score.')
