"""Build the static, indexable layer of tixterex.com from the published data.

python3 tools/build_seo.py <site_dir> [--base https://tixterex.com] [--logo logo.png]

Writes, next to index.html:
  events/index.html, events/<town>/index.html  one crawlable page per town with events,
                                               each with schema.org Event JSON-LD
  sitemap.xml, robots.txt, site.webmanifest, og.png, icon-192.png, icon-512.png,
  apple-touch-icon.png, favicon-32.png
Facts only (title, date, time, place, link to the publisher). Past events are dropped at
build time; rebuild whenever data/ changes. Nothing here fetches anything.
"""
import html, json, math, re, sys, unicodedata
from datetime import datetime, timezone, timedelta
from pathlib import Path

SITE = Path(sys.argv[1] if len(sys.argv) > 1 else "site")
ARGS = sys.argv[2:]
BASE = ARGS[ARGS.index("--base") + 1].rstrip("/") if "--base" in ARGS else "https://tixterex.com"
LOGO = Path(ARGS[ARGS.index("--logo") + 1]) if "--logo" in ARGS else None
NOW = datetime.now(timezone.utc)
if "--now" in ARGS: NOW = datetime.fromisoformat(ARGS[ARGS.index("--now") + 1])
TOWNS = [("Zürich", 47.37689, 8.54169, 9), ("Winterthur", 47.49988, 8.72413, 8), ("Meilen", 47.26952, 8.64412, 5),
         ("Küsnacht", 47.31871, 8.58401, 4), ("Uster", 47.34713, 8.72091, 6), ("Thalwil", 47.29527, 8.56346, 4),
         ("Horgen", 47.25983, 8.59778, 5), ("Wädenswil", 47.22683, 8.66870, 5), ("Dübendorf", 47.39724, 8.61872, 4),
         ("Kloten", 47.45152, 8.58491, 5), ("Rapperswil-Jona", 47.22557, 8.81670, 6), ("Stäfa", 47.24216, 8.72331, 4)]
CAT = [("sport", "Sport", "⚽"), ("stage", "Theatre & opera", "🎭"), ("music", "Concerts", "🎵"), ("festival", "Festivals & markets", "🎪"),
       ("food", "Food & brunch", "🥐"), ("family", "Family", "🧸"), ("other", "More", "✨")]


def slug(s):
    s = unicodedata.normalize("NFKD", s.replace("ü", "ue").replace("ä", "ae").replace("ö", "oe")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def km(a, b, c, d):
    r = math.pi / 180
    x = math.sin((c - a) * r / 2) ** 2 + math.cos(a * r) * math.cos(c * r) * math.sin((d - b) * r / 2) ** 2
    return 12742 * math.asin(math.sqrt(x))


def cat_of(e):
    t = " ".join(str(e.get(k) or "") for k in ("cat", "title", "venue", "source")).lower()
    if e.get("cat") in {c for c, _, _ in CAT}: return e["cat"]
    for c, rx in (("sport", r"fc |vs\b| – |hockey|lions|stadion|letzigrund|arena"), ("festival", r"festival|markt|market|noël|zauber|weinschiff|expovina"),
                  ("food", r"brunch|dinner|food|wein"), ("stage", r"oper|ballett|theater|schauspiel|bühne|pfauen|schiffbau"),
                  ("music", r"konzert|concert|orchester|tonhalle|requiem|quartet|trio"), ("family", r"kinder|family|famil")):
        if re.search(rx, t): return c
    return "other"


OPEN_LICENCE = re.compile(r"(cc0|public domain|pddl|cc[- ]?by(?![- ]?(nc|non))|odbl|open database|licence ouverte|open licen[cs]e|etalab|\bogl\b|open government|dl-de|ogdl|daten: eventsimple)", re.I)


# A34 facts-only tier: a publisher's own calendar, bare facts only, linked back; never a third-party compilation,
# never a publisher who opted out (data/optout.json). Mirrors a33_policy.js.
NOT_OWN = re.compile(r"(^|\.)(localcities\.ch|allevents\.in|eventfrog\.(ch|de|at|it|fr)|eventbrite\.[a-z.]+|meetup\.com|facebook\.com|instagram\.com|songkick\.com|bandsintown\.com|ra\.co|residentadvisor\.net|dice\.fm|skiddle\.com|seatgeek\.com|stubhub\.[a-z.]+|viagogo\.[a-z.]+|ticketcorner\.ch|eventim\.[a-z.]+|seetickets\.[a-z.]+|ticketswap\.[a-z.]+|timeout\.com|google\.[a-z.]+|bookmyshow\.com|district\.in|insider\.in|ticketek\.[a-z.]+|moshtix\.com\.au|oztix\.com\.au|eplus\.jp|t\.pia\.jp|l-tike\.com|peatix\.com|damai\.cn|maoyan\.com|interpark\.com|yes24\.com|kktix\.com|tixcraft\.com|sistic\.com\.sg|klook\.com|sympla\.com\.br|eventim\.com\.br|passline\.com|joinnus\.com|boletia\.com|livenation\.[a-z.]+|axs\.com|universe\.com|lu\.ma|luma\.com|partiful\.com|feverup\.com|headout\.com|getyourguide\.[a-z.]+|viator\.com|tiqets\.com|ticketsource\.[a-z.]+|ticketleap\.com|webtickets\.co\.za|quicket\.co\.za|computicket\.com|platinumlist\.net|kakaku\.com|yelp\.[a-z.]+|ticketportal\.[a-z.]+|ticketone\.it|entradas\.com|fnacspectacles\.com|billetreduc\.com|ticketswap\.[a-z.]+|tripadvisor\.[a-z.]+|archive\.org|osmcal\.org)$")


def _optout():
    try: return {h.lower().removeprefix("www.") for h in json.loads((SITE / "data" / "optout.json").read_text()).get("hosts", [])}
    except Exception: return set()


OPTOUT = _optout()


def _partners():
    try: return {h.lower().removeprefix("www.") for h in json.loads((SITE / "data" / "partners.json").read_text()).get("hosts", [])}
    except Exception: return set()


PARTNERS = _partners()


def facts_only(e):
    """Owner rule (16 Nov 2026): facts only from an organiser's own calendar; never third-party platforms or opted-out publishers."""
    from urllib.parse import urlparse
    src = e.get("sourceUrl") or e.get("url") or ""
    h = (urlparse(src).hostname or "").lower().removeprefix("www.")
    return bool(h) and (re.match(r"facts only", str(e.get("licence") or ""), re.I) is not None or any(h == p or h.endswith("." + p) for p in PARTNERS)) and not NOT_OWN.search(h) and not opted_out(h)


def opted_out(h):
    """A89 (audit F18): a publisher's opt-out covers its sub-domains too (tickets.venue.example)."""
    h = (h or "").lower().removeprefix("www.")
    return any(h == p or h.endswith("." + p) for p in OPTOUT)


def source_host(e):
    from urllib.parse import urlparse
    return (urlparse(e.get("sourceUrl") or e.get("url") or "").hostname or "").lower().removeprefix("www.")


def commercially_licensed(e):
    lic = str(e.get("licence") or "")
    if opted_out(source_host(e)): return False   # A89 (audit F18): the publisher's own "no" beats any licence text
    return (bool(OPEN_LICENCE.search(lic)) and not re.search(r"\bnc\b|non.?commercial", lic, re.I)) or facts_only(e)


def load():
    rows = []
    for f in sorted((SITE / "data" / "events").glob("*.json")):
        try: rows += json.loads(f.read_text())["events"]
        except Exception: pass
    seen, out = set(), []
    for e in rows:
        try: start = datetime.fromisoformat(e["start"].replace("Z", "+00:00"))
        except Exception: continue
        if e.get("geoApprox") or e.get("lat") is None: continue
        if not commercially_licensed(e): continue        # owner rule: public pages list only events licensed for commercial display
        if start < NOW - timedelta(hours=3): continue
        key = (e.get("title"), e.get("start"), e.get("venue"))
        if key in seen: continue
        seen.add(key); e["_start"] = start; out.append(e)
    return sorted(out, key=lambda e: e["_start"])


def local(e):
    """A89 (audit F19): the wall-clock time where the event happens. With localStart that is used; otherwise the absolute
    instant is shown in the event's own time zone (Europe/Zurich when none is known) — never shifted by a fixed hour."""
    if e.get("localStart"): return datetime.fromisoformat(e["localStart"])
    try:
        from zoneinfo import ZoneInfo
        return e["_start"].astimezone(ZoneInfo(e.get("timeZone") or "Europe/Zurich"))
    except Exception:
        return e["_start"] + timedelta(hours=1)


def when_text(e):
    d = local(e)
    day = d.strftime("%a %-d %b %Y")
    return day + (" · time to be confirmed" if e.get("dateOnly") or e.get("timeUnresolved") else " · " + d.strftime("%H:%M"))


def status_of(e):
    """A89 (audit F19): the real status reaches Google — cancelled, postponed, rescheduled or moved online."""
    st = str(e.get("eventStatus") or e.get("status") or "")
    if e.get("cancelled") or re.search(r"cancel", st, re.I): return "https://schema.org/EventCancelled"
    if e.get("postponed") or re.search(r"postpon", st, re.I): return "https://schema.org/EventPostponed"
    if re.search(r"reschedul", st, re.I): return "https://schema.org/EventRescheduled"
    if re.search(r"MovedOnline", st, re.I): return "https://schema.org/EventMovedOnline"
    return "https://schema.org/EventScheduled"


def ld_event(e):
    d = local(e)
    start = d.strftime("%Y-%m-%d") if e.get("dateOnly") or e.get("timeUnresolved") else d.isoformat()
    n = {"@type": "Event", "name": e["title"], "startDate": start,
         "eventAttendanceMode": "https://schema.org/OfflineEventAttendanceMode", "eventStatus": status_of(e),
         "location": {"@type": "Place", "name": e.get("venue") or "", "address": e.get("address") or e.get("venue") or "",
                      "geo": {"@type": "GeoCoordinates", "latitude": e["lat"], "longitude": e["lon"]}},
         "url": e.get("url") or e.get("sourceUrl")}
    if e.get("ticketUrl"): n["offers"] = {"@type": "Offer", "url": e["ticketUrl"]}
    if e.get("source"): n["organizer"] = {"@type": "Organization", "name": e["source"], "url": e.get("sourceUrl") or e.get("url")}
    return n


CSS = """.src{padding-left:18px;line-height:1.6}.src a{font-weight:800}:root{--paper:#fff4d6;--card:#fffdf6;--ink:#0b2246;--muted:#4a5875;--gold:#ffc22e;color-scheme:light}
@media (prefers-color-scheme:dark){:root{--paper:#0d1730;--card:#14213f;--ink:#fff4d6;--muted:#b7c2dc;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.5 Nunito,system-ui,-apple-system,"Segoe UI",sans-serif}
.w{max-width:880px;margin:0 auto;padding:20px max(16px,env(safe-area-inset-right)) 48px max(16px,env(safe-area-inset-left))}
header{display:flex;align-items:center;gap:14px;flex-wrap:wrap}header img{height:52px;width:auto}
h1{font:800 clamp(28px,5vw,42px)/1.1 "Baloo 2",system-ui,sans-serif;margin:18px 0 6px;text-shadow:3px 3px 0 var(--gold);text-wrap:balance}
.lede{color:var(--muted);margin:0 0 16px}.cta{display:inline-block;background:var(--gold);color:#0b2246;border:2.5px solid #0b2246;box-shadow:3px 3px 0 #0b2246;border-radius:14px;padding:11px 16px;font-weight:800;text-decoration:none}
nav.cats,nav.towns{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0}nav a{border:2px solid var(--ink);border-radius:999px;padding:7px 12px;color:var(--ink);text-decoration:none;font-weight:700;background:var(--card)}
h2{font:800 20px/1.2 "Baloo 2",system-ui,sans-serif;margin:26px 0 8px;display:inline-block;background:var(--gold);color:#0b2246;border:2.5px solid #0b2246;box-shadow:3px 3px 0 #0b2246;padding:3px 10px;border-radius:6px}
article{display:grid;grid-template-columns:84px 1fr;gap:12px;align-items:center;background:var(--card);border:2.5px solid var(--ink);border-radius:14px;box-shadow:3px 3px 0 var(--ink);padding:10px 12px;margin:10px 0}
.t{font:800 20px/1 "Baloo 2",system-ui,sans-serif;text-align:center}.t small{display:block;font:700 11px/1.3 system-ui;color:var(--muted);text-transform:uppercase}
article h3{margin:0 0 2px;font:800 17px/1.25 "Baloo 2",system-ui,sans-serif}article p{margin:0;color:var(--muted);font-size:14px}article a{color:inherit;font-weight:700}
footer{margin-top:36px;color:var(--muted);font-size:13px}footer a{color:inherit}"""


def page(title, desc, path, body, ld):
    url = BASE + path
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{html.escape(title)}</title><meta name="description" content="{html.escape(desc)}"><link rel="canonical" href="{url}">
<meta property="og:type" content="website"><meta property="og:site_name" content="TixTerex"><meta property="og:title" content="{html.escape(title)}">
<meta property="og:description" content="{html.escape(desc)}"><meta property="og:url" content="{url}"><meta property="og:image" content="{BASE}/og.png">
<meta name="twitter:card" content="summary_large_image"><meta name="theme-color" content="#0b2246"><link rel="icon" href="/favicon-32.png" sizes="32x32"><link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@800&family=Nunito:wght@500;700;800&display=swap">
<style>{CSS}</style><script type="application/ld+json">{json.dumps(ld, ensure_ascii=False)}</script></head>
<body><div class="w"><header><a href="/"><img src="/icon-192.png" alt="TixTerex" width="52" height="52"></a><a class="cta" href="/">Search any town</a></header>{body}
<footer>Dates, times and places as published by each organiser; the link goes to their own page. Built {NOW.strftime('%-d %b %Y')} from the TixTerex snapshot — open the live search for the newest listings. <a href="/legal.html">Sources, licences and privacy</a> · <a href="/terms.html">Terms</a> · © TixTerex. All rights reserved.</footer></div></body></html>"""


def town_page(name, evs, towns_with):
    path = f"/events/{slug(name)}/"
    days, body = {}, []
    for e in evs: days.setdefault(local(e).strftime("%A %-d %B"), []).append(e)
    cats = sorted({cat_of(e) for e in evs})
    body.append(f'<h1>Events in {html.escape(name)}</h1><p class="lede">{len(evs)} upcoming events from venues, clubs and the city — theatre, concerts, sport, festivals and food. Each links to the organiser.</p>')
    body.append(f'<p><a class="cta" href="/?loc={html.escape(name)}">Live search {html.escape(name)} →</a></p>')
    body.append('<nav class="cats" aria-label="Event types">' + "".join(f'<a href="#{c}">{ic} {lab}</a>' for c, lab, ic in CAT if c in cats) + '</nav>')
    firsts = set()
    for day, rows in days.items():
        body.append(f"<h2>{html.escape(day)}</h2>")
        for e in rows:
            d = local(e); tbd = e.get("dateOnly") or e.get("timeUnresolved")
            c = cat_of(e); aid = f' id="{c}"' if c not in firsts else ''; firsts.add(c)
            body.append(f'<article{aid}><div class="t">{"TBA" if tbd else d.strftime("%H:%M")}<small>{d.strftime("%a %-d %b")}</small></div><div><h3>{html.escape(e["title"])}</h3>'
                        f'<p>{html.escape(e.get("venue") or "")}{" · " + html.escape(e["address"]) if e.get("address") else ""}</p>'
                        f'<p><a href="{html.escape(e.get("ticketUrl") or e.get("url") or "")}" rel="noopener">Event page at {html.escape(e.get("source") or "the organiser")}</a></p></div></article>')
    others = [t for t in towns_with if t != name]
    if others: body.append('<h2>Nearby</h2><nav class="towns">' + "".join(f'<a href="/events/{slug(t)}/">{html.escape(t)}</a>' for t in others) + "</nav>")
    ld = {"@context": "https://schema.org", "@graph": [
        {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "TixTerex", "item": BASE + "/"},
                                                         {"@type": "ListItem", "position": 2, "name": "Events", "item": BASE + "/events/"},
                                                         {"@type": "ListItem", "position": 3, "name": name, "item": BASE + path}]},
        {"@type": "ItemList", "name": f"Events in {name}", "itemListElement": [{"@type": "ListItem", "position": i + 1, "item": ld_event(e)} for i, e in enumerate(evs[:100])]}]}
    first = evs[0]["_start"].strftime("%-d %b"); last = evs[-1]["_start"].strftime("%-d %b %Y")
    return path, page(f"Events in {name} — what's on {first}–{last} | TixTerex",
                      f"What's on in {name}: {len(evs)} concerts, plays, matches, festivals and brunches from {first} to {last}, each linked to the organiser.", path, "".join(body), ld)


COUNTRY = {"FR": ("France", "🇫🇷"), "CH": ("Switzerland", "🇨🇭"), "BE": ("Belgium", "🇧🇪"), "CA": ("Canada", "🇨🇦"), "US": ("United States", "🇺🇸"),
           "AU": ("Australia", "🇦🇺"), "NZ": ("New Zealand", "🇳🇿"), "GB": ("United Kingdom", "🇬🇧"), "HK": ("Hong Kong", "🇭🇰"), "LU": ("Luxembourg", "🇱🇺"),
           "IE": ("Ireland", "🇮🇪"), "IT": ("Italy", "🇮🇹"), "DE": ("Germany", "🇩🇪")}
KIND = {"ods": "Opendatasoft open-data portal", "socrata": "Socrata open-data portal", "arcgis": "ArcGIS Hub (council map layers)", "ckan": "CKAN open-data portal"}
QUICK = [("today", "", "Tonight"), ("weekend", "", "This weekend"), ("week", "music", "Concerts this week"), ("week", "stage", "Theatre & shows"),
         ("week", "sport", "Sport & matches"), ("week", "family", "With kids"), ("month", "", "This month")]


def atlas_cities():
    f = SITE / "data" / "atlas" / "atlas.json"
    if not f.exists(): return {}
    a = json.loads(f.read_text()); out = {}
    for pt in a.get("portals", []):
        if pt.get("lat") is None or str(pt.get("status", "")).startswith(("non", "unknown")): continue
        c = out.setdefault(pt["city"], {"cc": pt["cc"], "lat": pt["lat"], "lon": pt["lon"], "portals": []}); c["portals"].append(pt)
    for c in out.values(): c["national"] = [pt for pt in a.get("portals", []) if pt.get("lat") is None and pt["cc"] == c["cc"]]
    return out


def sources_block(name, info):
    """What is genuinely specific to this city: where it publishes its events, and one-tap searches."""
    loc = html.escape(name)
    quick = "".join(f'<a href="/?loc={loc}&amp;when={w}{"&amp;cat=" + c if c else ""}">{html.escape(t)}</a>' for w, c, t in QUICK)
    rows = []
    for pt in info["portals"] + info.get("national", []):
        host = pt.get("domain") or re.sub(r"^https?://", "", pt["base"]).split("/")[0]
        rows.append(f'<li><a href="https://{html.escape(host)}/" rel="noopener">{html.escape(host)}</a> — {KIND.get(pt["type"], "open data")}'
                    f'{" (national)" if pt.get("lat") is None else ""}; searched for “{html.escape(", ".join(pt.get("terms", ["events"])))}”</li>')
    return (f'<h2>Search {loc} now</h2><nav class="cats" aria-label="Quick searches in {loc}">{quick}</nav>'
            f'<h2>Where {loc} publishes its events</h2><p>TixTerex asks these public calendars live from your browser, together with the websites of '
            f'venues on the map, league fixtures for the stadiums and festivals on Wikidata. Dates, places and links come from each publisher, under its own licence.</p><ul class="src">{"".join(rows)}</ul>')


def city_page(name, info, allc):
    path = f"/events/{slug(name)}/"; cname, flag = COUNTRY.get(info["cc"], (info["cc"], ""))
    near = sorted((n for n in allc if n != name and allc[n]["cc"] == info["cc"]), key=lambda n: km(info["lat"], info["lon"], allc[n]["lat"], allc[n]["lon"]))[:8]
    e = html.escape(name)
    body = (f'<h1>Events in {e} — tonight, this weekend and beyond</h1><p class="lede">{flag} {e}, {html.escape(cname)}. Concerts, theatre, '
            f"sport, festivals, markets and family days, read live from the city's own calendars and its venues — each linked to the organiser, "
            f'with tickets, weather, food nearby and the way home.</p><p><a class="cta" href="/?loc={e}">Live search {e} →</a></p>' + sources_block(name, info))
    if near: body += '<h2>More cities in ' + html.escape(cname) + '</h2><nav class="towns">' + "".join(f'<a href="/events/{slug(n)}/">{html.escape(n)}</a>' for n in near) + "</nav>"
    body += '<p><a href="/events/">All cities</a></p>'
    ld = {"@context": "https://schema.org", "@graph": [
        {"@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": 1, "name": "TixTerex", "item": BASE + "/"},
            {"@type": "ListItem", "position": 2, "name": "Events", "item": BASE + "/events/"}, {"@type": "ListItem", "position": 3, "name": name, "item": BASE + path}]},
        {"@type": "WebPage", "name": f"Events in {name}", "url": BASE + path, "isPartOf": {"@id": BASE + "/#site"},
         "about": {"@type": "City", "name": name, "geo": {"@type": "GeoCoordinates", "latitude": info["lat"], "longitude": info["lon"]}, "containedInPlace": {"@type": "Country", "name": cname}}}]}
    return path, page(f"Events in {name} tonight & this weekend | TixTerex",
                      f"What’s on in {name} tonight and this weekend: concerts, theatre, sport and festivals from the city’s own calendars, with tickets and the way home.",
                      path, body, ld)


def assets():
    if not LOGO or not LOGO.exists(): return
    from PIL import Image, ImageDraw
    logo = Image.open(LOGO).convert("RGBA")
    mark = logo.crop((80, 0, 690, 285))                       # the gold ticket with "tf"
    for size, name in ((192, "icon-192.png"), (512, "icon-512.png"), (180, "apple-touch-icon.png"), (32, "favicon-32.png")):
        c = Image.new("RGBA", (size, size), (255, 244, 214, 255)); m = mark.copy(); m.thumbnail((int(size * .92), int(size * .92)))
        c.alpha_composite(m, ((size - m.width) // 2, (size - m.height) // 2)); c.convert("RGB").save(SITE / name, optimize=True)
    og = Image.new("RGBA", (1200, 630), (255, 244, 214, 255)); dr = ImageDraw.Draw(og)
    for y in range(0, 630, 18):
        for x in range(0, 1200, 18): dr.ellipse((x, y, x + 3, y + 3), fill=(11, 34, 70, 22))
    l = logo.copy(); l.thumbnail((760, 420)); og.alpha_composite(l, ((1200 - l.width) // 2, 70))
    try:
        from PIL import ImageFont
        f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 46)
        t = "Every show, match, festival and brunch near you"; w = dr.textlength(t, font=f)
        dr.text(((1200 - w) / 2, 520), t, font=f, fill=(11, 34, 70, 255))
    except Exception: pass
    og.convert("RGB").save(SITE / "og.png", optimize=True)


def main():
    evs = load()
    towns_with, pages = [], []
    groups = {}
    for e in evs:                                   # each event belongs to its nearest town only
        d, name = min((km(la, lo, e["lat"], e["lon"]) / r, n) for n, la, lo, r in TOWNS)
        if d <= 1: groups.setdefault(name, []).append(e)
    for name, *_ in TOWNS:
        if len(groups.get(name, [])) >= 3: towns_with.append(name)
    allc = atlas_cities()
    for name in towns_with:
        path, doc = town_page(name, groups[name], towns_with)
        info = allc.get(name) or {"cc": "CH", "portals": [], "national": [pt for c in allc.values() for pt in c.get("national", []) if pt["cc"] == "CH"][:1]}
        doc = doc.replace('<h2>Nearby</h2>', sources_block(name, info) + '<h2>Nearby</h2>', 1) if '<h2>Nearby</h2>' in doc else doc.replace('<footer>', sources_block(name, info) + '<footer>', 1)   # a town with no neighbours listed still says where it publishes
        out = SITE / path.strip("/") / "index.html"; out.parent.mkdir(parents=True, exist_ok=True); out.write_text(doc); pages.append(path)
    for name, info in allc.items():
        if name in towns_with: continue
        path, doc = city_page(name, info, allc)
        out = SITE / path.strip("/") / "index.html"; out.parent.mkdir(parents=True, exist_ok=True); out.write_text(doc)
        pages.append(path)
    # a town or city page this build did not produce is removed, so nothing stale stays public (e.g. a page whose events lost their licence)
    import shutil
    made = {p.strip("/") for p in pages}
    for d in (SITE / "events").iterdir():
        if d.is_dir() and ("events/" + d.name) not in made and (d / "index.html").exists() and "TixTerex" in (d / "index.html").read_text(errors="ignore"):
            shutil.rmtree(d)
    by = {}
    for t in towns_with: by.setdefault("CH", []).append((t, len(groups[t])))
    for n, info in allc.items():
        if n not in towns_with: by.setdefault(info["cc"], []).append((n, 0))
    hub = "<h1>Events by city</h1><p class=\"lede\">Pick a city for what's on tonight, this weekend and this month — concerts, plays, matches, festivals and brunches — or search any place on earth.</p>" + \
          "".join(f'<h2>{COUNTRY.get(cc, (cc, ""))[1]} {html.escape(COUNTRY.get(cc, (cc, ""))[0])}</h2><nav class="towns">' + "".join(f'<a href="/events/{slug(t)}/">{html.escape(t)}{" · " + str(n) if n else ""}</a>' for t, n in sorted(v)) + "</nav>"
                  for cc, v in sorted(by.items(), key=lambda x: COUNTRY.get(x[0], (x[0],))[0]))
    (SITE / "events").mkdir(exist_ok=True)
    (SITE / "events" / "index.html").write_text(page("Events by city — what's on worldwide | TixTerex", "What's on in cities worldwide: concerts, theatre, sport, festivals and family days, read live from each city's own calendars and venues.", "/events/", hub,
                                                     {"@context": "https://schema.org", "@type": "CollectionPage", "name": "Events by city", "url": BASE + "/events/"}))
    rb = SITE / "robots.txt"   # A62: keep the rights policy (AI-training opt-out) when it is there
    if not (rb.exists() and "terms.html" in rb.read_text()): rb.write_text("User-agent: *\nAllow: /\nDisallow: /data/\n")
    sys.path.insert(0, str(Path(__file__).parent)); import sitemap   # lists every indexable page on disk, keeps lastmod stable
    pages = sitemap.build(SITE, BASE, Path(__file__).with_name("sitemap_state.json"), NOW)
    (SITE / "site.webmanifest").write_text(json.dumps({"name": "TixTerex", "short_name": "TixTerex", "description": "Every show, match, festival and brunch near you.",
        "start_url": "/", "display": "standalone", "background_color": "#fff4d6", "theme_color": "#0b2246",
        "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"}, {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]}, indent=1))
    # a crawlable path from the homepage to every city page (plain links, below the app)
    links = "".join(f'<a href="/events/{slug(n)}/">{html.escape(n)}</a>' for n in sorted(set(towns_with) | set(allc)))
    block = ('<!--tf-cities--><footer id="tfCities" aria-label="Popular cities"><h2>What\'s on in popular cities</h2><nav>' + links +
             '</nav><p><a href="/events/">All cities</a> · <a href="/legal.html">Sources &amp; legal</a></p></footer><!--/tf-cities-->')
    ix = SITE / "index.html"; h = ix.read_text()
    if "<!--tf-cities-->" in h: ix.write_text(re.sub(r"<!--tf-cities-->.*?<!--/tf-cities-->", lambda m: block, h, flags=re.S))
    assets()
    print(json.dumps({"events": len(evs), "townPages": {t: len(groups[t]) for t in towns_with}, "sitemap": len(pages)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
