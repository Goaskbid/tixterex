#!/usr/bin/env python3
"""Exercise the built public site before deployment. External event feeds are controlled test fixtures, not a recall claim."""
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,unquote
import argparse,functools,http.server,json,os,sys,threading,time
from playwright.sync_api import sync_playwright

def fixtures(url):
 u=urlsplit(url);q=parse_qs(u.query)
 if u.hostname=='eventsimple.de' and u.path.startswith('/api/events'):
  lat=float(q.get('lat',['46.2044'])[0]);lon=float(q.get('lng',['6.1432'])[0])
  rows=[{'id':10000+round(lat*100)+i,'title':f'Acceptance fixture {i+1}','starts_at':f'2026-11-{26+i%2:02d}T19:00:00+01:00','ends_at':f'2026-11-{26+i%2:02d}T21:00:00+01:00','all_day':False,'latitude':lat,'longitude':lon,'has_coordinates':True,'venue':f'Fixture hall {i%3}','city':'Fixture city','country':'CH','url':f'https://fixture.example/event/{lat}/{i}','detail_url':f'https://eventsimple.de/event/{10000+i}','category':['concert','theatre','family','cinema'][i%4]} for i in range(8)]
  return {'events':rows,'total':8,'count':8,'truncated':False}
 if 'opendatasoft' in (u.hostname or ''):return {'results':[],'total_count':0}
 if 'overpass' in (u.hostname or ''):return {'elements':[]}
 if u.hostname=='query.wikidata.org':return {'results':{'bindings':[]}}
 if 'wikipedia.org' in (u.hostname or '') or u.hostname=='commons.wikimedia.org':return {'query':{'pages':{}}}
 return None

class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
 def translate_path(self,path):
  url=unquote(urlsplit(path).path)
  base=self.server.mount
  if base!='/' and (url==base.rstrip('/') or url.startswith(base)):url=url[len(base.rstrip('/')):] or '/'
  return super().translate_path(url)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--site',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--offline-harness',action='store_true');ap.add_argument('--widths',default='320,390,430,768,1440');ap.add_argument('--base-path',default='/');args=ap.parse_args()
 args.output.mkdir(parents=True,exist_ok=True);checks=[];errors=[]
 def check(name,actual,expected=True):
  checks.append({'name':name,'actual':actual,'expected':expected,'pass':actual==expected});(args.output/'progress.json').write_text(json.dumps({'status':'running','checks':checks,'errors':errors},indent=2));print(('PASS ' if actual==expected else 'FAIL ')+name,flush=True)
 server=None
 if not args.offline_harness:
  handler=functools.partial(Handler,directory=str(args.site.resolve()));server=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler);server.mount='/' + args.base_path.strip('/')+'/' if args.base_path.strip('/') else '/';threading.Thread(target=server.serve_forever,daemon=True).start()
 with sync_playwright() as pw:
  executable=os.environ.get('PLAYWRIGHT_CHROMIUM_EXECUTABLE')
  if args.offline_harness:executable=executable or '/usr/bin/chromium'
  browser=pw.chromium.launch(**({'executable_path':executable} if executable else {}),args=['--no-sandbox'])
  try:
   for width in [int(x) for x in args.widths.split(',')]:
    context=browser.new_context(viewport={'width':width,'height':844},is_mobile=width<700,has_touch=width<700,color_scheme='dark',timezone_id='Europe/Zurich',service_workers='block')
    page_errors=[]
    if args.offline_harness:
     sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'qa/r95'));from local_harness import load
     def reply(url):
      d=fixtures(url);return {'body':json.dumps(d),'status':200,'type':'application/json'} if d is not None else None
     page,page_errors,_=load(context,args.site,fixtures=reply)
    else:
     def route(r):
      u=urlsplit(r.request.url)
      if u.hostname=='127.0.0.1':return r.continue_()
      data=fixtures(r.request.url)
      if data is not None:return r.fulfill(status=200,body=json.dumps(data),headers={'Content-Type':'application/json','Access-Control-Allow-Origin':'*'})
      return r.abort()
     context.route('**/*',route);context.add_init_script("window.TIXTEREX_POLICY_MODE='commercial';")
     page=context.new_page();page.on('pageerror',lambda e:page_errors.append(str(e)));page.clock.set_system_time('2026-11-25T05:10:00Z')
     page.goto(f'http://127.0.0.1:{server.server_port}'+server.mount,wait_until='domcontentloaded',timeout=30000);page.wait_for_timeout(1500)
    page.set_default_timeout(7000);page.clock.set_system_time('2026-11-25T05:10:00Z')
    page.wait_for_function("document.querySelectorAll('#ttJungle .tt-gate').length>=(innerWidth<=760?3:5) && !!window.TixTerexAudit && typeof runSearch==='function'",timeout=15000)
    check(f'{width}: readable theme despite dark OS',page.evaluate("document.documentElement.dataset.theme==='light' && getComputedStyle(document.body).color==='rgb(11, 34, 70)'"))
    check(f'{width}: restored jungle exists',page.locator('#ttJungle .tt-gate').count()>=(3 if width<=760 else 5))
    check(f'{width}: no running background animation',page.evaluate('document.getAnimations().filter(a=>a.playState==="running").length'),0)
    check(f'{width}: initial top',page.evaluate('scrollY'),0)
    check(f'{width}: no horizontal document overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
    page.screenshot(path=str(args.output/f'{width}-home.png'))
    # The exact failure reported in the screenshot: repeat Find after choosing GPS timezone.
    page.evaluate("()=>{window.__done=false;runSearch({id:'gps:47.269:8.646',name:'My location (Europe/Zurich, near Obermeilen)',city:'Meilen',cc:'CH',country:'CH',lat:47.269,lon:8.646,timeZone:'Europe/Zurich'}).finally(()=>__done=true)}")
    page.wait_for_function('__done && !state.searching',timeout=30000);page.wait_for_timeout(300)
    check(f'{width}: exact point produces fixture results',page.evaluate('state.events.length'),8)
    page.locator('#q').fill('My location (Europe/Zurich, near Obermeilen)');page.locator('#btnGo').click();page.wait_for_function('!state.searching',timeout=30000);page.wait_for_timeout(350)
    check(f'{width}: repeated Find retains exact GPS point',page.evaluate('state.loc?.lat===47.269&&state.loc?.lon===8.646'))
    check(f'{width}: repeated Find retains visible cards',page.locator('#grid article.tix').count(),8)
    page.locator('#grid .tf-save').first.click();page.locator('#r91Saved').click();page.wait_for_timeout(150);check(f'{width}: Saved still works',page.locator('#grid article.tix').count(),1)
    page.locator('#r91Saved').click();page.wait_for_timeout(150);check(f'{width}: return from Saved',page.locator('#grid article.tix').count(),8)
    page.locator('#r91FilterCount').click();page.wait_for_timeout(150)
    check(f'{width}: filters fit viewport',page.evaluate("(()=>{const d=document.getElementById('r91Filters'),r=d.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth+1&&d.scrollWidth<=d.clientWidth+1})()"))
    page.keyboard.press('Escape');check(f'{width}: filter focus returns',page.evaluate("document.activeElement.id==='r91FilterCount'"))
    page.locator('#grid .tf-butler').first.click();page.wait_for_timeout(200);check(f'{width}: restored detail planner accessible',page.locator('.r95-planner>summary').count(),1)
    check(f'{width}: detail fits',page.evaluate("(()=>{const d=document.getElementById('r91Event');return d.scrollWidth<=d.clientWidth+1})()"));page.keyboard.press('Escape')
    page.evaluate('scrollTo(0,700)');page.wait_for_timeout(150);page.locator('#ttBackTop').click();page.wait_for_timeout(150);check(f'{width}: Back to top',page.evaluate('scrollY'),0)
    page.screenshot(path=str(args.output/f'{width}-results.png'));check(f'{width}: no uncaught browser exceptions',page_errors,[])
    context.close()
  except Exception as exc:
   errors.append(str(exc));print(str(exc),file=sys.stderr)
  finally:browser.close()
 if server:server.shutdown()
 report={'basis':'opaque-origin local harness with fetch/storage bridging' if args.offline_harness else 'built site served by a local HTTP server, native browser fetch/storage, controlled external feed fixtures; not live publisher recall','passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'errors':errors,'checks':checks}
 (args.output/'summary.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='checks'}));return 1 if report['failed'] or errors else 0
if __name__=='__main__':sys.exit(main())
