#!/usr/bin/env python3
"""Verify named release parts and extract safely. Refuse arbitrary ZIP merging."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,zipfile,stat
FONT_EXT={'.woff','.woff2','.ttf','.otf','.eot'}
def extract(archive,target,allowed_prefix='tixterex/'):
 with zipfile.ZipFile(archive) as z:
  for item in z.infolist():
   name=PurePosixPath(item.filename);mode=item.external_attr>>16
   if name.is_absolute() or '..' in name.parts or '\\' in item.filename or stat.S_ISLNK(mode):raise ValueError('Unsafe archive member')
   if not item.filename.startswith(allowed_prefix):raise ValueError('Unexpected archive root: '+item.filename)
   if name.suffix.lower() in FONT_EXT:continue
   z.extract(item,target)

def run(directory,output):
 main=directory/'tixterex-release.zip'
 with zipfile.ZipFile(main) as z:manifest=json.loads(z.read('tixterex/BUNDLE_INPUTS.json'))
 for part in manifest['requiredParts']:
  if part['name'] not in ['tixterex-places-1.zip','tixterex-places-2.zip']:raise ValueError('Unexpected part name')
  file=directory/part['name']
  if hashlib.sha256(file.read_bytes()).hexdigest()!=part['sha256']:raise ValueError('Hash mismatch: '+part['name'])
 extract(main,output)
 for part in manifest['requiredParts']:extract(directory/part['name'],output,allowed_prefix='tixterex/site/data/localities/')
 # Optional published collector output is treated as data, never as executable source.
 inventory=directory/'tixterex-inventory.zip'
 if inventory.exists():extract(inventory,output,allowed_prefix='tixterex/site/data/ingest/')
 root=output/'tixterex'
 if not (root/'site/index.html').is_file():raise ValueError('Missing release index')
 return root
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('directory',type=Path);p.add_argument('output',type=Path);a=p.parse_args();print(run(a.directory,a.output))
