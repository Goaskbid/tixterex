#!/usr/bin/env python3
"""Elect one TixTerex publisher and retire only identifiable older duplicates.

Executed by the owner's uploaded workflow with Actions write permission. Does not
edit source, delete workflows, touch other projects, or contact event publishers.
"""
from __future__ import annotations
import base64
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path, PurePosixPath
from urllib.parse import quote

REVISION = 98
MARKER = re.compile(r'^# TIXTEREX_DEPLOY_CONTRACT: r(\d+)\s*$', re.M)
LEGACY_NAMES = {'TixTerex validate and deploy', 'TixTerex nightly programmes and deploy'}
TERMINAL = {'completed'}

class GuardError(RuntimeError):
    pass

def gh_api(method, endpoint):
    args = ['gh', 'api', '--method', method, endpoint, '-H', 'Accept: application/vnd.github+json']
    r = subprocess.run(args, capture_output=True, text=True, timeout=45)
    if r.returncode:
        detail = r.stderr.strip()[:600]
        raise GuardError(f'GitHub {method} {endpoint}: {detail}')
    return json.loads(r.stdout) if r.stdout.strip() else None

class Guard:
    def __init__(self, api, repo, run_id, *, sleep=time.sleep, polls=20):
        if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo):
            raise GuardError('Invalid repository.')
        self.api, self.repo, self.run_id = api, repo, int(run_id)
        self.sleep, self.polls = sleep, polls
        self.report = {'revision':'r98', 'status':'checking', 'publish':False,
                       'disabledDuplicates':[], 'cancelledRuns':[], 'untouched':[], 'errors':[]}

    def call(self, method, suffix):
        return self.api(method, f'repos/{self.repo}/{suffix}')

    def pages(self, endpoint, key):
        rows = []
        for page in range(1, 11):
            sep = '&' if '?' in endpoint else '?'
            data = self.call('GET', f'{endpoint}{sep}per_page=100&page={page}')
            batch = data.get(key, [])
            if not isinstance(batch, list):
                raise GuardError('Unexpected GitHub list response.')
            rows.extend(batch)
            if len(batch) < 100:
                return rows
        raise GuardError('Too many workflows or runs for safe automatic coordination.')

    def source(self, path, sha):
        p = PurePosixPath(path)
        if len(p.parts) != 3 or p.parts[:2] != ('.github','workflows') or p.suffix not in {'.yml','.yaml'}:
            raise GuardError('Unexpected workflow path: '+path)
        data = self.call('GET', 'contents/'+quote(path, safe='/')+'?ref='+quote(sha,safe=''))
        if data.get('type') != 'file' or data.get('encoding') != 'base64':
            raise GuardError('Workflow content cannot be safely identified: '+path)
        body = base64.b64decode(data.get('content',''), validate=False)
        if len(body)>200000:
            raise GuardError('Workflow exceeds inspection size limit.')
        return body.decode('utf-8')

    def current_head(self, branch):
        return self.call('GET','git/ref/heads/'+quote(branch,safe=''))['object']['sha']

    @staticmethod
    def recognized(workflow, text):
        # Require both a known product identity and a real Pages deploy action.
        title_ok = workflow.get('name') in LEGACY_NAMES or workflow.get('name') == 'TixTerex deployment'
        return title_ok and 'TixTerex' in text and bool(re.search(r'uses:\s*actions/deploy-pages@',text))

    def live_runs(self, workflow):
        # Query all nonterminal statuses in one bounded list, so queued/waiting runs are not missed.
        return [r for r in self.pages(f'actions/workflows/{int(workflow)}/runs', 'workflow_runs')
                if r.get('status') not in TERMINAL and int(r.get('id',0)) != self.run_id]

    def run(self):
        me = self.call('GET',f'actions/runs/{self.run_id}')
        branch, sha = me.get('head_branch',''), me.get('head_sha','')
        if me.get('event') not in {'push','workflow_dispatch'} or not branch or not re.fullmatch(r'[a-f0-9]{40,64}',sha):
            raise GuardError('Only a branch push or explicit dispatch can publish.')
        self.report.update(branch=branch, headSha=sha, runId=self.run_id)
        if self.current_head(branch) != sha:
            self.report['status']='superseded';return self.report
        current_id = int(me['workflow_id'])
        workflows = self.pages('actions/workflows','workflows')
        me_wf = next((w for w in workflows if int(w['id'])==current_id), None)
        if me_wf is None:
            raise GuardError('Current workflow is not in the repository workflow list.')
        current_text = self.source(me_wf['path'],sha)
        marker = MARKER.search(current_text)
        if not marker or int(marker[1]) != REVISION:
            raise GuardError('Current workflow is not the R98 repair; no workflow was disabled.')
        candidates=[]; identified=[]
        for w in workflows:
            if w.get('state') != 'active' or w.get('name') not in LEGACY_NAMES|{'TixTerex deployment'}:
                self.report['untouched'].append({'id':w['id'],'path':w.get('path'),'reason':'inactive or other workflow'})
                continue
            text = current_text if int(w['id'])==current_id else self.source(w['path'],sha)
            if not self.recognized(w,text):
                self.report['untouched'].append({'id':w['id'],'path':w.get('path'),'reason':'not an identified TixTerex Pages publisher'})
                continue
            identified.append(w)
            m=MARKER.search(text)
            if m:candidates.append((int(m[1]),w))
        if not candidates:
            raise GuardError('No recognized repair workflow found.')
        newest=max(rev for rev,w in candidates)
        finalists=[w for rev,w in candidates if rev==newest]
        winner=sorted(finalists,key=lambda w:(w['path']!='.github/workflows/tixterex.yml',w['path']!='.github/workflows/tixterex.yaml',w['path']))[0]
        self.report['canonicalPath']=winner['path']
        if int(winner['id'])!=current_id:
            self.report['status']='duplicate_skipped';return self.report
        own_runs=[r for r in self.live_runs(current_id) if r.get('head_branch')==branch]
        if any(int(r['id'])>self.run_id and r.get('head_sha')==sha for r in own_runs):
            self.report['status']='superseded_run';return self.report
        targets=[w for w in identified if int(w['id'])!=current_id]
        for w in targets:
            # Reversible API disable, no workflow file deletion or repository write.
            self.call('PUT',f"actions/workflows/{int(w['id'])}/disable")
            self.report['disabledDuplicates'].append({'id':w['id'],'path':w['path']})
        cancelled=set()
        for attempt in range(self.polls):
            pending=[]
            for w in targets+[winner]:
                active=self.live_runs(w['id'])
                if int(w['id'])==current_id:
                    active=[r for r in active if r.get('head_branch')==branch and int(r['id'])<self.run_id]
                for r in active:
                    rid=int(r['id']);pending.append(rid)
                    if rid not in cancelled:
                        try:self.call('POST',f'actions/runs/{rid}/cancel')
                        except GuardError:
                            # Completion can race the cancellation call. Re-read before failing.
                            if self.call('GET',f'actions/runs/{rid}').get('status')!='completed':raise
                        cancelled.add(rid);self.report['cancelledRuns'].append(rid)
            if not pending:break
            if attempt==self.polls-1:
                raise GuardError('An older publisher has not stopped. The current live site was not replaced.')
            self.sleep(2)
        if self.current_head(branch)!=sha:
            self.report['status']='superseded';return self.report
        self.report.update(status='single_publisher',publish=True)
        return self.report

def main():
    report_path=Path('_reports/workflow-coordination.json');report_path.parent.mkdir(exist_ok=True)
    guard=None;code=0
    try:
        guard=Guard(gh_api,os.environ['GITHUB_REPOSITORY'],os.environ['GITHUB_RUN_ID'])
        report=guard.run()
    except Exception as exc:
        report=guard.report if guard else {'revision':'r98','publish':False}
        report.update(status='blocked',publish=False);report.setdefault('errors',[]).append(str(exc));code=1
        print('::error::'+str(exc).replace('%','%25').replace('\n','%0A').replace('\r','%0D'),file=sys.stderr)
    report_path.write_text(json.dumps(report,indent=2)+'\n')
    with open(os.environ.get('GITHUB_OUTPUT',os.devnull),'a') as f:f.write('publish='+str(bool(report.get('publish'))).lower()+'\n')
    with open(os.environ.get('GITHUB_STEP_SUMMARY',os.devnull),'a') as f:
        f.write('\n## Deployment coordination\n\n```json\n'+json.dumps(report,indent=2)+'\n```\n')
    print(json.dumps(report,indent=2));return code
if __name__=='__main__':sys.exit(main())
