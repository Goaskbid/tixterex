#!/usr/bin/env python3
"""Deterministic, offline deploy checks. These do not certify publisher CORS or recall."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,tempfile

def check(site):
 out=[]
 def ck(name,value,detail=None):out.append({'name':name,'pass':bool(value),'detail':detail})
 html=(site/'index.html').read_text();version=json.loads((site/'version.json').read_text())
 ck('light theme contract','color-scheme:light' in html or 'color-scheme: light' in html)
 ck('recovery controls present','r91Filters' in html and 'r91ResultSummary' in html)
 ck('Ticketcorner subscription present','https://www.ticketcorner.ch/campaign/ticketcorner-newsletter/' in html)
 ck('safe service worker scope',"const PREFIX='tixterex:'" in (site/'sw.js').read_text())
 blocks=re.findall(r'<script\b([^>]*)>([\s\S]*?)</script\s*>',html,re.I);executable=[];failed=[]
 with tempfile.TemporaryDirectory() as td:
  for attrs,body in blocks:
   type_attr=re.search(r"\btype\s*=\s*['\"]([^'\"]+)",attrs,re.I)
   if type_attr and type_attr[1].lower() not in ['text/javascript','application/javascript','module']:continue
   if not body.strip():continue
   if 'src=' in attrs:continue
   f=Path(td)/f'script-{len(executable)}.js';f.write_text(body);r=subprocess.run(['node','--check',str(f)],capture_output=True,text=True)
   executable.append(attrs)
   if r.returncode:failed.append({'attrs':attrs,'error':r.stderr[:1000]})
 ck('inline JavaScript parses',not failed,{'scripts':len(executable),'errors':failed})
 # Validate exact static references, excluding script bodies and external/data/blob URLs.
 stripped=re.sub(r'<script\b[\s\S]*?</script>','',html,flags=re.I)
 refs=re.findall(r'''\b(?:src|href)=["']([^"']+)["']''',stripped)
 missing=[]
 for ref in refs:
  if ref.startswith(('http:','https:','data:','blob:','//','#','mailto:','webcal:')):continue
  path=ref.split('?')[0].split('#')[0]
  if not path or path.startswith('/'):continue
  if not (site/path).exists():missing.append(path)
 ck('relative static assets present',not missing,missing)
 meta=json.loads((site/'data/places.json').read_text());refs=set(meta.get('parts',{}).values())|{x['url'] for x in meta.get('spatial',[]) if 'url' in x}
 ck('all place shards present',bool(refs) and all((site/'data'/x).is_file() for x in refs),len(refs))
 ck('no private tools in public folder',not any(p.name in ['tools','.github','.git','node_modules'] for p in site.rglob('*')))
 ck('no font files bundled',not any(p.suffix.lower() in ['.woff','.woff2','.ttf','.otf','.eot'] for p in site.rglob('*')))
 ck('build manifest agrees',version['build']==json.loads((site/'release-info.json').read_text())['build'])
 return {'passed':sum(x['pass'] for x in out),'failed':sum(not x['pass'] for x in out),'checks':out,'liveRecallMeasured':False}
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('site',type=Path);p.add_argument('--output',type=Path);a=p.parse_args();r=check(a.site);text=json.dumps(r,indent=2);print(text)
 if a.output:a.output.write_text(text)
 raise SystemExit(bool(r['failed']))
