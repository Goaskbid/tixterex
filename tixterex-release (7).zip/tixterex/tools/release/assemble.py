#!/usr/bin/env python3
"""Assemble one explicit release. No publisher requests, DNS changes or deployment."""
from __future__ import annotations
import argparse, copy, hashlib, json, os, re, shutil, sys
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'recovery'))
from stamp_build import stamp

FORBIDDEN={'.git','.github','node_modules','tools','__pycache__'}
FONT_EXT={'.woff','.woff2','.ttf','.otf','.eot'}
def read(path:Path,default=None):
 try:return json.loads(path.read_text(encoding='utf-8'))
 except (OSError,ValueError):return default

def write(path:Path,value):
 path.parent.mkdir(parents=True,exist_ok=True)
 temp=path.with_name(path.name+'.tmp')
 temp.write_text(json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8');os.replace(temp,path)

def point(city):
 try:return city.get('lat') is not None and city.get('lon') is not None and not isinstance(city.get('lat'),bool) and not isinstance(city.get('lon'),bool) and -90<=float(city['lat'])<=90 and -180<=float(city['lon'])<=180
 except (ValueError,TypeError,KeyError):return False

def event_count(doc):return sum(len(x) for x in doc.get('events',{}).values() if isinstance(x,list))

def explicitly_empty(doc):
 feeds=list((doc.get('feeds') or {}).values());venues=doc.get('venues') or []
 return bool(feeds or venues) and all(x.get('enumerationComplete') is True for x in feeds+venues)

def valid_city(doc,slug):
 if not isinstance(doc,dict) or not isinstance(doc.get('events'),dict) or not isinstance(doc.get('city'),dict) or not point(doc.get('city',{})):return False
 if not re.fullmatch(r'[A-Za-z0-9_-]{1,150}',slug):return False
 venues=doc.get('venues') or [];feeds=doc.get('feeds') or {}
 if not isinstance(venues,list) or not all(isinstance(x,dict) for x in venues):return False
 if not isinstance(feeds,dict) or not all(isinstance(x,dict) for x in feeds.values()):return False
 return all(isinstance(v,list) and all(isinstance(x,dict) for x in v) for v in doc['events'].values())

def numeric_stamp(value):
 """Compare snapshot timestamps without turning malformed input into a build crash."""
 import math
 if value is None or isinstance(value,bool):return 0.0
 try:
  result=float(value)
 except (ValueError,TypeError):
  try:result=datetime.fromisoformat(str(value).replace('Z','+00:00')).timestamp()*1000
  except (ValueError,TypeError,OverflowError):return 0.0
 return result if math.isfinite(result) and result>=0 else 0.0

def source_metadata(doc,key):
 feeds=doc.get('feeds') or {}
 if key in feeds:return feeds[key],True
 for venue in doc.get('venues') or []:
  if str(venue.get('id'))==str(key):return venue,False
 return {},False

def occurrence_key(row):
 uid=row.get('occurrenceId') or row.get('uid') or row.get('id')
 if uid is not None:return ('id',str(uid))
 return ('fact',)+tuple(str(row.get(k) or '') for k in ('title','start','venue','room','format','language','subtitles'))

def merge_city(old,new,decisions,slug):
 """Merge each independently collected source, never replace a whole city after one partial success."""
 if not old:return copy.deepcopy(new)
 newer=numeric_stamp(new.get('at'))>=numeric_stamp(old.get('at'))
 result=copy.deepcopy(new if newer else old)
 result['at']=max(numeric_stamp(old.get('at')),numeric_stamp(new.get('at')))
 result['feeds']={};result['venues']=[];result['events']={}
 keys=set(old.get('events',{}))|set(new.get('events',{}))|set(old.get('feeds') or {})|set(new.get('feeds') or {})
 keys.update(str(v.get('id')) for v in (old.get('venues') or [])+(new.get('venues') or []) if v.get('id') is not None)
 for key in sorted(keys):
  om,of=source_metadata(old,key);nm,nf=source_metadata(new,key)
  older=old.get('events',{}).get(key,[]);incoming=new.get('events',{}).get(key,[])
  old_at=numeric_stamp(om.get('good') or om.get('at') or om.get('read'))
  new_at=numeric_stamp(nm.get('good') or nm.get('at') or nm.get('read'))
  newer_source=(new_at>old_at) if new_at and old_at and new_at!=old_at else newer
  has_new=key in new.get('events',{}) or bool(nm)
  reason='retained_source';meta=om;is_feed=of;rows=older
  if has_new and (newer_source or not om and not older):
   if nm.get('retired') is True:
    rows=[];meta=nm;is_feed=nf;reason='source_retired'
   elif nm.get('error') or nm.get('lastError') or str(nm.get('status','')).lower() in {'failed','error','http_error','timeout','blocked'}:
    rows=older;meta=copy.deepcopy(om or nm);is_feed=of if om else nf
    meta['lastAttemptAt']=nm.get('attemptAt') or nm.get('read') or new.get('at')
    meta['lastAttemptError']=nm.get('error') or nm.get('lastError') or nm.get('status')
    reason='retained_after_failed_refresh'
   elif nm.get('enumerationComplete') is True:
    rows=incoming;meta=nm;is_feed=nf;reason='complete_source_refresh'
   elif incoming:
    merged={occurrence_key(e):copy.deepcopy(e) for e in older}
    for event in incoming:merged[occurrence_key(event)]=copy.deepcopy(event)
    rows=list(merged.values());meta={**om,**nm};is_feed=nf if nm else of;reason='partial_source_merged'
   elif not older:
    rows=[];meta={**om,**nm};is_feed=nf if nm else of;reason='empty_source_without_history'
   else:
    meta=copy.deepcopy(om);meta['lastAttemptAt']=nm.get('attemptAt') or nm.get('read') or new.get('at');meta['lastAttemptError']=nm.get('error') or nm.get('status') or 'unconfirmed_empty_refresh'
    reason='retained_nonempty_last_good'
  elif not older and not om and has_new:
   rows=incoming;meta=nm;is_feed=nf;reason='new_source'
  meta=copy.deepcopy(meta);meta['n']=len(rows)
  if is_feed:result['feeds'][key]=meta
  else:
   if meta:meta.setdefault('id',key);result['venues'].append(meta)
  result['events'][key]=copy.deepcopy(rows)
  decisions.append({'city':slug,'sourceKey':key,'decision':reason,'occurrences':len(rows)})
 return result

def merge_inventory(site:Path,cache:Path|None):
 target=site/'data/ingest';target.mkdir(parents=True,exist_ok=True)
 index=read(target/'index.json',{}) or {};records={};decisions=[]
 roots=[('release',target)]+([('cache',cache)] if cache and cache.is_dir() else [])
 for origin,root in roots:
  for file in sorted((root/'cities').glob('*.json')):
   slug=file.stem;doc=read(file)
   if not valid_city(doc,slug):decisions.append({'city':slug,'source':origin,'decision':'invalid_city_rejected'});continue
   old=records.get(slug)
   records[slug]=merge_city(old,doc,decisions,slug);records[slug]['city']['slug']=slug
   decisions.append({'city':slug,'source':origin,'decision':'merged' if old else 'selected'})
 # Rebuild index from actual valid files. A collector can write a city and crash before indexing it.
 cities=[];tiles={};future=0;now=datetime.now(timezone.utc);old_meta={x.get('slug'):x for x in index.get('cities',[]) if isinstance(x,dict)}
 for slug,doc in sorted(records.items()):
  write(target/'cities'/f'{slug}.json',doc);c=doc['city'];count=event_count(doc)
  row={**old_meta.get(slug,{}),**{k:c.get(k) for k in ['name','cc','lat','lon','pop']},'slug':slug,'at':doc.get('at'),
       'events':count,'topVenues':len(doc.get('venues',[])),'read':sum(bool(x.get('read')) for x in doc.get('venues',[])),
       'withProgramme':sum(numeric_stamp(x.get('n'))>0 for x in doc.get('venues',[])),'feeds':doc.get('feeds',{})}
  cities.append(row)
  import math
  tile=f"{math.floor(float(c['lat'])/5)}_{math.floor(float(c['lon'])/5)}"
  tiles.setdefault(tile,[]).append({k:row.get(k) for k in ['slug','name','cc','lat','lon','at']})
  for rows in doc['events'].values():
   for ev in rows:
    try:
     end=datetime.fromisoformat(str(ev.get('end') or ev.get('start') or '').replace('Z','+00:00'))
     if end.tzinfo is None:end=end.replace(tzinfo=timezone.utc)
     future+=int(end>=now)
    except (ValueError,TypeError):pass
 # Preserve original observation timestamps; assembly time never becomes publisher observation time.
 index={**index,'schema':'tixterex-ingest/1','at':max([numeric_stamp(x.get('at')) for x in cities] or [numeric_stamp(index.get('at'))]),
        'cities':cities,'totals':{k:sum(int(x.get(k) or 0) for x in cities) for k in ['events','topVenues','read','withProgramme']},
        'assembly':{'source':'validated release and prior collection cache','collectionExecuted':False}}
 index['totals']['cities']=len(cities);write(target/'index.json',index)
 shutil.rmtree(target/'near',ignore_errors=True)
 for name,rows in tiles.items():write(target/'near'/f'{name}.json',{'cities':rows})
 return {'cities':len(cities),'occurrences':sum(event_count(x) for x in records.values()),'futureOrOngoingOccurrences':future,
         'status':'inventory_present' if future else 'no_future_collected_inventory','collectionExecuted':False,
         'coverage10075Measured':False,'decisions':decisions}

def apply_base(site:Path,base_path:str,site_url:str):
 if not re.fullmatch(r'/[A-Za-z0-9._/-]*/?',base_path) or '..' in base_path:raise ValueError('Unsafe base path')
 base='/' + base_path.strip('/')+'/' if base_path.strip('/') else '/'
 # HTML attributes only: do not rewrite strings inside application scripts.
 attribute=re.compile(r'''\b(href|src|action)=(['"])/([^/'"<>][^'"<>]*)\2''')
 for file in site.rglob('*.html'):
  raw=file.read_text(encoding='utf-8');sections=re.split(r'(<script\b[\s\S]*?</script>)',raw,flags=re.I)
  for i in range(0,len(sections),2):
   if base!='/':sections[i]=attribute.sub(lambda m:f'{m[1]}={m[2]}/{m[3]}{m[2]}' if m[3].startswith(base.lstrip('/')) else f'{m[1]}={m[2]}{base}{m[3]}{m[2]}',sections[i])
  raw=''.join(sections)
  if site_url and file==site/'index.html':
   url=site_url.rstrip('/')+'/'
   raw=re.sub(r'(<link rel="canonical" href=")[^"]*',lambda m:m[1]+url,raw,count=1)
  file.write_text(raw,encoding='utf-8')
 manifest=read(site/'site.webmanifest',{})
 if manifest:
  manifest['start_url']=base;manifest['scope']=base;manifest['id']=base
  manifest['theme_color']='#fffaf0';manifest['background_color']='#fffaf0'
  for icon in manifest.get('icons',[]):
   if icon.get('src','').startswith('/') and not icon['src'].startswith('//') and not icon['src'].startswith(base):icon['src']=base+icon['src'].lstrip('/')
  write(site/'site.webmanifest',manifest)

def assemble(source:Path,dest:Path,build:str,cache=None,base_path='/',site_url=''):
 src=source/'site' if (source/'site').is_dir() else source
 if not (src/'index.html').is_file():raise ValueError('Explicit source has no site/index.html')
 if dest.resolve()==src.resolve() or src.resolve() in dest.resolve().parents:raise ValueError('Output must be outside source site')
 if dest.exists():shutil.rmtree(dest)
 def ignore(_folder,names):return [n for n in names if n in FORBIDDEN or n.startswith('.env') or Path(n).suffix.lower() in FONT_EXT or n.endswith(('.map','.zip','.py','.mjs','.sh','.sql')) or n in ['ledger.json','sitemap_state.json']]
 shutil.copytree(src,dest,ignore=ignore)
 health=merge_inventory(dest,cache)
 apply_base(dest,base_path,site_url);stamp(dest,build)
 (dest/'.nojekyll').touch()
 write(dest/'release-info.json',{'build':build,'siteSha256':hashlib.sha256((dest/'index.html').read_bytes()).hexdigest(),
  'artifactSource':str(source.name),'collectionExecuted':False,'coverage10075Measured':False})
 write(dest/'supply-health.json',health)
 return health
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--build',required=True);p.add_argument('--cache',type=Path);p.add_argument('--base-path',default='/');p.add_argument('--site-url',default='')
 a=p.parse_args();result=assemble(a.input,a.output,a.build,a.cache,a.base_path,a.site_url);print(json.dumps(result,indent=2))
