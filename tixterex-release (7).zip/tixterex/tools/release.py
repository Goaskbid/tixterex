#!/usr/bin/env python3
"""Build and validate the public folder from the canonical R93 source. No deployment."""
from pathlib import Path
import argparse,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=ROOT/'_site');p.add_argument('--build',default='r93-20261125');p.add_argument('--base-path',default='/');p.add_argument('--site-url',default='https://tixterex.com');p.add_argument('--cache',type=Path);a=p.parse_args()
 subprocess.run([sys.executable,str(ROOT/'tools/build_site.py')],check=True)
 cmd=[sys.executable,str(ROOT/'tools/release/assemble.py'),'--input',str(ROOT),'--output',str(a.output),'--build',a.build,'--base-path',a.base_path,'--site-url',a.site_url]
 if a.cache:cmd+=['--cache',str(a.cache)]
 subprocess.run(cmd,check=True)
 subprocess.run([sys.executable,str(ROOT/'tools/recovery/readiness_gate.py'),str(a.output),'--mode','package'],check=True)
 subprocess.run([sys.executable,str(ROOT/'tools/release/check_package.py'),str(a.output)],check=True)
 subprocess.run(['node',str(ROOT/'tools/cf_budget.mjs'),str(a.output)],check=True)
 print('Public folder validated. Event supply and live 100/75 coverage are separate checks.')
