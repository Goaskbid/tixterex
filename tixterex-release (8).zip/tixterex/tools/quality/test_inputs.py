"""Test-only data. Never copied to the public site or used by production collection."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit, parse_qs, unquote

FIXED_NOW = '2026-11-25T05:10:00Z'
FIXTURE_PREFIX = 'Acceptance fixture '
INVENTORY_PREFIX = 'Existing collection fixture '
ALLOWED_LOCAL_HOSTS = {'127.0.0.1', 'localhost', 'tixterex.invalid', 'tixterex.audit.test'}


def tree_digest(root):
    digest = hashlib.sha256()
    for p in sorted(Path(root).rglob('*')):
        if p.is_file():
            digest.update(p.relative_to(root).as_posix().encode('utf-8'))
            digest.update(b'\0')
            digest.update(hashlib.sha256(p.read_bytes()).digest())
    return digest.hexdigest()


class FixtureCatalog:
    """Respond only to fixture data URLs. Real code, images and place files pass through."""
    def __init__(self, base_path='/', inventory_count=1):
        self.base = '/' + base_path.strip('/') + '/' if base_path.strip('/') else '/'
        self.inventory_count = int(inventory_count)
        if not 0 <= self.inventory_count <= 32:
            raise ValueError('Fixture inventory count outside test limit')
        self.calls = []
        self.city = {'slug': 'quality-meilen-ch', 'name': 'Meilen', 'cc': 'CH',
                     'lat': 47.269, 'lon': 8.646, 'tz': 'Europe/Zurich'}

    @property
    def expected_count(self):
        return 8 + self.inventory_count

    def _local_path(self, url):
        u = urlsplit(url)
        if u.netloc and u.hostname not in ALLOWED_LOCAL_HOSTS:
            return None
        rel = unquote(u.path).lstrip('/')
        mount = self.base.strip('/')
        if mount and rel.startswith(mount + '/'):
            rel = rel[len(mount) + 1:]
        return rel

    def respond(self, url):
        u = urlsplit(url)
        q = parse_qs(u.query)
        rel = self._local_path(url)
        payload = None
        if rel == 'data/index.json':
            payload = {'schemaVersion': 2, 'generatedAt': FIXED_NOW,
                       'expiresAt': '2026-12-25T05:10:00Z', 'count': 0,
                       'occurrenceCount': 0, 'seriesCount': 0, 'detailRecordCount': 0,
                       'shards': [], 'detailShards': [], 'sources': [], 'liveSources': [],
                       'coverage': 'QA fixture only; not live event inventory'}
        elif rel == 'data/reviewed-programmes.json':
            payload = {'schema': 'tixterex-reviewed-programmes/1', 'observedAt': FIXED_NOW,
                       'validUntil': '2026-11-28T05:10:00Z', 'records': []}
        elif rel == 'data/public-sources.json':
            payload = {'schemaVersion': 1, 'generatedAt': FIXED_NOW,
                       'expiresAt': '2026-12-25T05:10:00Z', 'sources': []}
        elif rel == 'data/doors.json':
            payload = {'schema': 'tixterex-doors/1', 'doors': []}
        elif rel == 'data/atlas/verified.json':
            payload = {'schema': 'tixterex-atlas-verified/1', 'datasets': []}
        elif rel == 'data/ingest/index.json':
            payload = {'schema': 'tixterex-ingest/1', 'at': 1795583400000,
                       'cities': [self.city] if self.inventory_count else []}
        elif rel and rel.startswith('data/ingest/near/'):
            payload = {'cities': [self.city] if self.inventory_count and rel.endswith('/9_1.json') else []}
        elif rel == 'data/ingest/cities/quality-meilen-ch.json':
            at = 1795583400000
            payload = {'city': self.city, 'at': at, 'feeds': {},
                       'venues': [{'id': 'quality-hall', 'name': 'Existing fixture hall',
                                   'lat': 47.269, 'lon': 8.646, 'site': 'https://fixture.example',
                                   'read': at, 'good': at, 'n': self.inventory_count}],
                       'events': {'quality-hall': [
                           {'id': 'quality-inventory-' + str(i), 'title': INVENTORY_PREFIX + str(i + 1),
                            'start': '2026-11-26T20:15:00+01:00', 'end': '2026-11-26T22:15:00+01:00',
                            'url': 'https://fixture.example/existing/' + str(i),
                            'venue': 'Existing fixture hall', 'lat': 47.269, 'lon': 8.646,
                            'observedAt': FIXED_NOW}
                           for i in range(self.inventory_count)]}}
        elif u.hostname == 'eventsimple.de' and u.path.startswith('/api/events'):
            lat = float(q.get('lat', ['46.2044'])[0]); lon = float(q.get('lng', ['6.1432'])[0])
            rows = [{'id': 10000 + round(lat * 100) + i, 'title': FIXTURE_PREFIX + str(i + 1),
                     'starts_at': f'2026-11-{26 + i % 2:02d}T19:00:00+01:00',
                     'ends_at': f'2026-11-{26 + i % 2:02d}T21:00:00+01:00', 'all_day': False,
                     'latitude': lat, 'longitude': lon, 'has_coordinates': True,
                     'venue': f'Fixture hall {i % 3}', 'city': 'Fixture city', 'country': 'CH',
                     'url': f'https://fixture.example/event/{lat}/{i}',
                     'detail_url': f'https://eventsimple.de/event/{10000+i}',
                     'category': ['concert','theatre','family','cinema'][i%4]} for i in range(8)]
            payload = {'events': rows, 'total': 8, 'count': 8, 'truncated': False}
        elif 'opendatasoft' in (u.hostname or ''):
            payload = {'results': [], 'total_count': 0}
        elif 'overpass' in (u.hostname or ''):
            payload = {'elements': []}
        elif u.hostname == 'query.wikidata.org':
            payload = {'results': {'bindings': []}}
        elif 'wikipedia.org' in (u.hostname or '') or u.hostname == 'commons.wikimedia.org':
            payload = {'query': {'pages': {}}}
        if payload is not None:
            self.calls.append({'url': url, 'fixture': True})
            return {'body': json.dumps(payload), 'status': 200, 'type': 'application/json'}
        return None
