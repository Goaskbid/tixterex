import base64,copy,importlib.util,json,re,unittest
from pathlib import Path
P=Path(__file__).resolve().parents[2]/'tools/release/workflow_guard.py'
spec=importlib.util.spec_from_file_location('guard',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
SHA='a'*40
NEW='# TIXTEREX_DEPLOY_CONTRACT: r{revision}\nname: TixTerex deployment\njobs:\n  deploy:\n    steps:\n    - uses: actions/deploy-pages@v5\n'.replace('{revision}',str(m.REVISION))
OLD='name: TixTerex validate and deploy\nrun-name: TixTerex ZIP upload deploy\njobs:\n  deploy:\n    steps:\n    - uses: actions/deploy-pages@v5\n'
class Fake:
 def __init__(self):
  self.current=101;self.head=SHA;self.denied=None;self.endless=False;self.calls=[];self.statuses={}
  self.wfs=[{'id':1,'name':'TixTerex deployment','path':'.github/workflows/tixterex.yml','state':'active'}, {'id':2,'name':'TixTerex validate and deploy','path':'.github/workflows/tixterex (1).yml','state':'active'}, {'id':3,'name':'Security scan','path':'.github/workflows/security.yml','state':'active'}]
  self.bodies={self.wfs[0]['path']:NEW,self.wfs[1]['path']:OLD,self.wfs[2]['path']:'name: Security scan\n'}
  self.runs={1:[{'id':101,'workflow_id':1,'status':'in_progress','event':'push','head_sha':SHA,'head_branch':'main'}],2:[{'id':99,'workflow_id':2,'status':'queued','event':'push','head_sha':SHA,'head_branch':'main'}],3:[]}
 def __call__(self,method,path):
  from urllib.parse import unquote,urlsplit,parse_qs
  self.calls.append((method,path));s=path.split('repos/owner/repo/',1)[1]
  if self.denied and self.denied in s:raise m.GuardError('HTTP 403 permission denied')
  if s.startswith('actions/runs/'):
   rid=int(s.split('/')[2]);r=next(r for rows in self.runs.values() for r in rows if r['id']==rid)
   if method=='POST':
    if not self.endless:r['status']='completed'
    return None
   return copy.deepcopy(r)
  if s.startswith('git/ref/heads/'):return {'object':{'sha':self.head}}
  if s.startswith('contents/'):
   name=unquote(s[len('contents/'):].split('?')[0]);return {'type':'file','encoding':'base64','content':base64.b64encode(self.bodies[name].encode()).decode()}
  if s.startswith('actions/workflows?'):
   page=int(parse_qs(urlsplit(s).query)['page'][0]);return {'workflows':copy.deepcopy(self.wfs[(page-1)*100:page*100])}
  if s.startswith('actions/workflows/'):
   wid=int(s.split('/')[2])
   if method=='PUT':
    next(w for w in self.wfs if w['id']==wid)['state']='disabled_manually';return None
   page=int(parse_qs(urlsplit(s).query)['page'][0]);return {'workflow_runs':copy.deepcopy(self.runs.get(wid,[])[(page-1)*100:page*100])}
  raise AssertionError((method,path))
class Cases(unittest.TestCase):
 def setUp(self):self.f=Fake()
 def run_guard(self,run=101):return m.Guard(self.f,'owner/repo',run,sleep=lambda _:None,polls=2).run()
 def writes(self):return [x for x in self.f.calls if x[0]!='GET']
 def test_disables_only_old_publisher(self):
  r=self.run_guard();self.assertTrue(r['publish']);self.assertEqual([x['id'] for x in r['disabledDuplicates']],[2]);self.assertEqual(r['cancelledRuns'],[99]);self.assertEqual(self.f.wfs[2]['state'],'active')
 def test_does_not_disable_self(self):self.run_guard();self.assertFalse(any('/1/disable' in p for _,p in self.writes()))
 def test_does_not_delete_any_file(self):self.run_guard();self.assertTrue(all(method in {'PUT','POST'} for method,p in self.writes()));self.assertFalse(any('contents/' in p for _,p in self.writes()))
 def test_no_duplicates_no_mutations(self):self.f.wfs[1]['state']='disabled_manually';self.f.runs[2][0]['status']='completed';self.assertTrue(self.run_guard()['publish']);self.assertEqual(self.writes(),[])
 def test_same_name_without_deploy_not_disabled(self):self.f.bodies[self.f.wfs[1]['path']]='name: TixTerex validate and deploy\n';self.run_guard();self.assertEqual(self.writes(),[])
 def test_unrelated_pages_workflow_not_disabled(self):self.f.bodies[self.f.wfs[2]['path']]='name: Security scan\n- uses: actions/deploy-pages@v5\n';self.run_guard();self.assertFalse(any('/3/' in p for _,p in self.writes()))
 def test_mislabeled_current_rejected(self):self.f.bodies[self.f.wfs[0]['path']]=OLD;self.assertRaisesRegex(m.GuardError,'not the R'+str(m.REVISION),self.run_guard);self.assertEqual(self.writes(),[])
 def test_stale_commit_skips(self):self.f.head='b'*40;r=self.run_guard();self.assertFalse(r['publish']);self.assertEqual(r['status'],'superseded');self.assertEqual(self.writes(),[])
 def test_permission_failure_cannot_publish(self):self.f.denied='/disable';self.assertRaisesRegex(m.GuardError,'403',self.run_guard);self.assertEqual(self.f.runs[2][0]['status'],'queued')
 def test_cancellation_must_finish(self):self.f.endless=True;self.assertRaisesRegex(m.GuardError,'has not stopped',self.run_guard)
 def test_only_active_old_workflows_disabled(self):self.f.wfs[1]['state']='disabled_inactivity';self.f.runs[2][0]['status']='completed';self.run_guard();self.assertEqual(self.writes(),[])
 def test_duplicate_new_file_skips(self):
  self.f.bodies[self.f.wfs[1]['path']]=NEW;r=self.run_guard(99);self.assertFalse(r['publish']);self.assertEqual(r['canonicalPath'],self.f.wfs[0]['path']);self.assertEqual(self.writes(),[])
 def test_canonical_new_disables_duplicate_new(self):self.f.bodies[self.f.wfs[1]['path']]=NEW;self.assertTrue(self.run_guard()['publish']);self.assertEqual(self.f.wfs[1]['state'],'disabled_manually')
 def test_other_higher_revision_retained(self):self.f.bodies[self.f.wfs[1]['path']]=NEW.replace('r'+str(m.REVISION),'r'+str(m.REVISION+1));self.assertFalse(self.run_guard()['publish']);self.assertEqual(self.writes(),[])
 def test_manual_dispatch_allowed(self):self.f.runs[1][0]['event']='workflow_dispatch';self.assertTrue(self.run_guard()['publish'])
 def test_pull_requests_never_publish(self):self.f.runs[1][0]['event']='pull_request';self.assertRaisesRegex(m.GuardError,'Only a branch',self.run_guard);self.assertEqual(self.writes(),[])
 def test_run_paths_encoded(self):self.run_guard();self.assertTrue(any('tixterex%20%281%29.yml' in p for method,p in self.f.calls))
 def test_workflow_pagination(self):
  for i in range(4,108):self.f.wfs.append({'id':i,'name':'Other','path':f'.github/workflows/other{i}.yml','state':'active'})
  self.assertTrue(self.run_guard()['publish']);self.assertTrue(any('actions/workflows?per_page=100&page=2' in p for _,p in self.f.calls))
 def test_run_pagination(self):
  self.f.runs[2]=[{'id':i,'workflow_id':2,'status':'completed'} for i in range(1000,1100)]+[{'id':99,'workflow_id':2,'status':'waiting'}]
  self.assertEqual(self.run_guard()['cancelledRuns'],[99])
 def test_old_run_of_same_workflow_cancelled_not_disabled(self):
  self.f.runs[1].append({'id':100,'workflow_id':1,'status':'in_progress','event':'push','head_sha':'b'*40,'head_branch':'main'})
  r=self.run_guard();self.assertIn(100,r['cancelledRuns']);self.assertEqual(self.f.wfs[0]['state'],'active')
 def test_newer_same_commit_run_wins(self):
  self.f.runs[1].append({'id':102,'workflow_id':1,'status':'in_progress','event':'workflow_dispatch','head_sha':SHA,'head_branch':'main'})
  r=self.run_guard();self.assertFalse(r['publish']);self.assertEqual(r['status'],'superseded_run');self.assertEqual(self.writes(),[])
 def test_other_branch_own_run_not_cancelled(self):
  self.f.runs[1].append({'id':100,'workflow_id':1,'status':'in_progress','event':'push','head_sha':'b'*40,'head_branch':'feature'})
  r=self.run_guard();self.assertNotIn(100,r['cancelledRuns'])
 def test_invalid_repository(self):self.assertRaises(m.GuardError,m.Guard,self.f,'owner/repo/unsafe',1)
 def test_no_deployment_before_guard(self):r=self.run_guard();self.assertEqual(r['status'],'single_publisher');self.assertTrue(r['publish'])
if __name__=='__main__':unittest.main(verbosity=2)
