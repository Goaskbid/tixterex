import hashlib,json,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools/quality'))
import importlib.util
spec=importlib.util.spec_from_file_location('quality_fixture_catalog',ROOT/'tools/quality/test_inputs.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
FixtureCatalog,tree_digest=module.FixtureCatalog,module.tree_digest

class Cases(unittest.TestCase):
 def value(self,url,n=1,base='/'):
  r=FixtureCatalog(base,n).respond(url);return json.loads(r['body']) if r else None
 def test_root_inventory_is_controlled(self):self.assertEqual(len(self.value('http://127.0.0.1:8000/data/ingest/index.json')['cities']),1)
 def test_project_path_inventory(self):self.assertEqual(len(self.value('http://127.0.0.1:8000/tixterex/data/ingest/index.json',base='/tixterex/')['cities']),1)
 def test_relative_inventory(self):self.assertEqual(len(self.value('data/ingest/index.json')['cities']),1)
 def test_remote_same_named_data_not_overridden(self):self.assertIsNone(self.value('https://publisher.example/data/index.json'))
 def test_real_javascript_not_overridden(self):self.assertIsNone(self.value('http://127.0.0.1:8000/app.js'))
 def test_real_artwork_not_overridden(self):self.assertIsNone(self.value('img/rex/01.webp'))
 def test_real_locality_files_not_overridden(self):self.assertIsNone(self.value('data/localities/ch.json'))
 def test_empty_primary_index(self):self.assertEqual(self.value('data/index.json')['shards'],[])
 def test_zero_inventory(self):self.assertEqual(self.value('data/ingest/index.json',0)['cities'],[])
 def test_multiple_inventory(self):self.assertEqual(len(self.value('data/ingest/cities/quality-meilen-ch.json',5)['events']['quality-hall']),5)
 def test_index_base_uses_directory_boundary(self):self.assertIsNone(self.value('/tixterexx/data/index.json',base='/tixterex/'))
 def test_feed_eight_geographic_rows(self):
  x=self.value('https://eventsimple.de/api/events?lat=47.269&lng=8.646');self.assertEqual(len(x['events']),8);self.assertTrue(all(r['latitude']==47.269 for r in x['events']))
 def test_expected_count_combines_sources(self):self.assertEqual(FixtureCatalog(inventory_count=5).expected_count,13)
 def test_negative_count_rejected(self):self.assertRaises(ValueError,FixtureCatalog,inventory_count=-1)
 def test_excessive_count_rejected(self):self.assertRaises(ValueError,FixtureCatalog,inventory_count=1000)
 def test_snapshot_cannot_inject_third_source(self):self.assertEqual(self.value('data/reviewed-programmes.json')['records'],[])
 def test_unmatched_tile_empty(self):self.assertEqual(self.value('data/ingest/near/8_1.json')['cities'],[])
 def test_matched_tile_contains_city(self):self.assertEqual(len(self.value('data/ingest/near/9_1.json')['cities']),1)
 def test_tree_hash_detects_mutation(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'a';p.write_bytes(b'a');before=tree_digest(Path(td));p.write_bytes(b'b');self.assertNotEqual(before,tree_digest(Path(td)))
 def test_no_files_written_by_fixture_response(self):
  with tempfile.TemporaryDirectory() as td:
   before=tree_digest(Path(td));self.value('data/index.json');self.assertEqual(before,tree_digest(Path(td)))
if __name__=='__main__':unittest.main(verbosity=2)
