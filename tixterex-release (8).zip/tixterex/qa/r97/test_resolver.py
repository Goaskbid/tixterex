import importlib.util, json, os, shutil, stat, tempfile, unittest, zipfile, hashlib
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('resolver',Path(__file__).resolve().parents[2]/'tools/release/resolve.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def fixture(path, version='r95-visual-restore-20261125', content='APP95', full=True, required=None, prefix='tixterex/'):
    files={prefix+'BUNDLE_INPUTS.json':json.dumps({'schema':'tixterex-release-parts/1','release':version,'requiredParts':required or []}),
      prefix+'site/index.html':content,prefix+'tools/release/assemble.py':'# assemble',prefix+'tools/recovery/readiness_gate.py':'# gate',
      prefix+'tools/release/check_package.py':'# check',prefix+'tools/cf_budget.mjs':'// budget',
      prefix+'site/data/places.json':json.dumps({'parts':{'a':'localities/a.json'},'spatial':[{'url':'localities/a.json'}]})}
    if full: files[prefix+'site/data/localities/a.json']='[]'
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for k,v in files.items():z.writestr(k,v)
    return path
class Resolution(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name);self.calls=[]
    def tearDown(self):self.tmp.cleanup()
    def resolve(self,releases=None,source='auto',pinned='',loader=None,fetch=None):
        def denied(*args):self.calls.append(args);raise AssertionError('Unexpected remote asset call')
        r=m.Resolver(self.work,releases or [],fetch or denied,pinned,source,release_loader=loader)
        out=r.run();return r,out
    def test_repository_mode_keeps_quality_tests(self):
        (self.work/'site/data/localities').mkdir(parents=True)
        (self.work/'site/index.html').write_text('APP')
        (self.work/'site/data/places.json').write_text(json.dumps({'parts':{'a':'localities/a.json'}}))
        (self.work/'site/data/localities/a.json').write_text('[]')
        (self.work/'tools/release').mkdir(parents=True)
        (self.work/'tools/release/assemble.py').write_text('# assemble')
        (self.work/'qa/r97').mkdir(parents=True)
        (self.work/'qa/r97/test_inventory.py').write_text('# REQUIRED QA')
        (self.work/'benchmark').mkdir()
        (self.work/'benchmark/cities.json').write_text('[]')
        r,out=self.resolve(source='repository')
        self.assertEqual((out/'qa/r97/test_inventory.py').read_text(),'# REQUIRED QA')
        self.assertTrue((out/'benchmark/cities.json').exists())
    def test_new_browser_suffix_beats_older_canonical(self):
        fixture(self.work/'tixterex-release.zip','r97-20261125','OLD')
        fixture(self.work/'tixterex-release (2).zip','r98-20261125','NEW')
        self.assertEqual((self.resolve()[1]/'site/index.html').read_text(),'NEW')
    def test_dot_suffix_uses_revision_not_suffix_number(self):
        fixture(self.work/'tixterex-release.99.zip','r97-20261125','OLD')
        fixture(self.work/'tixterex-release.1.zip','r98-20261125','NEW')
        self.assertEqual((self.resolve()[1]/'site/index.html').read_text(),'NEW')
    def test_older_download_does_not_replace_canonical(self):
        fixture(self.work/'tixterex-release.zip','r98-20261125','NEW')
        fixture(self.work/'tixterex-release (7).zip','r93-20261125','OLD')
        self.assertEqual((self.resolve()[1]/'site/index.html').read_text(),'NEW')
    def test_legacy_unqualified_family_does_not_hide_new_upload(self):
        with zipfile.ZipFile(self.work/'tixterex-release.zip','w') as z:z.writestr('site/index.html','legacy')
        fixture(self.work/'tixterex-release.2.zip','r98-20261125','NEW')
        self.assertEqual((self.resolve()[1]/'site/index.html').read_text(),'NEW')
    def test_same_revision_conflicting_upload_family_stops(self):
        fixture(self.work/'tixterex-release.zip','r98-20261125','A')
        fixture(self.work/'tixterex-release (1).zip','r98-20261125','B')
        with self.assertRaisesRegex(m.ResolveError,'SAME embedded'):self.resolve()
    def test_canonical_wins_older_source_and_releases(self):
        fixture(self.work/'tixterex-release.zip');fixture(self.work/'tixterex-source.zip','r93-20261125','OLD')
        def loader():raise AssertionError('No Release request for complete Code uploads')
        r,p=self.resolve(loader=loader);self.assertEqual((p/'site/index.html').read_text(),'APP95');self.assertEqual(r.report['assetsSeen'],[])
    def test_canonical_wins_even_newer_backup(self):
        fixture(self.work/'tixterex-release.zip');fixture(self.work/'backup.zip','r99-20261125','BACKUP')
        r,p=self.resolve();self.assertEqual((p/'site/index.html').read_text(),'APP95')
    def test_uploads_directory(self):
        (self.work/'uploads').mkdir();fixture(self.work/'uploads/tixterex-release.zip');self.assertEqual(self.resolve()[0].report['status'],'resolved')
    def test_renamed_code_versions_select_latest_manifest(self):
        fixture(self.work/'tixterex-release.2.zip','r93-20261125','OLD');fixture(self.work/'tixterex-release (1).zip')
        r,p=self.resolve();self.assertEqual((p/'site/index.html').read_text(),'APP95');self.assertEqual(len(r.report['ignoredApplications']),1)
    def test_numeric_version_not_lexical(self):
        fixture(self.work/'a.zip','r9-20261125','NINE');fixture(self.work/'b.zip','r95-20261125','NINETYFIVE')
        self.assertEqual((self.resolve()[1]/'site/index.html').read_text(),'NINETYFIVE')
    def test_same_version_timestamp_orders(self):
        fixture(self.work/'a.zip','r95-202611241213','OLD');fixture(self.work/'b.zip','r95-202611251540','NEW')
        self.assertEqual((self.resolve()[1]/'site/index.html').read_text(),'NEW')
    def test_identical_duplicate_archives(self):
        p=fixture(self.work/'one.zip');shutil.copy2(p,self.work/'two.zip');self.assertEqual(self.resolve()[0].report['status'],'resolved')
    def test_same_code_repack_not_ambiguity(self):
        fixture(self.work/'one.zip');fixture(self.work/'two.zip',prefix='different/root/');self.assertEqual(self.resolve()[0].report['status'],'resolved')
    def test_full_and_split_same_build(self):
        fixture(self.work/'one.zip');fixture(self.work/'two.zip',full=False)
        r,p=self.resolve();self.assertTrue((p/'site/data/localities/a.json').exists())
    def test_conflicting_same_revision_fails_explained(self):
        fixture(self.work/'one.zip',content='ONE');fixture(self.work/'two.zip',content='TWO')
        with self.assertRaisesRegex(m.ResolveError,'SAME embedded'):self.resolve()
    def test_canonical_corrupt_never_falls_back(self):
        (self.work/'tixterex-release.zip').write_text('broken');fixture(self.work/'old.zip','r93-20261125')
        with self.assertRaisesRegex(m.ResolveError,'Unreadable'):self.resolve()
    def test_canonical_old_unqualified_never_falls_back(self):
        with zipfile.ZipFile(self.work/'tixterex-release.zip','w') as z:z.writestr('site/index.html','legacy')
        fixture(self.work/'old.zip')
        with self.assertRaisesRegex(m.ResolveError,'does not contain'):self.resolve()
    def test_unrelated_corrupt_zip_ignored(self):
        (self.work/'unrelated.zip').write_text('broken');fixture(self.work/'restored.zip')
        r,p=self.resolve();self.assertEqual(r.report['status'],'resolved');self.assertTrue(r.report['warnings'])
    def test_path_traversal_rejected(self):
        p=fixture(self.work/'tixterex-release.zip')
        with zipfile.ZipFile(p,'a') as z:z.writestr('../outside','evil')
        with self.assertRaisesRegex(m.ResolveError,'Unsafe'):self.resolve()
    def test_absolute_path_rejected(self):
        p=fixture(self.work/'tixterex-release.zip')
        with zipfile.ZipFile(p,'a') as z:z.writestr('/tmp/outside','evil')
        with self.assertRaisesRegex(m.ResolveError,'Unsafe'):self.resolve()
    def test_symlink_rejected(self):
        p=fixture(self.work/'tixterex-release.zip')
        with zipfile.ZipFile(p,'a') as z:
            info=zipfile.ZipInfo('tixterex/link');info.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(info,'/tmp')
        with self.assertRaisesRegex(m.ResolveError,'Unsafe'):self.resolve()
    def test_case_duplicate_rejected(self):
        p=fixture(self.work/'tixterex-release.zip')
        with zipfile.ZipFile(p,'a') as z:z.writestr('tixterex/SITE/INDEX.HTML','duplicate')
        with self.assertRaisesRegex(m.ResolveError,'Duplicate'):self.resolve()
    def test_unsafe_locality_reference_rejected(self):
        p=fixture(self.work/'x.zip');r=m.Resolver(self.work,[],lambda *_:None);app=r.choose(r.inspect(p,'x')['apps']);r.extract(app['archive'],app['prefix'],r.output)
        (r.output/'site/data/places.json').write_text('{"parts":{"x":"../outside"}}')
        with self.assertRaisesRegex(m.ResolveError,'Unsafe locality'):r.places_complete()
    def test_missing_parts_fail(self):
        fixture(self.work/'tixterex-release.zip',full=False,required=[{'name':'tixterex-places-1.zip','sha256':'0'*64}])
        with self.assertRaisesRegex(m.ResolveError,'matching data parts'):self.resolve()
    def test_hash_matched_renamed_parts(self):
        part=self.work/'tixterex-places-1.1.zip'
        with zipfile.ZipFile(part,'w') as z:z.writestr('tixterex/site/data/localities/a.json','[]')
        fixture(self.work/'tixterex-release.zip',full=False,required=[{'name':'tixterex-places-1.zip','sha256':m.digest(part)}])
        r,p=self.resolve();self.assertEqual(r.report['placeFilesMissing'],0)
    def test_wrong_part_hash_rejected(self):
        fixture(self.work/'tixterex-release.zip',full=False,required=[{'name':'tixterex-places-1.zip','sha256':'1'*64}])
        with zipfile.ZipFile(self.work/'tixterex-places-1.zip','w') as z:z.writestr('tixterex/site/data/localities/a.json','[]')
        with self.assertRaisesRegex(m.ResolveError,'matching data parts'):self.resolve()
    def test_nested_kit(self):
        part=fixture(self.work/'_nested.zip')
        with zipfile.ZipFile(self.work/'kit.zip','w') as z:z.write(part,'bundle/tixterex-release.zip')
        part.unlink();self.assertEqual(self.resolve()[0].report['status'],'resolved')
    def test_multiple_nested_versions(self):
        a=fixture(self.work/'_a.zip','r93-20261125','OLD');b=fixture(self.work/'_b.zip')
        with zipfile.ZipFile(self.work/'tixterex-release.zip','w') as z:z.write(a,'old.zip');z.write(b,'current.zip')
        a.unlink();b.unlink();self.assertEqual((self.resolve()[1]/'site/index.html').read_text(),'APP95')
    def test_unavailable_releases_do_not_break_complete_upload(self):
        fixture(self.work/'tixterex-release.zip')
        def fail():raise OSError('GitHub unavailable')
        self.assertEqual(self.resolve(loader=fail)[0].report['status'],'resolved')
    def test_release_selection_isolated(self):
        store=self.work/'_assets';store.mkdir();older=fixture(store/'old.zip','r93-20261125','OLD');newer=fixture(store/'new.zip')
        rows=[{'id':2,'tag_name':'a91','published_at':'2026-11-25','assets':[{'id':2,'name':'tixterex-release.2.zip','size':newer.stat().st_size}]},
              {'id':1,'tag_name':'a90','published_at':'2026-11-24','assets':[{'id':1,'name':'tixterex-release.1.zip','size':older.stat().st_size}]}]
        def fetch(a,p):self.calls.append(a['id']);shutil.copy2({1:older,2:newer}[a['id']],p)
        r,p=self.resolve(rows,source='release',fetch=fetch);self.assertEqual(r.report['releaseTag'],'a91');self.assertEqual(self.calls,[2])
    def test_multiple_app_versions_in_one_release(self):
        store=self.work/'_assets';store.mkdir();a=fixture(store/'a.zip','r93-20261125','OLD');b=fixture(store/'b.zip')
        assets=[{'id':1,'name':'release-old.zip','size':a.stat().st_size},{'id':2,'name':'release-new.zip','size':b.stat().st_size}]
        def fetch(x,p):shutil.copy2({1:a,2:b}[x['id']],p)
        r,p=self.resolve([{'id':1,'tag_name':'a91','assets':assets}],source='release',fetch=fetch);self.assertEqual((p/'site/index.html').read_text(),'APP95')
    def test_pinned_release_does_not_choose_local(self):
        fixture(self.work/'tixterex-release.zip')
        with self.assertRaisesRegex(m.ResolveError,'selected published release'):self.resolve([],source='release',pinned='missing')
    def test_asset_size_mismatch(self):
        store=self.work/'_store';store.mkdir();p=fixture(store/'x.zip')
        r=m.Resolver(self.work,[],lambda a,d:shutil.copy2(p,d))
        with self.assertRaisesRegex(m.ResolveError,'Incomplete'):r.download({'tag_name':'a91'},{'id':1,'name':'x.zip','size':1})
    def test_asset_hash_mismatch(self):
        store=self.work/'_store';store.mkdir();p=fixture(store/'x.zip')
        r=m.Resolver(self.work,[],lambda a,d:shutil.copy2(p,d))
        with self.assertRaisesRegex(m.ResolveError,'SHA-256 mismatch'):r.download({'tag_name':'a91'},{'id':1,'name':'x.zip','size':p.stat().st_size,'digest':'sha256:'+'0'*64})
    def test_fresh_inventory_kept(self):
        fixture(self.work/'tixterex-release.zip')
        with zipfile.ZipFile(self.work/'tixterex-inventory.zip','w') as z:
            z.writestr('tixterex/site/data/ingest/index.json','{"cities":[{"slug":"fresh"}]}')
        r,p=self.resolve();self.assertIn('fresh',(p/'site/data/ingest/index.json').read_text())
    def test_invalid_inventory_type_rejected(self):
        fixture(self.work/'tixterex-release.zip')
        with zipfile.ZipFile(self.work/'tixterex-inventory.zip','w') as z:
            z.writestr('tixterex/site/data/ingest/index.json','{}');z.writestr('tixterex/site/data/ingest/script.js','evil')
        with self.assertRaisesRegex(m.ResolveError,'Unexpected file type'):self.resolve()
    def test_no_zip_exact_message(self):
        with self.assertRaisesRegex(m.ResolveError,'No repaired application ZIP'):self.resolve()
    def test_failed_inspect_does_not_poison_cache(self):
        p=self.work/'bad.zip';p.write_text('bad');r=m.Resolver(self.work,[],lambda *_:None)
        for _ in range(2):
            with self.assertRaises(m.ResolveError):r.inspect(p,'bad')
        self.assertEqual(r.archives,{})
    def test_font_files_not_extracted(self):
        p=fixture(self.work/'tixterex-release.zip')
        with zipfile.ZipFile(p,'a') as z:z.writestr('tixterex/site/test.woff2','not-for-sharing')
        self.assertFalse((self.resolve()[1]/'site/test.woff2').exists())
    def test_invalid_manifest_part_rejected(self):
        fixture(self.work/'tixterex-release.zip',required=[{'name':'other.zip','sha256':'0'*64}])
        with self.assertRaisesRegex(m.ResolveError,'Invalid required part'):self.resolve()
    def test_source_uploads_without_app_never_fetches_release(self):
        with self.assertRaisesRegex(m.ResolveError,'Upload tixterex-release'):self.resolve(source='uploads')
    def test_bad_source_rejected(self):
        with self.assertRaisesRegex(m.ResolveError,'Source must'):self.resolve(source='nonsense')
if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Resolution)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    (ROOT/'evidence').mkdir(parents=True,exist_ok=True)
    (ROOT/'evidence/resolver-tests.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.testsRun-len(result.failures)-len(result.errors),'basis':'synthetic archive and mocked release metadata fixtures; no GitHub mutation'},indent=2))
    raise SystemExit(not result.wasSuccessful())
