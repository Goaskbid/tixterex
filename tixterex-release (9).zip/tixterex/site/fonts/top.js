/* Shared by the static pages: every visit starts at the top; a back-to-top button appears after scrolling (owner rules, Nov 2026) */
(function () { try { if ('scrollRestoration' in history) history.scrollRestoration = 'manual'; } catch (_) {}
  var top0 = function () { if (!location.hash || location.hash.length < 2) window.scrollTo(0, 0); }; top0(); window.addEventListener('load', top0);
  var b = document.createElement('button'); b.id = 'ttTop'; b.type = 'button'; b.textContent = '↑'; b.title = b.ariaLabel = 'Back to top'; b.setAttribute('aria-label', 'Back to top');
  b.onclick = function () { window.scrollTo({ top: 0, behavior: 'smooth' }); };
  var on = false, t = function () { var s = window.scrollY > Math.max(500, innerHeight * 0.9); if (s !== on) { on = s; b.classList.toggle('on', s); } };
  var mount = function () { document.documentElement.appendChild(b); window.addEventListener('scroll', t, { passive: true }); t(); };
  if (document.body) mount(); else document.addEventListener('DOMContentLoaded', mount); })();
