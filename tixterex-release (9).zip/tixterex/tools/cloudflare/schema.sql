CREATE TABLE IF NOT EXISTS nominations(host TEXT NOT NULL, page TEXT NOT NULL, vn TEXT, lat REAL, lon REAL, hits INTEGER NOT NULL DEFAULT 1, first INTEGER, last INTEGER, sample TEXT, PRIMARY KEY(host,page));
CREATE INDEX IF NOT EXISTS nominations_last ON nominations(last);
CREATE TABLE IF NOT EXISTS counter(day TEXT PRIMARY KEY, n INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS subs(id TEXT PRIMARY KEY, endpoint TEXT NOT NULL, p256dh TEXT NOT NULL, auth TEXT NOT NULL, follows TEXT, lat REAL, lon REAL, place TEXT, made INTEGER, last INTEGER, seen TEXT, day TEXT);
CREATE INDEX IF NOT EXISTS subs_last ON subs(last);
-- A88 organiser API: linked websites (proved by a token on their own site), their feed, and their pushed programme
CREATE TABLE IF NOT EXISTS organisers(host TEXT PRIMARY KEY, verified INTEGER, feed TEXT, anchor_lat REAL, anchor_lon REAL, pushed_at INTEGER, trust TEXT, revoked TEXT);
CREATE TABLE IF NOT EXISTS pushed(host TEXT PRIMARY KEY, events TEXT NOT NULL, at INTEGER NOT NULL, held INTEGER NOT NULL DEFAULT 0);

CREATE TABLE IF NOT EXISTS places(k TEXT PRIMARY KEY, name TEXT NOT NULL, cc TEXT, lat REAL NOT NULL, lon REAL NOT NULL, hits INTEGER NOT NULL DEFAULT 1, first INTEGER, last INTEGER);
