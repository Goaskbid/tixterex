"""Build a single-file TixTerex that works without the data/ folder.

python3 tools/build_standalone.py site out.html [--standalone]

Embeds the published event snapshot (index, event and detail shards) and a compact GeoNames
place list (tools/places-lite.json: 36,000+ places with local-script names) into a copy of
site/index.html, with tools/standalone_fetch.js serving them. The page stays identical to the
site; the pack only activates when opened as a file, or everywhere with --standalone (for
preview hosts without data/). The deployed site uses site/index.html, not this file.
"""
import json, sys
from pathlib import Path
site, out = Path(sys.argv[1]), Path(sys.argv[2])
html = (site / "index.html").read_text()
if 'id="tf-sourcegraph"' not in html and (site / "data" / "sourcegraph.json").exists():   # A37: the site loads it as a file; a page opened from disk needs it inline
    html = html.replace('<script id="tf-sourcegraph-preload">', '<script type="application/json" id="tf-sourcegraph">' + (site / "data" / "sourcegraph.json").read_text().replace("</", "<\\/") + '</script><script id="tf-sourcegraph-preload">', 1)
files = {}
for p in sorted((site / "data").rglob("*.json")):
    rel = p.relative_to(site).as_posix()
    if rel in ("data/places.json", "data/sourcegraph.json") or rel.startswith("data/localities/"): continue
    # audit F01: assets with a declared hash travel byte for byte (re-serialising changed the bytes and broke their check)
    files[rel] = {"$raw": p.read_bytes().decode("utf-8")} if rel.startswith(("data/events/", "data/details/")) else json.loads(p.read_text())
here = Path(__file__).parent
places = json.loads((here / "places-lite.json").read_text())
pack = json.dumps({"files": files, "places": places}, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
flag = "window.TF_STANDALONE=true;" if "--standalone" in sys.argv else ""
inject = "<script>" + flag + "window.TF_PACK=" + pack + ";</script>\n<script>" + (here / "standalone_fetch.js").read_text() + "</script>\n"
anchor = html.find("const fetch0=global.fetch.bind(global)")
start = max(html.rfind("<script>", 0, anchor), html.rfind("<script ", 0, anchor), html.rfind("<script\n", 0, anchor))
while html[start:start + 30].startswith("<script\\b"): start = html.rfind("<script", 0, start)
assert anchor > 0 and start > 0, "transport script not found"
html = html[:start] + inject + html[start:]
# A79c: the one-file copy carries its own pictures (logo, ticket badges, icons) so nothing shows as broken offline
import base64, re as _re
def _inline(m):
    rel = m.group(2); f = site / rel
    if not f.is_file() or f.stat().st_size > 400000: return m.group(0)
    mime = {'svg': 'image/svg+xml', 'png': 'image/png', 'webp': 'image/webp', 'jpg': 'image/jpeg'}.get(f.suffix[1:].lower())
    return m.group(1) + 'data:' + mime + ';base64,' + base64.b64encode(f.read_bytes()).decode() if mime else m.group(0)
html = _re.sub(r"""(["'(])((?:img/[a-z0-9_/-]+|favicon-32|icon-192|icon-512|apple-touch-icon|icon)\.(?:svg|png|webp|jpg))(?=["')])""", _inline, html)
# A80: the drawn Terry set (img/rex/NN.webp) is chosen in code, so it travels as a lookup the page reads first
rexd = site / "img" / "rex"
if rexd.is_dir():
    rex = {f.stem: "data:image/webp;base64," + base64.b64encode(f.read_bytes()).decode() for f in sorted(rexd.glob("[0-9][0-9].webp"))}
    i = html.find("<script")
    html = html[:i] + "<script>window.__TF_REX=" + json.dumps(rex, separators=(",", ":")) + ";</script>\n" + html[i:]
logd = site / "img" / "logos"
if logd.is_dir():
    lg = {f.stem: "data:image/webp;base64," + base64.b64encode(f.read_bytes()).decode() for f in sorted(logd.glob("*.webp"))}
    i = html.find("<script")
    html = html[:i] + "<script>window.__TF_LOGOS=" + json.dumps(lg, separators=(",", ":")) + ";</script>\n" + html[i:]
out.write_text(html)
print(json.dumps({"files": len(files), "places": len(places), "bytes": out.stat().st_size}))
