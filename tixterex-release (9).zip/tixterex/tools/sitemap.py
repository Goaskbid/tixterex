"""Generate and validate site/sitemap.xml from the files that are actually published.

python3 tools/sitemap.py <site_dir> [--base https://tixterex.com] [--state tools/sitemap_state.json] [--check] [--now ISO]

Runs as part of every release (tools/release.py). Rules:
  1. every canonical, public, indexable HTML page in <site_dir> is listed;
  2. a new page is added automatically, because the list is built from the files on disk;
  3. a deleted page disappears; a redirect page (meta refresh / data-redirect) is never listed;
  4. <lastmod> moves only when the page's meaningful content or structure changes:
     visible text, headings, title, description, canonical, JSON-LD — not scripts, styles,
     build stamps or whitespace. Hashes live in --state (kept in the source tree, not published);
  5. the sitemap stays at /sitemap.xml;
  6. robots.txt must reference it (fixed if missing);
  7. --check validates the result and exits 1 on any problem — a release cannot ship a bad sitemap;
  8. noindex pages, non-canonical pages, duplicates and robots-blocked paths are never listed.
No search-console submission is needed: crawlers find the sitemap through robots.txt and re-read it
on their own schedule. (Google retired the sitemap "ping" endpoint in 2023, so nothing is pinged.)
Nothing here touches the network.
"""
import hashlib, html, json, re, sys
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse
import xml.etree.ElementTree as ET

NS = "http://www.sitemaps.org/schemas/sitemap/0.9"
SKIP_DIRS = {"data", ".git", ".github", "node_modules"}


class Page(HTMLParser):
    """Reads what matters for indexing and for 'did this page really change'."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.canonical = self.robots = self.title = self.desc = None
        self.redirect = False
        self.text, self.heads, self.ld = [], [], []
        self._skip = 0; self._in = None; self._buf = []
    def handle_starttag(self, tag, a):
        a = dict(a)
        if tag in ("script", "style", "noscript", "template", "svg"):
            if tag == "script" and (a.get("type") or "").lower() == "application/ld+json": self._in = "ld"; self._buf = []
            else: self._skip += 1
            return
        if tag == "title": self._in = "title"; self._buf = []
        if tag in ("h1", "h2", "h3"): self.heads.append(tag)
        if tag == "link" and (a.get("rel") or "").lower() == "canonical": self.canonical = a.get("href")
        if tag == "meta":
            n = (a.get("name") or "").lower(); h = (a.get("http-equiv") or "").lower()
            if n == "robots" or n == "googlebot": self.robots = ((self.robots or "") + "," + (a.get("content") or "")).lower()
            if n == "description": self.desc = a.get("content")
            if h == "refresh" and "url=" in (a.get("content") or "").lower(): self.redirect = True
        if "data-redirect" in a: self.redirect = True
    def handle_endtag(self, tag):
        if tag in ("script", "style", "noscript", "template", "svg"):
            if self._in == "ld" and tag == "script": self.ld.append("".join(self._buf)); self._in = None
            elif self._skip: self._skip -= 1
            return
        if tag == "title" and self._in == "title": self.title = "".join(self._buf).strip(); self._in = None
    def handle_data(self, d):
        if self._in: self._buf.append(d); return
        if not self._skip and d.strip(): self.text.append(d.strip())


STAMP = re.compile(r"\b(?:build|built|updated|generated|retrieved)\b[^.\n]{0,40}?(?:\d{4}-\d{2}-\d{2}|\d{1,2} (?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w* \d{4})[^.\n]{0,20}", re.I)


def fingerprint(p):
    """Meaningful content + structure. Whitespace, build stamps and scripts don't count."""
    ld = []
    for raw in p.ld:
        try: ld.append(json.dumps(json.loads(raw), sort_keys=True, ensure_ascii=False))
        except Exception: ld.append(re.sub(r"\s+", " ", raw).strip())
    body = STAMP.sub("", " ".join(p.text))
    body = re.sub(r"\s+", " ", body).strip()
    blob = json.dumps({"t": p.title, "d": p.desc, "c": p.canonical, "h": p.heads, "b": body, "ld": ld}, ensure_ascii=False)
    return hashlib.sha256(blob.encode()).hexdigest()


def url_for(rel, base):
    rel = rel.replace("\\", "/")
    if rel == "index.html": return base + "/"
    if rel.endswith("/index.html"): return base + "/" + rel[: -len("index.html")]
    return base + "/" + rel


def norm(u):
    p = urlparse(u.strip())
    path = re.sub(r"/index\.html$", "/", p.path or "/")
    return f"{p.scheme}://{p.netloc.lower()}{path}"


def robots_rules(site):
    f = site / "robots.txt"; dis, applies = [], False
    if not f.exists(): return dis
    for line in f.read_text().splitlines():
        k, _, v = line.partition(":"); k = k.strip().lower(); v = v.split("#")[0].strip()
        if k == "user-agent": applies = v == "*"
        elif k == "disallow" and applies and v: dis.append(v)
    return dis


def blocked(path, dis):
    return any(path.startswith(d.rstrip("*")) for d in dis)


def scan(site, base):
    """Every published HTML page, with the reason it is (not) in the sitemap."""
    dis, pages, seen = robots_rules(site), [], {}
    for f in sorted(site.rglob("*.html")):
        rel = f.relative_to(site).as_posix()
        if set(rel.split("/")[:-1]) & SKIP_DIRS: continue
        p = Page(); p.feed(f.read_text(errors="replace"))
        url = url_for(rel, base); path = urlparse(url).path
        why = None
        if p.redirect: why = "redirect"
        elif p.robots and "noindex" in p.robots: why = "noindex"
        elif not p.canonical: why = "no canonical"
        elif norm(p.canonical) != norm(url): why = "canonical points elsewhere: " + p.canonical
        elif blocked(path, dis): why = "blocked by robots.txt"
        elif norm(url) in seen: why = "duplicate of " + seen[norm(url)]
        if not why: seen[norm(url)] = rel
        pages.append({"file": rel, "url": url, "fp": fingerprint(p), "excluded": why})
    return pages


def build(site, base, state_file, now):
    state = json.loads(state_file.read_text()) if state_file and state_file.exists() else {}
    today = now.strftime("%Y-%m-%d")
    listed, new_state = [], {}
    for pg in scan(site, base):
        if pg["excluded"]: continue
        old = state.get(pg["url"])
        lastmod = old["lastmod"] if old and old.get("fp") == pg["fp"] else today
        new_state[pg["url"]] = {"fp": pg["fp"], "lastmod": lastmod}
        listed.append((pg["url"], lastmod))
    listed.sort(key=lambda x: (x[0] != base + "/", x[0]))
    xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="' + NS + '">\n' + "".join(
        f"  <url><loc>{html.escape(u)}</loc><lastmod>{m}</lastmod></url>\n" for u, m in listed) + "</urlset>\n"
    (site / "sitemap.xml").write_text(xml)
    rb = site / "robots.txt"; line = f"Sitemap: {base}/sitemap.xml"
    txt = rb.read_text() if rb.exists() else "User-agent: *\nAllow: /\n"
    txt = "\n".join(l for l in txt.splitlines() if not l.lower().startswith("sitemap:")).rstrip() + "\n\n" + line + "\n"
    rb.write_text(txt)
    if state_file: state_file.write_text(json.dumps(new_state, indent=1, ensure_ascii=False, sort_keys=True) + "\n")
    return listed


def validate(site, base):
    """Returns a list of problems; empty means the sitemap is good to ship."""
    errs = []; sm = site / "sitemap.xml"
    if not sm.exists(): return ["sitemap.xml is missing at the site root"]
    raw = sm.read_bytes()
    if len(raw) > 50 * 1024 * 1024: errs.append("sitemap.xml is over 50 MB")
    try: root = ET.fromstring(raw)
    except ET.ParseError as e: return ["sitemap.xml is not well-formed XML: " + str(e)]
    if root.tag != "{%s}urlset" % NS: errs.append("root element must be <urlset> in the sitemaps.org namespace")
    urls = root.findall("{%s}url" % NS)
    if not urls: errs.append("sitemap lists no pages")
    if len(urls) > 50000: errs.append("more than 50,000 URLs (needs a sitemap index)")
    host = urlparse(base).netloc; good = {norm(p["url"]): p for p in scan(site, base)}
    seen = set()
    for u in urls:
        loc = (u.findtext("{%s}loc" % NS) or "").strip(); lm = (u.findtext("{%s}lastmod" % NS) or "").strip()
        p = urlparse(loc)
        if p.scheme != "https" or p.netloc != host: errs.append(f"{loc}: must be an absolute https URL on {host}")
        if norm(loc) in seen: errs.append(f"{loc}: listed twice")
        seen.add(norm(loc))
        pg = good.get(norm(loc))
        if not pg: errs.append(f"{loc}: no published page behind it (deleted?)")
        elif pg["excluded"]: errs.append(f"{loc}: must not be listed ({pg['excluded']})")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2})?(Z|[+-]\d{2}:\d{2}))?", lm): errs.append(f"{loc}: lastmod '{lm}' is not W3C date format")
    for k, pg in good.items():
        if not pg["excluded"] and k not in seen: errs.append(f"{pg['url']}: indexable page missing from the sitemap")
    rb = site / "robots.txt"
    if not rb.exists() or f"sitemap: {base}/sitemap.xml".lower() not in rb.read_text().lower(): errs.append("robots.txt does not reference the sitemap")
    if blocked("/sitemap.xml", robots_rules(site)): errs.append("robots.txt blocks /sitemap.xml")
    return errs


def main(argv):
    site = Path(argv[1]); a = argv[2:]
    base = (a[a.index("--base") + 1] if "--base" in a else "https://tixterex.com").rstrip("/")
    state = Path(a[a.index("--state") + 1]) if "--state" in a else Path(__file__).with_name("sitemap_state.json")
    now = datetime.fromisoformat(a[a.index("--now") + 1]) if "--now" in a else datetime.now(timezone.utc)
    listed = None if "--check-only" in a else build(site, base, state, now)
    errs = validate(site, base) if ("--check" in a or "--check-only" in a) else []
    excluded = [{"file": p["file"], "why": p["excluded"]} for p in scan(site, base) if p["excluded"]]
    print(json.dumps({"listed": len(listed) if listed is not None else None, "excluded": excluded, "problems": errs}, ensure_ascii=False, indent=1))
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
