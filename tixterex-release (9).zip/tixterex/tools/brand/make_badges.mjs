/* A79: the three ticket badges (free, last minute, recommended), drawn in code with Terry and the Baloo 2 font, no
   name on them — so they never carry an old brand. Run: node tools/brand/make_badges.mjs site/img/badges */
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const BR = path.dirname(fileURLToPath(import.meta.url)); const ot = (await import(path.join(BR, 'opentype.mjs'))).default; { const d = path.join(BR, 'rex'), m = {}; for (const f of fs.readdirSync(d)) if (/^\d\d\.webp$/.test(f)) m[f.slice(0, 2)] = 'data:image/webp;base64,' + fs.readFileSync(path.join(d, f)).toString('base64'); globalThis.__TF_REX = m; } await import(path.join(BR, 'dino.js'));
const D = globalThis.TFDino, b = fs.readFileSync(path.join(BR, 'baloo-2-latin-800-normal.woff')), F = ot.parse(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
const INK = '#0b2246';
const text = (s, x, y, size) => { const p = F.getPath(s, x, y, size); return { d: p.toPathData(1), w: F.getAdvanceWidth(s, size) }; };
const badge = (label, fill, prop) => { const t = text(label, 0, 0, 34), W = Math.max(200, Math.ceil(t.w + 124)), T = text(label, 88, 62, 34);
  const n = 11; const shape = `M14 6h${W - 28}a8 8 0 0 1 8 8v${30 - n}a${n} ${n} 0 0 0 0 ${2 * n}v${30 - n}a8 8 0 0 1-8 8h-${W - 28}a8 8 0 0 1-8-8v-${30 - n}a${n} ${n} 0 0 0 0-${2 * n}v-${30 - n}a8 8 0 0 1 8-8z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} 96" width="${W}" height="96" role="img" aria-label="${label}"><path d="${shape}" fill="${fill}" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/><path d="M78 16v64" stroke="${INK}" stroke-width="3" stroke-dasharray="6 5" opacity=".55"/>
<g transform="translate(-30 -16) scale(.46)">${D.terry({ v: prop })}</g><path d="${T.d}" fill="#fff" stroke="${INK}" stroke-width="5" stroke-linejoin="round" paint-order="stroke"/></svg>`; };
const out = process.argv[2] || 'site/img/badges'; fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'free.svg'), badge('FREE', '#14b37d', 'party'));
fs.writeFileSync(path.join(out, 'lastminute.svg'), badge('LAST MINUTE', '#ff8a3d', 'run'));
fs.writeFileSync(path.join(out, 'recommended.svg'), badge('TOP PICK', '#ffc21a', 'thumbs'));
console.log('badges drawn');
