/* A79c — Terry 3: a round, friendly baby T-rex (owner: "a better dino in 33 varieties with animation", "the terex must
   have some association to ticketing (er könnte entwerten) and events … fun and entertaining"). One body, 33 outfits and
   props — ticket inspector with his punch, usher, rock star, goalkeeper, ice-hockey player, Santa … — each with its own
   little animation (the punch clacks, the guitar strums, the ball bounces, confetti falls). Drawn in code: ours to use
   anywhere. 240 × 240 box, facing right. Animation classes only move parts; the page stops them for reduced motion. */
(function (g) {
  const D = g.TFDino = g.TFDino || {};
  const OL = '#163a2b', SK1 = '#5fd18f', SK2 = '#2fa866', SKD = '#238a52', BEL = '#fff1c4', GOLD = '#ffc21a', GOLD2 = '#f2a900', INK = '#0b2246', PINK = '#ff8fa3', WHITE = '#ffffff';
  D.colors = { INK, GOLD, GOLD2, SKIN: SK2, SKIN2: SKD, BELLY: BEL, OL };
  let uid = 0;
  const T = (x, y, r = 0, s = 1) => `transform="translate(${x} ${y})${r ? ` rotate(${r})` : ''}${s !== 1 ? ` scale(${s})` : ''}"`;
  const plate = (x, y, r, s) => `<g ${T(x, y, r, s)}><path d="M-8-11h16a3 3 0 0 1 3 3v4.5a3.4 3.4 0 0 0 0 7V8a3 3 0 0 1-3 3h-16a3 3 0 0 1-3-3v-4.5a3.4 3.4 0 0 0 0-7V-8a3 3 0 0 1 3-3z" fill="${GOLD}" stroke="${OL}" stroke-width="3.2" stroke-linejoin="round"/></g>`;
  /* a ticket: optional bite (validated by Terry) */
  const ticket = (x, y, r, s = 1, bitten = false, cls = '') => `<g class="${cls}" ${T(x, y, r, s)}><path d="M-22-13h44a4 4 0 0 1 4 4v5a4.5 4.5 0 0 0 0 8v5a4 4 0 0 1-4 4h-44a4 4 0 0 1-4-4V4a4.5 4.5 0 0 0 0-8v-5a4 4 0 0 1 4-4z" fill="${GOLD}" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><path d="M-10-9v18" stroke="${INK}" stroke-width="2" stroke-dasharray="3 3"/><path d="M-2-3h16M-2 3h11" stroke="${INK}" stroke-width="2.4" stroke-linecap="round" opacity=".55"/>${bitten ? `<g class="tt-bite"><path d="M10-13l3 6 3-6 3 6 3-6v26l-3-6-3 6-3-6-3 6z" fill="${WHITE}" stroke="${INK}" stroke-width="1.6" stroke-linejoin="round"/></g>` : ''}</g>`;
  const star = (x, y, s, c = GOLD) => `<path ${T(x, y, 0, s)} d="M0-10l3 6.5 7 1-5 5 1.2 7L0 6.2-6.2 9.5-5 2.5-10-2.5l7-1z" fill="${c}" stroke="${INK}" stroke-width="2" stroke-linejoin="round"/>`;
  const note = (x, y, s) => `<g ${T(x, y, 0, s)}><path d="M0 0v-18l12-4v18" stroke="${INK}" stroke-width="3" fill="none" stroke-linecap="round"/><ellipse cx="-3" cy="1" rx="5" ry="4" fill="${INK}"/><ellipse cx="9" cy="-3" rx="5" ry="4" fill="${INK}"/></g>`;
  const heart = (x, y, s, c = '#ff4d6d') => `<path ${T(x, y, 0, s)} d="M0 8C-14-2-12-14-4-14c3 0 4 2 4 4 0-2 1-4 4-4 8 0 10 12-4 22z" fill="${c}" stroke="${INK}" stroke-width="2"/>`;
  /* --- the 33 varieties: what he wears, what he holds, how he moves --- */
  const V = D.VARIETIES = {
    ticket: { label: 'Ticket fan', hand: 'ticket', anim: 'wave' },
    validate: { label: 'Ticket inspector', head: 'cap', hand: 'punch', anim: 'punch' },
    chomp: { label: 'Validates with a bite', hand: 'bitten', anim: 'chomp', mouth: 'open' },
    usher: { label: 'Usher', head: 'usher', hand: 'torch', anim: 'sweep' },
    popcorn: { label: 'Cinema', head: 'glasses3d', hand: 'popcorn', anim: 'munch' },
    film: { label: 'Film buff', hand: 'clapper', anim: 'clap' },
    rock: { label: 'Rock star', head: 'shades', hand: 'guitar', anim: 'strum' },
    drums: { label: 'Drummer', head: 'bandana', hand: 'sticks', anim: 'drum' },
    dj: { label: 'DJ', head: 'headphones', hand: 'vinyl', anim: 'bounce' },
    classic: { label: 'Conductor', head: 'bowtie', hand: 'baton', anim: 'conduct' },
    opera: { label: 'Opera', hand: 'none', anim: 'sing', mouth: 'sing', extra: 'notes' },
    theatre: { label: 'Theatre', hand: 'masks', anim: 'tilt' },
    ballet: { label: 'Ballet', body: 'tutu', hand: 'none', anim: 'twirl' },
    football: { label: 'Football', body: 'scarf', hand: 'ball', anim: 'kick' },
    hockey: { label: 'Ice hockey', head: 'helmet', hand: 'stick', anim: 'slap' },
    tennis: { label: 'Tennis', head: 'band', hand: 'racket', anim: 'swing' },
    basket: { label: 'Basketball', head: 'band', hand: 'hoop', anim: 'dribble' },
    ski: { label: 'Ski race', head: 'beanie', hand: 'poles', anim: 'wobble' },
    festival: { label: 'Festival', head: 'flowers', hand: 'flag', anim: 'sway' },
    party: { label: 'Party', head: 'partyhat', hand: 'popper', anim: 'jump', extra: 'confetti' },
    birthday: { label: 'Birthday', head: 'partyhat', hand: 'cake', anim: 'bob' },
    xmas: { label: 'Christmas market', head: 'santa', hand: 'mug', anim: 'bob', extra: 'snow' },
    market: { label: 'Market', hand: 'basket', anim: 'bob' },
    food: { label: 'Food', head: 'chef', hand: 'fork', anim: 'munch' },
    brunch: { label: 'Brunch', hand: 'coffee', anim: 'sip', extra: 'steam' },
    date: { label: 'Date night', head: 'bowtie', hand: 'rose', anim: 'blush', extra: 'hearts' },
    family: { label: 'Family', hand: 'balloon', anim: 'float' },
    art: { label: 'Museum', head: 'beret', hand: 'brush', anim: 'paint' },
    rain: { label: 'Rain-proof', hand: 'umbrella', anim: 'bob', extra: 'rain' },
    cold: { label: 'Wrap up warm', head: 'beanie', body: 'scarf', hand: 'none', anim: 'shiver' },
    sunny: { label: 'Open air', head: 'shades', hand: 'icecream', anim: 'sway' },
    late: { label: 'Late night', head: 'nightcap', hand: 'none', anim: 'sleepy', eyes: 'sleepy', extra: 'zzz' },
    scout: { label: 'Scouting events', head: 'explorer', hand: 'magnifier', anim: 'search' },
    hello: { label: 'Hello', anim: 'wave' }, scanner: { label: 'Ticket scanner', anim: 'punch' }, detective: { label: 'Detective', anim: 'search' },
    map: { label: 'Finding the way', anim: 'search' }, point: { label: 'This way', anim: 'wave' }, point2: { label: 'Over there', anim: 'wave' },
    idea: { label: 'Got an idea', anim: 'jump' }, sniff: { label: 'On the trail', anim: 'search' }, thumbs: { label: 'Top pick', anim: 'bob' },
    heart: { label: 'Love it', anim: 'blush' }, shrug: { label: 'Nothing here', anim: 'bob' }, run: { label: 'Last minute', anim: 'jump' },
    grumpy: { label: 'Sold out', anim: 'shiver' }, read: { label: 'Programme', anim: 'bob' }, sing: { label: 'Singing', anim: 'sway' },
    medal: { label: 'Winner', anim: 'jump' }, sweat: { label: 'Hurry', anim: 'shiver' }, hero: { label: 'Ticket hoard', anim: 'bob' }
  };
  D.ORDER = Object.keys(V);
  const heads = {
    cap: () => `<g ${T(158, 30, -6)}><path d="M-40 6c4-24 26-34 44-30 18 4 30 16 30 30z" fill="#1c3f8a" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M28 4c14 0 26 2 30 8-10 4-24 4-34 0z" fill="#132d66" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><rect x="-8" y="-12" width="22" height="12" rx="3" fill="${GOLD}" stroke="${OL}" stroke-width="2.5"/><path d="M-2-6h10" stroke="${OL}" stroke-width="2"/></g>`,
    usher: () => `<g ${T(156, 30, -4)}><rect x="-26" y="-14" width="52" height="20" rx="6" fill="#b4233b" stroke="${OL}" stroke-width="4"/><path d="M-26 0h52" stroke="${GOLD}" stroke-width="4"/></g>`,
    glasses3d: () => `<g ${T(164, 60)}><rect x="-30" y="-10" width="26" height="18" rx="4" fill="#ff4d6d" fill-opacity=".75" stroke="${INK}" stroke-width="3.5"/><rect x="6" y="-12" width="26" height="18" rx="4" fill="#38b6ff" fill-opacity=".75" stroke="${INK}" stroke-width="3.5"/><path d="M-4-2h10" stroke="${INK}" stroke-width="3.5"/></g>`,
    shades: () => `<g ${T(166, 58, -4)}><path d="M-32-8h26c0 10-4 16-13 16s-13-6-13-16zM6-10h26c0 10-4 16-13 16S6 0 6-10z" fill="${INK}" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><path d="M-6-8h12" stroke="${INK}" stroke-width="3.5"/><path d="M-26-5l6 0" stroke="#fff" stroke-width="2.5" stroke-linecap="round" opacity=".8"/></g>`,
    bandana: () => `<g ${T(152, 34, -8)}><path d="M-42 10c10-22 60-26 82-6l-4 10c-24-10-54-8-74 4z" fill="#e03131" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><circle cx="-10" cy="2" r="2.5" fill="#fff"/><circle cx="12" cy="0" r="2.5" fill="#fff"/></g>`,
    headphones: () => `<g><path d="M110 70c0-40 70-52 92-12" stroke="${INK}" stroke-width="7" fill="none" stroke-linecap="round"/><rect x="100" y="64" width="20" height="30" rx="8" fill="#5b4bdb" stroke="${INK}" stroke-width="3.5"/></g>`,
    bowtie: () => `<g ${T(150, 132)}><path d="M0 0l-16-9v18zM0 0l16-9v18z" fill="#e03131" stroke="${OL}" stroke-width="3" stroke-linejoin="round"/><circle r="4.5" fill="#b4233b" stroke="${OL}" stroke-width="2.5"/></g>`,
    helmet: () => `<g ${T(156, 44, -6)}><path d="M-46 20c0-34 26-50 52-48 28 2 44 22 42 46z" fill="#1c3f8a" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M-30-8h40M-36 6h56" stroke="#fff" stroke-width="3" opacity=".5"/><path d="M48 20h8v20" stroke="${INK}" stroke-width="3.5" fill="none"/></g>`,
    band: () => `<path d="M104 56c30-16 76-18 104-2" stroke="#e03131" stroke-width="9" fill="none" stroke-linecap="round"/>`,
    beanie: () => `<g ${T(154, 34, -6)}><path d="M-44 14c0-30 22-44 46-44s44 14 44 44z" fill="#e8590c" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><rect x="-48" y="8" width="96" height="14" rx="7" fill="#ffd8a8" stroke="${OL}" stroke-width="4"/><circle cx="0" cy="-34" r="9" fill="#fff" stroke="${OL}" stroke-width="3.5"/></g>`,
    flowers: () => `<g>${[[116, 46, '#ff6b9a'], [136, 32, GOLD], [160, 28, '#a78bfa'], [184, 34, '#ff8a3d'], [200, 48, '#ff6b9a']].map(([x, y, c]) => `<g ${T(x, y)}>${[0, 72, 144, 216, 288].map(a => `<circle ${T(0, 0, a)} cx="0" cy="-6" r="5" fill="${c}" stroke="${OL}" stroke-width="1.6"/>`).join('')}<circle r="3.5" fill="#fff4b0" stroke="${OL}" stroke-width="1.6"/></g>`).join('')}</g>`,
    partyhat: () => `<g ${T(150, 18, -14)} class="tt-hat"><path d="M-18 16L0-34 18 16z" fill="#a78bfa" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M-10-4l8 6M-4-18l8 6M-14 8l10 6" stroke="${GOLD}" stroke-width="3.5" stroke-linecap="round"/><circle cx="0" cy="-36" r="6" fill="${GOLD}" stroke="${OL}" stroke-width="3"/></g>`,
    santa: () => `<g ${T(150, 22, -10)}><path d="M-44 20c4-30 30-44 58-38 20 4 30 18 36 34-14-10-30-12-46-4z" fill="#e03131" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><rect x="-48" y="14" width="96" height="16" rx="8" fill="#fff" stroke="${OL}" stroke-width="4"/><circle cx="54" cy="18" r="9" fill="#fff" stroke="${OL}" stroke-width="3.5"/></g>`,
    chef: () => `<g ${T(152, 10, -6)}><path d="M-26 24v-14c-14-4-14-26 2-26 2-12 22-16 30-4 10-10 30-4 26 12 12 6 6 24-6 22v10z" fill="#fff" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M-26 24h52" stroke="${OL}" stroke-width="4"/></g>`,
    beret: () => `<g ${T(150, 32, -12)}><ellipse rx="40" ry="14" fill="#b4233b" stroke="${OL}" stroke-width="4"/><path d="M0-14v-8" stroke="${OL}" stroke-width="4" stroke-linecap="round"/></g>`,
    nightcap: () => `<g ${T(150, 26, -14)}><path d="M-40 18c6-30 30-40 52-34 22 6 34 30 30 62-10-20-22-32-36-34z" fill="#5b8def" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><circle cx="42" cy="48" r="8" fill="#fff" stroke="${OL}" stroke-width="3.5"/><rect x="-44" y="12" width="70" height="14" rx="7" fill="#fff" stroke="${OL}" stroke-width="4"/></g>`,
    explorer: () => `<g ${T(152, 26, -8)}><path d="M-52 18h104c-8-6-18-8-30-8 0-18-18-30-34-30s-30 12-30 30c-14 0-22 2-10 8z" fill="#c8a165" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M-30 6h60" stroke="#7a5a2a" stroke-width="5"/></g>`
  };
  const bodies = {
    tutu: () => `<path d="M66 176c20 10 76 12 104-2l10 14c-36 16-92 14-124 0z" fill="#ffb3d1" stroke="${OL}" stroke-width="3.5" stroke-linejoin="round"/>`,
    scarf: () => `<g><path d="M104 126c20 10 52 10 72-4l4 14c-22 14-56 14-80 2z" fill="#e03131" stroke="${OL}" stroke-width="3.5" stroke-linejoin="round"/><path d="M118 136l-6 30 14 2 4-28" fill="#e03131" stroke="${OL}" stroke-width="3.5" stroke-linejoin="round"/><path d="M114 150h12M113 158h12" stroke="#fff" stroke-width="3"/></g>`
  };
  /* the thing in his tiny hand (anchored at 176,150) */
  const hands = {
    none: () => '',
    ticket: () => ticket(190, 146, -18, .9, false, 'tt-prop'),
    bitten: () => ticket(222, 90, 10, .6, true, 'tt-prop'),
    punch: () => `<g class="tt-prop" ${T(180, 160, 24, .9)}><path d="M-6 0L22-14M-6 0L22 14" stroke="#6b7a90" stroke-width="7" stroke-linecap="round"/><path d="M-6 0L22-14M-6 0L22 14" stroke="#c5cfdb" stroke-width="3" stroke-linecap="round"/><circle cx="-6" cy="0" r="6" fill="#6b7a90" stroke="${INK}" stroke-width="2.5"/><g class="tt-jaw">${ticket(40, -4, 10, .7, true)}</g></g>`,
    torch: () => `<g class="tt-prop" ${T(186, 148, -20)}><rect x="-4" y="-8" width="26" height="14" rx="3" fill="#6b7a90" stroke="${INK}" stroke-width="3"/><path d="M22-10l50-22v52L22 8z" fill="#fff6b0" opacity=".55"/></g>`,
    popcorn: () => `<g class="tt-prop" ${T(186, 140)}><path d="M-15-6h30l-5 32h-20z" fill="#fff" stroke="${INK}" stroke-width="3"/><path d="M-8-6l2 32M8-6l-2 32" stroke="#e03131" stroke-width="4.5"/>${[[-10, -11], [-2, -16], [7, -12], [12, -6], [-13, -4], [2, -8]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="5.5" fill="#fff6d6" stroke="${INK}" stroke-width="2"/>`).join('')}</g>`,
    clapper: () => `<g class="tt-prop" ${T(190, 144, -10)}><rect x="-18" y="-6" width="36" height="24" rx="2" fill="${INK}"/><g class="tt-jaw"><path d="M-18-6l36-10v8l-36 10z" fill="#fff" stroke="${INK}" stroke-width="2.5"/></g><path d="M-12 2h24M-12 9h16" stroke="#fff" stroke-width="2"/></g>`,
    guitar: () => `<g class="tt-prop" ${T(178, 152, -38)}><rect x="-3.5" y="-62" width="7" height="50" rx="2" fill="#7a4a1d" stroke="${INK}" stroke-width="2.5"/><rect x="-7" y="-72" width="14" height="12" rx="3" fill="#7a4a1d" stroke="${INK}" stroke-width="2.5"/><path d="M0-12c16 0 22 10 20 18 8 6 6 24-20 24S-28 12-20 6c-2-8 4-18 20-18z" fill="#e8590c" stroke="${INK}" stroke-width="3"/><circle cy="6" r="5" fill="${INK}"/></g>`,
    sticks: () => `<g class="tt-prop"><path d="M170 150l34-26M178 156l38-14" stroke="#c8a165" stroke-width="6" stroke-linecap="round"/><ellipse cx="206" cy="206" rx="24" ry="10" fill="#e03131" stroke="${INK}" stroke-width="3"/><path d="M182 206v14h48v-14" fill="#e03131" stroke="${INK}" stroke-width="3"/></g>`,
    vinyl: () => `<g class="tt-prop" ${T(194, 150)}><circle r="20" fill="${INK}"/><circle r="12" fill="none" stroke="#3b4a66" stroke-width="2"/><circle r="6" fill="${GOLD}"/></g>`,
    baton: () => `<g class="tt-prop" ${T(180, 146, -40)}><path d="M0 0h44" stroke="#fff" stroke-width="5" stroke-linecap="round"/><path d="M0 0h44" stroke="${INK}" stroke-width="1.5" stroke-linecap="round" opacity=".4"/></g>`,
    masks: () => `<g class="tt-prop" ${T(194, 142, -8)}><path d="M-22-14c10-5 22-5 30 0 0 16-6 26-15 26s-15-10-15-26z" fill="#fff" stroke="${INK}" stroke-width="3"/><circle cx="-12" cy="-4" r="2.5" fill="${INK}"/><circle cx="-2" cy="-4" r="2.5" fill="${INK}"/><path d="M-12 4q5 5 10 0" stroke="${INK}" stroke-width="2.5" fill="none"/><path d="M2-8c10-5 22-5 30 0 0 16-6 26-15 26S2 8 2-8z" fill="${GOLD}" stroke="${INK}" stroke-width="3"/><circle cx="12" cy="2" r="2.5" fill="${INK}"/><circle cx="22" cy="2" r="2.5" fill="${INK}"/><path d="M12 13q5-5 10 0" stroke="${INK}" stroke-width="2.5" fill="none"/></g>`,
    ball: () => `<g class="tt-prop tt-ball" ${T(200, 206)}><circle r="16" fill="#fff" stroke="${INK}" stroke-width="3"/><path d="M0-6l6 4-2 7h-8l-2-7z" fill="${INK}"/><path d="M0-16v10M6-2l10-3M4 5l6 9M-4 5l-6 9M-6-2l-10-3" stroke="${INK}" stroke-width="2"/></g>`,
    stick: () => `<g class="tt-prop"><path d="M170 150l26 60h30" stroke="#7a4a1d" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><ellipse class="tt-ball" cx="222" cy="222" rx="10" ry="5" fill="${INK}"/></g>`,
    racket: () => `<g class="tt-prop" ${T(182, 146, -30)}><path d="M0 0h20" stroke="${INK}" stroke-width="6" stroke-linecap="round"/><ellipse cx="38" cy="0" rx="18" ry="14" fill="none" stroke="#e03131" stroke-width="5"/><path d="M24 0h28M38-12v24M30-9v18M46-9v18" stroke="${INK}" stroke-width="1.2" opacity=".5"/><circle class="tt-ball" cx="66" cy="-26" r="7" fill="#d4f53c" stroke="${INK}" stroke-width="2"/></g>`,
    hoop: () => `<g class="tt-prop tt-ball" ${T(196, 196)}><circle r="16" fill="#f76707" stroke="${INK}" stroke-width="3"/><path d="M-16 0h32M0-16v32M-11-11c6 6 6 16 0 22M11-11c-6 6-6 16 0 22" stroke="${INK}" stroke-width="2" fill="none"/></g>`,
    poles: () => `<g class="tt-prop"><path d="M172 148l16 70M184 150l22 66" stroke="${INK}" stroke-width="4" stroke-linecap="round"/><path d="M40 226h150M60 232h150" stroke="#e03131" stroke-width="6" stroke-linecap="round"/></g>`,
    flag: () => `<g class="tt-prop" ${T(180, 150, -10)}><path d="M0 0v-56" stroke="${INK}" stroke-width="4" stroke-linecap="round"/><path class="tt-flag" d="M0-56c14-6 26 6 40 0v24c-14 6-26-6-40 0z" fill="#ff6b9a" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/></g>`,
    popper: () => `<g class="tt-prop" ${T(186, 146, -30)}><path d="M0 0l30-8v16z" fill="#a78bfa" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/></g>`,
    cake: () => `<g class="tt-prop" ${T(194, 146)}><rect x="-22" y="-6" width="44" height="22" rx="4" fill="#ffb3d1" stroke="${INK}" stroke-width="3"/><path d="M-22 0c6 6 10-4 15 2s9-4 14 2 10-4 15 0" stroke="#fff" stroke-width="4" fill="none"/><rect x="-2" y="-20" width="4" height="14" fill="#5b8def"/><path class="tt-flame" d="M0-30c5 5 4 10 0 10s-5-5 0-10z" fill="#ff8a3d"/></g>`,
    mug: () => `<g class="tt-prop" ${T(192, 146)}><rect x="-14" y="-12" width="26" height="28" rx="5" fill="#b4233b" stroke="${INK}" stroke-width="3"/><path d="M12-4c10 0 10 14 0 14" stroke="${INK}" stroke-width="3" fill="none"/><path d="M-8-2h14" stroke="#fff" stroke-width="3"/></g>`,
    basket: () => `<g class="tt-prop" ${T(194, 150)}><path d="M-22-4h44l-6 26h-32z" fill="#c8a165" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><path d="M-16-4c0-20 32-20 32 0" stroke="${INK}" stroke-width="3" fill="none"/><circle cx="-8" cy="-8" r="6" fill="#e03131" stroke="${INK}" stroke-width="2"/><circle cx="6" cy="-9" r="6" fill="#ff8a3d" stroke="${INK}" stroke-width="2"/></g>`,
    fork: () => `<g class="tt-prop" ${T(186, 144, -20)}><path d="M0-24v44" stroke="${INK}" stroke-width="4" stroke-linecap="round"/><path d="M-6-24v10a6 6 0 0 0 12 0v-10M0-24v10" stroke="${INK}" stroke-width="3" fill="none"/><circle cx="18" cy="12" r="11" fill="#ff8a3d" stroke="${INK}" stroke-width="3"/></g>`,
    coffee: () => `<g class="tt-prop" ${T(194, 148)}><path d="M-14-10h28l-4 26h-20z" fill="#fff" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><path d="M-14-10h28" stroke="${INK}" stroke-width="3"/><path d="M-10 0h20" stroke="#7a4a1d" stroke-width="5"/></g>`,
    rose: () => `<g class="tt-prop" ${T(188, 144, -16)}><path d="M0 0v34" stroke="#2fa866" stroke-width="4"/><circle cy="-4" r="10" fill="#e03131" stroke="${INK}" stroke-width="3"/><path d="M-4-6c4 4 8 0 4-4" stroke="${INK}" stroke-width="2" fill="none"/></g>`,
    balloon: () => `<g class="tt-prop tt-balloon"><path d="M180 150c14-20 26-40 36-66" stroke="${INK}" stroke-width="2" fill="none"/><ellipse cx="216" cy="66" rx="15" ry="18" fill="#ff4d6d" stroke="${INK}" stroke-width="3"/><path d="M210 58c3-4 7-6 10-4" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".7"/></g>`,
    brush: () => `<g class="tt-prop" ${T(186, 144, -36)}><path d="M0 0h36" stroke="#7a4a1d" stroke-width="5" stroke-linecap="round"/><path d="M36-4c8 0 12 4 12 4s-4 4-12 4z" fill="#5b8def" stroke="${INK}" stroke-width="2"/></g><g class="tt-canvas" ${T(214, 196)}><rect x="-20" y="-26" width="40" height="34" rx="2" fill="#fff" stroke="${INK}" stroke-width="3"/><path d="M-12-6c6-10 12 6 20-6" stroke="#5b8def" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="6" cy="-16" r="4" fill="${GOLD}"/></g>`,
    umbrella: () => `<g class="tt-prop" ${T(176, 150)}><path d="M0 0v-90" stroke="${INK}" stroke-width="4"/><path d="M-56-86c8-36 104-36 112 0-12-8-24-8-28 0-8-8-20-8-28 0-8-8-20-8-28 0-8-8-20-8-28 0z" fill="#38b6ff" stroke="${INK}" stroke-width="3.5" stroke-linejoin="round"/><path d="M0 0c0 8 10 8 10 0" stroke="${INK}" stroke-width="4" fill="none"/></g>`,
    icecream: () => `<g class="tt-prop" ${T(190, 142, -10)}><path d="M-10 0h20l-10 28z" fill="#e8b84a" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><circle cy="-6" r="11" fill="#ffb3d1" stroke="${INK}" stroke-width="3"/><circle cx="2" cy="-18" r="5" fill="#e03131" stroke="${INK}" stroke-width="2"/></g>`,
    magnifier: () => `<g class="tt-prop" ${T(190, 132, -30)}><path d="M-4 18L14 0" stroke="#7a4a1d" stroke-width="7" stroke-linecap="round"/><circle cx="24" cy="-10" r="16" fill="#cfeeff" fill-opacity=".6" stroke="${INK}" stroke-width="4"/><path d="M16-16a10 10 0 0 1 10-4" stroke="#fff" stroke-width="3" stroke-linecap="round"/></g>`
  };
  const extras = {
    notes: () => `<g class="tt-fx">${note(212, 56, .9)}${note(226, 92, .7)}</g>`,
    confetti: () => `<g class="tt-fx">${[[200, 40, GOLD], [222, 70, '#ff6b9a'], [208, 92, '#38b6ff'], [228, 30, '#a78bfa'], [190, 20, '#5fd18f']].map(([x, y, c], i) => `<rect x="${x}" y="${y}" width="7" height="12" rx="2" fill="${c}" stroke="${INK}" stroke-width="1.5" transform="rotate(${i * 37} ${x} ${y})"/>`).join('')}</g>`,
    snow: () => `<g class="tt-fx">${[[30, 30], [70, 14], [210, 24], [226, 70], [20, 96], [196, 100]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="4" fill="#fff" stroke="#9fb3c8" stroke-width="1.5"/>`).join('')}</g>`,
    steam: () => `<g class="tt-fx"><path d="M188 124c-6-8 6-12 0-20M198 122c-6-8 6-12 0-20" stroke="#9fb3c8" stroke-width="3" fill="none" stroke-linecap="round"/></g>`,
    hearts: () => `<g class="tt-fx">${heart(214, 52, 1)}${heart(226, 86, .7)}</g>`,
    rain: () => `<g class="tt-fx">${[[100, 20], [130, 4], [214, 30], [230, 8], [90, 50]].map(([x, y]) => `<path d="M${x} ${y}l-4 10" stroke="#38b6ff" stroke-width="3" stroke-linecap="round"/>`).join('')}</g>`,
    zzz: () => `<g class="tt-fx" font-family="Arial Rounded MT Bold,Nunito,system-ui,sans-serif" font-weight="900" fill="#5b8def"><text x="206" y="40" font-size="22">z</text><text x="222" y="22" font-size="16">z</text></g>`
  };
  /* Terry */
  D.terry = (o = {}) => {
    const key = V[o.v] ? o.v : ({ ticket: 'ticket', binoculars: 'scout', guitar: 'rock', ball: 'football', mask: 'theatre', popcorn: 'popcorn', lantern: 'market', fork: 'food', star: 'party' })[o.prop] || 'ticket';
    const v = V[key], id = 'tt' + (++uid), blink = o.blink !== false;
    /* A80 redraw ("this is not a dino!"): a real T-rex silhouette, comic style — long boxy skull with a big snout and a
       separate lower jaw full of friendly teeth, brow ridge, thick neck, leaning body, long heavy tail, huge thighs with
       three-toed clawed feet and the famous tiny two-fingered arms (holding the ticket). Ticket stubs are his back spikes. */
    const skull = 'M108 66C106 42 128 28 158 28L204 32C222 34 232 44 232 58V66C232 74 227 80 219 80L150 84C126 86 110 82 108 66Z';
    const jaw = 'M124 84L214 81C222 81 225 87 221 93C212 104 188 110 160 108C140 106 126 98 124 84Z';
    const body = 'M108 74C120 90 146 98 156 120C168 146 162 176 142 190C122 204 92 202 74 188C60 176 56 152 68 134C78 120 96 108 108 74Z';
    const tail = 'M78 140C54 134 30 138 4 160C28 160 50 166 74 180Z';
    const belly = 'M130 100C150 114 158 146 148 172C140 186 128 192 116 192C130 170 136 140 126 108Z';
    const teethUp = [154, 166, 178, 190, 202, 212].map(x => `<path d="M${x - 4} 82.5l4 7 4-7z" fill="#fff" stroke="${OL}" stroke-width="1.6" stroke-linejoin="round"/>`).join('');
    const teethLo = [164, 184, 204].map(x => `<path d="M${x - 3.5} 83l3.5-6 3.5 6z" fill="#fff" stroke="${OL}" stroke-width="1.5" stroke-linejoin="round"/>`).join('');
    const eyes = v.eyes === 'sleepy'
      ? `<path d="M140 62q8 6 16 0M172 58q8 6 16 0" stroke="${OL}" stroke-width="4" fill="none" stroke-linecap="round"/>`
      : `<g class="${blink ? 'tt-eye' : ''}"><ellipse cx="148" cy="60" rx="9.5" ry="12" fill="${OL}"/><ellipse cx="180" cy="57" rx="8.5" ry="11" fill="${OL}"/><circle cx="151.5" cy="55" r="3.8" fill="#fff"/><circle cx="183" cy="52.5" r="3.3" fill="#fff"/><circle cx="145.5" cy="65.5" r="1.7" fill="#fff"/><circle cx="177.5" cy="62.5" r="1.5" fill="#fff"/></g>`;
    const jawG = v.mouth === 'open'
      ? `<g class="tt-mouth"><path d="M128 84L214 81 210 96C194 110 160 114 134 100Z" fill="#b4233b" stroke="${OL}" stroke-width="3.5" stroke-linejoin="round"/><g transform="rotate(14 128 84)"><path d="${jaw}" fill="url(#${id}s)" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/>${teethLo}</g></g>`
      : v.mouth === 'sing'
      ? `<g class="tt-mouth"><g transform="rotate(8 128 84)"><path d="${jaw}" fill="url(#${id}s)" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/></g><ellipse cx="190" cy="90" rx="10" ry="6" fill="#b4233b" stroke="${OL}" stroke-width="3"/></g>`
      : `<g class="tt-jawlow"><path d="${jaw}" fill="url(#${id}s)" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/>${teethLo}</g>`;
    return `<g class="tt-terry tt-v-${key} tt-a-${v.anim}"><defs><linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${SK1}"/><stop offset="1" stop-color="${SK2}"/></linearGradient></defs>
<ellipse cx="112" cy="228" rx="74" ry="7" fill="#000" opacity=".12"/>
<g class="tt-tail"><path d="${tail}" fill="url(#${id}s)" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M60 146l-4 8M44 150l-3 7M28 156l-2 6" stroke="${SKD}" stroke-width="3" stroke-linecap="round" opacity=".6"/></g>
<g class="tt-legs"><path d="M138 170C152 168 160 182 156 196L154 214H170C176 214 178 222 172 224H142L144 196C138 190 132 178 138 170Z" fill="${SKD}" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M170 214l6 3-6 4M162 216l5 3-5 3" fill="#fff" stroke="${OL}" stroke-width="1.6" stroke-linejoin="round"/></g>
${[[62, 136, -60, .62], [76, 120, -42, .74], [92, 104, -30, .84], [106, 86, -18, .9], [118, 38, -30, .82], [138, 28, -6, .86]].map(s => plate(...s)).join('')}
<g class="tt-body"><path d="${body}" fill="url(#${id}s)" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/>
<path d="${belly}" fill="${BEL}"/><path d="M134 128h16M137 146h16M134 164h15M126 180h12" stroke="#f0d78f" stroke-width="2.4" stroke-linecap="round"/>
${bodies[v.body] ? bodies[v.body]() : ''}
<circle cx="86" cy="140" r="5" fill="${SKD}" opacity=".5"/><circle cx="78" cy="162" r="3.5" fill="${SKD}" opacity=".5"/><circle cx="100" cy="126" r="3" fill="${SKD}" opacity=".5"/>
</g>
<g class="tt-legs"><path d="M80 168C80 146 116 140 126 164C132 180 124 196 112 200L110 214H130C137 214 139 223 132 225H92C86 225 86 216 92 214H96L98 198C86 192 80 182 80 168Z" fill="url(#${id}s)" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/><path d="M130 214l7 3.5-7 4.5M120 215l6 3.5-6 4M94 216l-6 3.5 6 4" fill="#fff" stroke="${OL}" stroke-width="1.6" stroke-linejoin="round"/><path d="M92 172q10-12 24-4" stroke="${SK1}" stroke-width="4" fill="none" stroke-linecap="round" opacity=".8"/></g>
<g class="tt-head">${jawG}<path d="${skull}" fill="url(#${id}s)" stroke="${OL}" stroke-width="4" stroke-linejoin="round"/>${teethUp}
<path d="M134 44q14-10 30-4M168 40q12-7 24-2" stroke="${OL}" stroke-width="4.5" fill="none" stroke-linecap="round"/>
<circle cx="126" cy="44" r="4.5" fill="${SKD}" opacity=".45"/><circle cx="118" cy="58" r="3.2" fill="${SKD}" opacity=".45"/>
${eyes}<ellipse cx="132" cy="74" rx="8" ry="4.5" fill="${PINK}" opacity=".65"/><ellipse cx="198" cy="70" rx="7" ry="4" fill="${PINK}" opacity=".55"/>
<path d="M220 46q4-3 7 0" stroke="${OL}" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M136 84q-6 0-8-5" stroke="${OL}" stroke-width="3.5" fill="none" stroke-linecap="round"/>${heads[v.head] ? heads[v.head]() : ''}</g>
<g class="tt-arm"><path d="M150 132q14 4 18 14" stroke="${OL}" stroke-width="10" stroke-linecap="round" fill="none"/><path d="M150 132q14 4 18 14" stroke="${SK1}" stroke-width="4.5" stroke-linecap="round" fill="none"/><path d="M168 146l6 2M167 148l4 5" stroke="${OL}" stroke-width="3.2" stroke-linecap="round"/><g transform="translate(176 158) scale(1.15) translate(-176 -150)">${hands[v.hand] ? hands[v.hand]() : ''}</g></g>
${extras[v.extra] ? extras[v.extra]() : ''}</g>`;
  };
  /* A80 (owner, 22 Nov 2026): Terry is now the owner's own drawn set of 50 — every variety is one picture
     (img/rex/NN.webp, 200 px, transparent). Inline SVG places it with <image>; whole-body animation moves it
     (cheap: one element). D.terryVector keeps the code-drawn Terry as a fallback. */
  D.REX = { hello: 0, ticket: 1, chomp: 2, validate: 3, scanner: 4, usher: 5, scout: 6, detective: 7, map: 8, point: 9, point2: 10, idea: 11, sniff: 12, thumbs: 13, party: 14, heart: 15, market: 16, shrug: 17, late: 18, run: 19,
    grumpy: 20, read: 21, sing: 22, rock: 23, drums: 24, dj: 25, opera: 26, classic: 27, theatre: 28, ballet: 29, popcorn: 30, film: 31, football: 32, hockey: 33, basket: 34, tennis: 35, medal: 36, festival: 37, rain: 38, cold: 39,
    sunny: 40, xmas: 41, birthday: 42, food: 43, brunch: 44, date: 45, family: 46, art: 47, sweat: 48, hero: 49, ski: 39 };
  D.rexSrc = key => { const n = D.REX[key] != null ? D.REX[key] : 1, f = String(n).padStart(2, '0'); const m = g.__TF_REX; return (m && m[f]) || (D.rexBase || 'img/rex/') + f + '.webp'; };
  D.terryVector = D.terry;
  D.terry = (o = {}) => { const key = V[o.v] ? o.v : ({ ticket: 'ticket', binoculars: 'scout', guitar: 'rock', ball: 'football', mask: 'theatre', popcorn: 'popcorn', lantern: 'market', fork: 'food', star: 'party' })[o.prop] || 'ticket';
    return `<g class="tt-terry tt-rexg tt-v-${key} tt-a-${V[key].anim}"><image href="${D.rexSrc(key)}" x="0" y="0" width="240" height="240" preserveAspectRatio="xMidYMax meet"/></g>`; };
  D.svg = (o = {}) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240" width="${o.w || 240}" height="${o.h || 240}" role="img" aria-label="${o.label || 'Terry the TixTerex dinosaur'}">${D.terry(o)}</svg>`;
  D.uri = svg => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  /* animation: one stylesheet for all 33 (only transforms and opacity, cheap) */
  D.rexCss = `
@keyframes ttRxBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-3%)}}
@keyframes ttRxHop{0%,60%,100%{transform:translateY(0) scale(1,1)}70%{transform:translateY(0) scale(1.06,.94)}80%{transform:translateY(-9%) scale(.97,1.03)}90%{transform:translateY(0)}}
@keyframes ttRxRock{0%,100%{transform:rotate(-3deg)}50%{transform:rotate(3deg)}}
@keyframes ttRxBeat{0%,100%{transform:translateY(0)}25%{transform:translateY(-4%)}50%{transform:translateY(0)}75%{transform:translateY(-2%)}}
@keyframes ttRxLook{0%,35%,100%{transform:rotate(0)}45%,60%{transform:rotate(-5deg)}70%,85%{transform:rotate(4deg)}}
@keyframes ttRxShiver{0%,100%{transform:translateX(0)}20%{transform:translateX(-1.2%)}40%{transform:translateX(1.2%)}60%{transform:translateX(-.8%)}80%{transform:translateX(.8%)}}
@keyframes ttRxBreathe{0%,100%{transform:scale(1)}50%{transform:scale(1.03,.98)}}
.tt-rexg{transform-box:fill-box;transform-origin:50% 100%}
.tt-anim .tt-rexg{animation:ttRxBob 2.6s ease-in-out infinite}
.tt-anim .tt-rexg.tt-a-jump,.tt-anim .tt-rexg.tt-a-dribble,.tt-anim .tt-rexg.tt-a-punch,.tt-anim .tt-rexg.tt-a-chomp{animation:ttRxHop 1.8s ease-in-out infinite}
.tt-anim .tt-rexg.tt-a-sway,.tt-anim .tt-rexg.tt-a-wave,.tt-anim .tt-rexg.tt-a-conduct,.tt-anim .tt-rexg.tt-a-blush,.tt-anim .tt-rexg.tt-a-paint{animation:ttRxRock 3s ease-in-out infinite}
.tt-anim .tt-rexg.tt-a-strum,.tt-anim .tt-rexg.tt-a-drum,.tt-anim .tt-rexg.tt-a-bounce,.tt-anim .tt-rexg.tt-a-slap,.tt-anim .tt-rexg.tt-a-swing,.tt-anim .tt-rexg.tt-a-kick{animation:ttRxBeat .9s ease-in-out infinite}
.tt-anim .tt-rexg.tt-a-search,.tt-anim .tt-rexg.tt-a-sweep{animation:ttRxLook 4s ease-in-out infinite}
.tt-anim .tt-rexg.tt-a-shiver,.tt-anim .tt-rexg.tt-a-wobble{animation:ttRxShiver 1.4s ease-in-out infinite}
.tt-anim .tt-rexg.tt-a-sleepy{animation:ttRxBreathe 3.6s ease-in-out infinite}
@media (prefers-reduced-motion:reduce){.tt-rexg{animation:none!important}}`;
  D.css = `
.tt-terry *{transform-box:fill-box}
.tt-terry .tt-head{transform-origin:30% 90%}.tt-terry .tt-arm{transform-origin:10% 20%}.tt-terry .tt-tail{transform-origin:95% 50%}.tt-terry .tt-prop{transform-origin:20% 60%}
.tt-terry .tt-eye{transform-origin:50% 50%}
@keyframes ttBlink{0%,93%,100%{transform:scaleY(1)}96%{transform:scaleY(.12)}}
@keyframes ttTail{0%,100%{transform:rotate(-4deg)}50%{transform:rotate(6deg)}}
@keyframes ttBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-3%)}}
@keyframes ttTilt{0%,100%{transform:rotate(0)}50%{transform:rotate(-6deg)}}
@keyframes ttWave{0%,100%{transform:rotate(0)}50%{transform:rotate(-14deg)}}
@keyframes ttPunch{0%,60%,100%{transform:rotate(0)}70%{transform:rotate(-16deg)}80%{transform:rotate(4deg)}}
@keyframes ttChomp{0%,55%,100%{transform:translate(0,0)}65%{transform:translate(-6%,8%) rotate(-6deg)}75%{transform:translate(0,0)}}
@keyframes ttStrum{0%,100%{transform:rotate(0)}25%{transform:rotate(-6deg)}75%{transform:rotate(6deg)}}
@keyframes ttBounceBall{0%,100%{transform:translateY(0)}50%{transform:translateY(-30%)}}
@keyframes ttFloat{0%,100%{transform:translate(0,0) rotate(0)}50%{transform:translate(3%,-6%) rotate(4deg)}}
@keyframes ttFx{0%{transform:translateY(0);opacity:1}100%{transform:translateY(-30%);opacity:0}}
@keyframes ttFall{0%{transform:translateY(-20%);opacity:0}20%{opacity:1}100%{transform:translateY(40%);opacity:0}}
@keyframes ttSpin{to{transform:rotate(360deg)}}
@keyframes ttShiver{0%,100%{transform:translateX(0)}25%{transform:translateX(-1.5%)}75%{transform:translateX(1.5%)}}
@keyframes ttFlame{0%,100%{transform:scale(1)}50%{transform:scale(.8,1.15)}}
@keyframes ttBite{0%,60%{opacity:0}70%,100%{opacity:1}}
.tt-anim .tt-terry .tt-eye{animation:ttBlink 4.6s infinite}
.tt-anim .tt-terry .tt-tail{animation:ttTail 2.4s ease-in-out infinite}
.tt-anim .tt-a-wave .tt-arm,.tt-anim .tt-a-conduct .tt-arm,.tt-anim .tt-a-paint .tt-arm,.tt-anim .tt-a-sweep .tt-arm{animation:ttWave 1.4s ease-in-out infinite}
.tt-anim .tt-a-punch .tt-arm{animation:ttPunch 1.6s ease-in-out infinite}
.tt-anim .tt-a-punch .tt-bite,.tt-anim .tt-a-chomp .tt-bite{animation:ttBite 1.6s infinite}
.tt-anim .tt-a-chomp .tt-head{animation:ttChomp 1.6s ease-in-out infinite}
.tt-anim .tt-a-strum .tt-prop,.tt-anim .tt-a-drum .tt-arm,.tt-anim .tt-a-clap .tt-arm,.tt-anim .tt-a-slap .tt-arm,.tt-anim .tt-a-swing .tt-arm{animation:ttStrum .5s ease-in-out infinite}
.tt-anim .tt-a-kick .tt-ball,.tt-anim .tt-a-dribble .tt-ball,.tt-anim .tt-a-swing .tt-ball{animation:ttBounceBall .7s ease-in-out infinite}
.tt-anim .tt-a-bounce .tt-terry,.tt-anim .tt-a-bounce .tt-head,.tt-anim .tt-a-jump .tt-head,.tt-anim .tt-a-bob .tt-head,.tt-anim .tt-a-munch .tt-head,.tt-anim .tt-a-sip .tt-head{animation:ttBob 1.2s ease-in-out infinite}
.tt-anim .tt-a-bounce .tt-prop{animation:ttSpin 1.2s linear infinite}
.tt-anim .tt-a-tilt .tt-head,.tt-anim .tt-a-sing .tt-head,.tt-anim .tt-a-blush .tt-head,.tt-anim .tt-a-sleepy .tt-head,.tt-anim .tt-a-search .tt-head,.tt-anim .tt-a-sway .tt-head,.tt-anim .tt-a-twirl .tt-head,.tt-anim .tt-a-wobble .tt-head{animation:ttTilt 2.2s ease-in-out infinite}
.tt-anim .tt-a-search .tt-prop{animation:ttFloat 1.8s ease-in-out infinite}
.tt-anim .tt-a-float .tt-balloon{animation:ttFloat 2.6s ease-in-out infinite}
.tt-anim .tt-a-shiver .tt-body,.tt-anim .tt-a-shiver .tt-head{animation:ttShiver .25s linear infinite}
.tt-anim .tt-terry .tt-fx{animation:ttFx 2.4s ease-out infinite}
.tt-anim .tt-v-party .tt-fx,.tt-anim .tt-v-xmas .tt-fx,.tt-anim .tt-v-rain .tt-fx{animation:ttFall 2.2s linear infinite}
.tt-anim .tt-terry .tt-flame{animation:ttFlame .5s ease-in-out infinite;transform-origin:50% 100%}
@media (prefers-reduced-motion:reduce){.tt-terry *{animation:none!important}}`;
  D.injectCss = () => { try { if (typeof document === 'undefined' || document.getElementById('ttDinoCss')) return; const s = document.createElement('style'); s.id = 'ttDinoCss'; s.textContent = D.css + D.rexCss; (document.head || document.documentElement).appendChild(s); } catch (_) {} };
  D.injectCss();
  /* which Terry for which kind of event */
  D.forKind = (kind, seed = '') => { const map = { music: ['rock', 'drums', 'dj', 'classic', 'opera'], sport: ['football', 'hockey', 'tennis', 'basket', 'ski'], stage: ['theatre', 'ballet', 'usher'], film: ['popcorn', 'film'],
    festival: ['festival', 'party'], food: ['food', 'market'], brunch: ['brunch'], market: ['market', 'xmas'], family: ['family', 'birthday'], party: ['party', 'dj'], art: ['art'], other: ['validate', 'chomp', 'ticket'] };
    const list = map[kind] || map.other; let h = 0; for (const c of String(seed)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return list[h % list.length]; };
  const INKC = INK;
  /* jungle leaves: a big monstera-ish leaf, any colour, any angle */
  D.leaf = (x, y, s, r, c = '#1f8a4f', c2 = '#16693b') => `<g transform="translate(${x} ${y}) rotate(${r}) scale(${s})"><path d="M0 0C-30-10-44-48-20-74 4-96 40-80 44-46 48-14 26 6 0 0z" fill="${c}" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><path d="M0 0C6-24 10-48 4-70" stroke="${c2}" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M4-20l-18-8M6-36l-20-12M6-52l-16-10M6-28l18-8M6-46l18-12" stroke="${c2}" stroke-width="2.4" stroke-linecap="round"/></g>`;
  D.fern = (x, y, s, r, c = '#2e9e5b') => `<g transform="translate(${x} ${y}) rotate(${r}) scale(${s})"><path d="M0 0Q4-40 0-80" stroke="${INK}" stroke-width="3" fill="none"/>${[10, 22, 34, 46, 58, 70].map((k, i) => `<path d="M0-${k}q-${16 - i}-4-${22 - i * 2}-14q12 0 22 12zM0-${k}q${16 - i}-4 ${22 - i * 2}-14q-12 0-22 12z" fill="${c}" stroke="${INK}" stroke-width="2"/>`).join('')}</g>`;

  /* one jungle scene per kind of event, for tickets without a photo of their own (120 × 120, shown as a tall slice:
     the middle third stays calm for the time printed over it) */
  const SCENE = {
    music: { a: '#5b4bdb', b: '#241a7a', prop: 'guitar' }, sport: { a: '#14b37d', b: '#065f46', prop: 'ball' }, stage: { a: '#d6336c', b: '#6b0f3a', prop: 'mask' },
    film: { a: '#364fc7', b: '#121a4a', prop: 'popcorn' }, festival: { a: '#f76707', b: '#8a2f00', prop: 'star' }, food: { a: '#e8590c', b: '#7a3200', prop: 'fork' },
    brunch: { a: '#f2a900', b: '#7a5410', prop: 'fork' }, market: { a: '#c2255c', b: '#5c0f2e', prop: 'lantern' }, family: { a: '#1c7ed6', b: '#0b4b80', prop: 'star' },
    party: { a: '#ae3ec9', b: '#4a0f5c', prop: 'star' }, art: { a: '#0ca678', b: '#05523b', prop: 'binoculars' }, other: { a: '#2b8a3e', b: '#0b3d17', prop: 'ticket' } };
  const hash = s => { let h = 2166136261; for (const ch of String(s)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; };
  D.scene = (kind, seed = '', vv, noDino) => {
    const s = SCENE[kind] || SCENE.other, h = hash(seed + kind), id = 'j' + h.toString(36), flip = (h >> 5) & 1, sway = (h >> 3) % 20 - 10;
    const stars = Array.from({ length: 7 }, (_, i) => `<circle cx="${28 + ((h >> i) % 64)}" cy="${6 + ((h >> (i + 5)) % 26)}" r="${.8 + ((h >> (i + 2)) % 3) * .4}" fill="#fff" opacity=".7"/>`).join('');
    return `<svg class="a17-cover tt-scene" viewBox="0 0 120 120" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.a}"/><stop offset="1" stop-color="${s.b}"/></linearGradient></defs>
<rect width="120" height="120" fill="url(#${id})"/>${stars}<circle cx="${flip ? 84 : 36}" cy="22" r="7" fill="#fff6c8" opacity=".85"/>
<path d="M30 44l12 -4" stroke="#ffd8a8" stroke-width="1.6" stroke-linecap="round" opacity="${(h >> 9) % 3 === 0 ? .9 : 0}"/>
<g opacity=".55">${D.leaf(30, 120, .55, -30 + sway, '#0b3d17', '#06280f')}${D.leaf(92, 122, .55, 28 - sway, '#0b3d17', '#06280f')}</g>
${noDino ? '' : `<g transform="translate(${flip ? 96 : 24} 72) scale(${flip ? -.3 : .3} .3)">${D.terry({ v: vv || D.forKind(kind, seed) })}</g>`}
${D.fern(26, 122, .45, -12 + sway / 2, '#2e9e5b')}${D.fern(96, 122, .42, 10 - sway / 2, '#2e9e5b')}${D.leaf(20, 0, .42, 160 + sway, '#1f8a4f')}${D.leaf(104, 2, .4, 200 - sway, '#1f8a4f')}</svg>`;
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
