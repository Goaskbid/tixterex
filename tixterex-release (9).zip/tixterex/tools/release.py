"""One release step, run before every production deployment (and by run_all_tests.sh):
rebuild the indexable pages, regenerate sitemap.xml + robots.txt, validate, and refuse to
continue if anything is wrong.   python3 tools/release.py [site]   → exit 0 = safe to deploy."""
import subprocess, sys
from pathlib import Path
here = Path(__file__).parent; site = sys.argv[1] if len(sys.argv) > 1 else str(here.parent / "site")
for cmd in ([sys.executable, str(here / "build_seo.py"), site], [sys.executable, str(here / "sitemap.py"), site, "--check-only"]):
    r = subprocess.run(cmd)
    if r.returncode: print("RELEASE BLOCKED: " + " ".join(cmd[1:2]) + " failed — do not deploy.", file=sys.stderr); sys.exit(1)
# A89 (audit F01/F02): every data file the page refers to must really be there (the place shards travel in the two
# places zips next to the release zip; a deploy without them is refused here, not discovered by visitors)
import json
sp = Path(site); missing = []
try:
    meta = json.loads((sp / "data/places.json").read_text())
    refs = set((meta.get("parts") or {}).values()) | {x["url"] for x in meta.get("spatial", []) if isinstance(x, dict) and x.get("url")}
    missing = sorted(x for x in refs if not (sp / "data" / x).is_file())
except FileNotFoundError:
    pass
if missing:
    print("RELEASE BLOCKED: %d place data files referenced by data/places.json are missing (first: %s). Add tixterex-places-1.zip and tixterex-places-2.zip." % (len(missing), missing[0]), file=sys.stderr); sys.exit(1)
print("Release checks passed: sitemap.xml and robots.txt are valid and current; all referenced place data present.")
