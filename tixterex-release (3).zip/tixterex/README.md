# TixTerex R92, integrated repair

This is the repaired, rebuildable source and application, not an audit-only overlay. The compiled app, canonical source and deployment workflow belong to one release.

## Publish without Claude

1. Replace the existing TixTerex workflow in `.github/workflows/tixterex.yml` with the supplied `tixterex.yml`. Do not leave a second older TixTerex crawler/deployer active under another filename. Keep your current Pages domain and hosting settings.
2. Create a new GitHub release. Attach the three files **without extracting them**: `tixterex-release.zip`, `tixterex-places-1.zip`, `tixterex-places-2.zip`. Publish the release. Do not attach the source backup as a replacement for these files.
3. In Actions, the release handoff run starts the actual deployment on the default branch. The build summary states the exact release tag, package results and available event-supply counts. A failing build does not replace the current site.

The two place archives are unchanged, complete copies of your supplied files. Their hashes are checked against the main release. This avoids losing the 3,043 locality shards and avoids manually merging files.

The workflow uses the release assets by default even if an older `site/` exists in the repository. To deliberately deploy source checked into the repository, run the workflow manually with `source=repository`, or set the repository variable `TIXTEREX_ARTIFACT_SOURCE=repository`.

## What is implemented

A readable light mobile theme, wrapping filters in a vertical modal, one primary search form, facts-only event details, restrained image loading, retained mascot/logo, no visitor process/test boards, safer city changes, retry after failed/cancelled city-data reads, retained pending-page work, scope-owned service-worker caches, and user-controlled updates.

Ticketcorner's official newsletter subscription link is present in the Menu. Affiliate/data-feed integration is not activated without Ticketcorner's authorisation and actual feed details. See `docs/ticketcorner/`.

The collector now gives configured official city feeds priority over expensive venue discovery and global artist work. Empty runs do not impose the former global 20-hour lock. A forced retry actually revisits due cities/venues. Failed reads do not masquerade as successful observations, and unavailable feeds do not replace their last-good inventory with an empty list.

Deployment preserves valid, newer city data recovered from the existing `ingest-` Actions cache. It rebuilds the city index and spatial tiles from actual validated city files, so an orphaned city file is no longer invisible merely because the old index missed it.

## Collection is not deployment

The new workflow builds, validates and publishes. It does not crawl third-party websites on GitHub, change DNS, provision Cloudflare products or delete rollback releases and diagnostic caches. Existing Cloudflare tooling is retained but is not activated by this workflow. The shared hosting decision is unchanged.

The supplied event snapshot is not newly collected. No live publisher events were added in this repair. An empty supplied nightly index is reported as **EVENT SUPPLY NOT READY**, not as 100/75 coverage. Existing browser feeds still run on an explicit visitor search; their final-origin availability must be checked after deployment.

For an approved local collection environment with Node 22 and Python:

```sh
python tools/collect_snapshot.py --retry
```

This keeps the existing request/time ceilings, preserves collection state and creates `tixterex-inventory.zip` only when there are actual stored occurrences. Attach that optional fourth data ZIP to the release and manually rerun the deploy workflow for that tag. The workflow accepts it only under the data/ingest path. No secret is put into browser HTML. Ticketmaster and other private feed credentials remain environment variables for the collector.

## Rebuild

```sh
python tools/build_site.py
python tools/build_site.py --check
python tools/release.py --output _site
```

`src/manifest.json`, `src/page.html.in`, `src/scripts/` and `src/styles/` are the canonical application inputs. This replaces the inconsistent loose-module build from the old source ZIP. Do not compile the old loose modules over this release. The original upload is preserved separately by its input hash, not silently mixed into this tree.

The source package includes the full place directory. The upload release is split into the three named files only to keep each file below 25 MB.

## Tests

The Python/Node release, city-cache and collector tests are in `qa/r92/`. The inherited browser tests are in `qa/recovery/tests/` and require Playwright, BeautifulSoup4 and Chromium. Publisher responses in these tests are synthetic. They verify code paths, not real city recall.

Actual HTTP navigation to the local test server was blocked by the execution environment. Physical iPhone Safari, deployed service-worker upgrades, live GitHub Actions and production CORS were not certified here. The uploaded evidence exports both concern Zurich; no non-Zurich live run is represented by those files.

**100% top-event recall and 75% public-event recall remain unmeasured.** The independent benchmark and scorer remain in `benchmark/`; synthetic fixtures and source-directory sizes do not substitute for it.
