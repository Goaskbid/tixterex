TIXTEREX - REPLACE THE EXISTING FILE

Use this tixterex-release.zip IN PLACE OF the current attachment with the same name.
Do not extract this ZIP before uploading it.

1. Open the existing latest GitHub release in Goaskbid/tixterex and click Edit.
2. Remove only its old tixterex-release.zip attachment. Upload this replacement
   tixterex-release.zip. Keep both tixterex-places ZIPs and any current inventory
   attachment. Click Update release. Keep the existing release tag.
3. Actions > TixTerex validate and deploy > Run workflow. Choose main and release;
   leave the release_tag blank for the existing latest release, then Run workflow.
   Start a new run, not a rerun of an old job. Editing a release attachment alone
   does not trigger the installed published-only workflow.

No new release, branch, tag or workflow is required.
The installed R94 workflow is retained.
The original two place ZIPs are unchanged and verified against BUNDLE_INPUTS.json.

This is the same R95 restored application, source, artwork and collection code.
Only packaging and these instructions differ. Collection is not activated by a
file delivery; no live deployment or event-coverage claim is made here.
