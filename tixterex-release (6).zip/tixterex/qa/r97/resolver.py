#!/usr/bin/env python3
"""Resolve deployable TixTerex archives by content, not an exact asset filename.
Code uploads take precedence. Applications are never merged. Older releases may supply hash-identical
place archives, never a substitute application. No third-party crawling.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import urllib.parse
import zipfile

MAX_ZIP = 250 * 1024 * 1024
MAX_EXPANDED = 900 * 1024 * 1024
MAX_TOTAL = 1500 * 1024 * 1024
FONT_EXT = {'.woff', '.woff2', '.ttf', '.otf', '.eot'}
PART_NAMES = {'tixterex-places-1.zip', 'tixterex-places-2.zip'}


def release_key(value):
    """Order the embedded application revision, never a download suffix like .2.zip."""
    text = str(value or '').strip().lower()
    match = re.match(r'^[ar](\d+)(?:\.(\d+))?(?:\.(\d+))?(?:[^0-9]|$)', text)
    if not match:
        return (0, 0, 0, 0)
    dates = re.findall(r'(?<!\d)(20\d{6}(?:t?\d{4,6})?)(?!\d)', text)
    stamp = max((int(x.replace('t','').ljust(14,'0')) for x in dates), default=0)
    return tuple(int(x or 0) for x in match.groups()) + (stamp,)

def app_identity(z, prefix, names):
    h=hashlib.sha256()
    for name in sorted(names):
        if not name.startswith(prefix) or name.endswith('/'):
            continue
        rel=name[len(prefix):]
        if not rel.startswith(('site/','src/','tools/')) or rel.startswith(('site/data/localities/','site/data/ingest/')):
            continue
        h.update(rel.encode());h.update(b'\0');h.update(hashlib.sha256(z.read(name)).digest())
    return h.hexdigest()

class ResolveError(RuntimeError):
    pass

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def members(z):
    items = z.infolist()
    if len(items) > 40000 or sum(x.file_size for x in items) > MAX_EXPANDED:
        raise ResolveError('Archive exceeds the safe extraction limit.')
    seen = set()
    for x in items:
        p = PurePosixPath(x.filename)
        if (p.is_absolute() or '..' in p.parts or '\\' in x.filename
                or ':' in x.filename or stat.S_ISLNK(x.external_attr >> 16)):
            raise ResolveError('Unsafe archive path: ' + repr(x.filename))
        if x.flag_bits & 1:
            raise ResolveError('Encrypted archives cannot be deployed.')
        normalized = str(p).casefold().rstrip('/')
        if normalized in seen:
            raise ResolveError('Duplicate archive path: ' + repr(x.filename))
        seen.add(normalized)
    return items

class Resolver:
    def __init__(self, work, releases, fetch_asset, pinned='', source='auto', release_loader=None):
        self.work = Path(work).resolve()
        self.staging = self.work / '_r97_downloads'
        self.staging.mkdir(exist_ok=True)
        self.output = self.work / '_r97_package' / 'tixterex'
        self.releases = [r for r in releases if not r.get('draft') and (pinned or not r.get('prerelease'))]
        self.releases.sort(key=lambda r: (r.get('published_at') or '', r.get('created_at') or ''), reverse=True)
        self.fetch_asset = fetch_asset
        self.release_loader = release_loader
        self._releases_loaded = release_loader is None
        self.pinned = pinned
        self.source = source
        self.archives = {}
        self.cache = {}
        self.total_bytes = 0
        self.expanded_bytes = 0
        self.report = {'schema': 'tixterex-workflow-resolution/1', 'status': 'checking',
                       'workflowRevision': 'r97', 'workflowPatch': 'deterministic-upload-selection', 'assetsSeen': [], 'warnings': [], 'placeParts': [], 'ignoredApplications': []}

    def inspect(self, path, label, depth=0):
        path = Path(path)
        if path.stat().st_size > MAX_ZIP:
            raise ResolveError('ZIP is larger than the download safety limit: ' + label)
        sha = digest(path)
        if sha in self.archives:
            return self.archives[sha]
        result = {'path': path, 'sha256': sha, 'label': label, 'apps': [], 'inventories': []}
        self.archives[sha] = result
        try:
            with zipfile.ZipFile(path) as z:
                items = members(z)
                self.expanded_bytes += sum(x.file_size for x in items)
                if self.expanded_bytes > 2 * MAX_TOTAL:
                    raise ResolveError('Cumulative archive expansion allowance exhausted.')
                names = set(z.namelist())
                for x in items:
                    if x.is_dir():
                        continue
                    if x.filename.endswith('/BUNDLE_INPUTS.json') or x.filename == 'BUNDLE_INPUTS.json':
                        prefix = x.filename[:-len('BUNDLE_INPUTS.json')]
                        needed = ['site/index.html', 'tools/release/assemble.py', 'tools/recovery/readiness_gate.py',
                                  'tools/release/check_package.py', 'tools/cf_budget.mjs']
                        if all(prefix + n in names for n in needed):
                            manifest = json.loads(z.read(x))
                            parts = manifest.get('requiredParts', [])
                            if not isinstance(parts, list):
                                raise ResolveError('Invalid place manifest: ' + label)
                            pn = []
                            for part in parts:
                                if (not isinstance(part, dict) or part.get('name') not in PART_NAMES
                                        or not re.fullmatch(r'[a-f0-9]{64}', str(part.get('sha256', '')))):
                                    raise ResolveError('Invalid required part in ' + label)
                                pn.append(part['name'])
                            if len(pn) != len(set(pn)):
                                raise ResolveError('Duplicate part declaration in ' + label)
                            result['apps'].append({'archive': result, 'prefix': prefix, 'manifest': manifest,
                                                   'rank': int(prefix + 'src/manifest.json' in names),
                                                   'releaseKey': release_key(manifest.get('release', '')),
                                                   'identity': app_identity(z, prefix, names),
                                                   'hasLocalities': any(y.startswith(prefix+'site/data/localities/') and not y.endswith('/') for y in names),
                                                   'updatedAt': ''})
                    if x.filename.endswith('/data/ingest/index.json') and all(
                        y.is_dir() or '/site/data/ingest/' in y.filename for y in items
                    ):
                        result['inventories'].append(x.filename[:-len('index.json')])
                if depth < 2:
                    for i, x in enumerate(items):
                        if x.is_dir() or not x.filename.lower().endswith('.zip'):
                            continue
                        if x.file_size > MAX_ZIP:
                            raise ResolveError('Nested ZIP is too large: ' + x.filename)
                        self.total_bytes += x.file_size
                        if self.total_bytes > MAX_TOTAL:
                            raise ResolveError('Download/expansion allowance exhausted.')
                        child = self.staging / (sha[:16] + '-' + str(i) + '.zip')
                        with z.open(x) as src, open(child, 'wb') as dst:
                            shutil.copyfileobj(src, dst)
                        found = self.inspect(child, label + ' > ' + x.filename, depth + 1)
                        result['apps'].extend(found['apps'])
        except ResolveError:
            self.archives.pop(sha, None)
            raise
        except (zipfile.BadZipFile, json.JSONDecodeError, ValueError, KeyError) as exc:
            self.archives.pop(sha, None)
            raise ResolveError('Unreadable ZIP or manifest: ' + label) from exc
        return result

    def download(self, release, asset):
        aid = asset.get('id')
        if not isinstance(aid, int) or aid <= 0:
            raise ResolveError('Invalid GitHub asset ID.')
        if aid in self.cache:
            return self.cache[aid]
        if asset.get('state', 'uploaded') != 'uploaded':
            raise ResolveError('A release file is still uploading: ' + str(asset.get('name')))
        if int(asset.get('size') or 0) > MAX_ZIP:
            raise ResolveError('Asset exceeds the size allowance: ' + str(asset.get('name')))
        path = self.staging / ('asset-' + str(aid) + '.zip')
        self.fetch_asset(asset, path)
        size = path.stat().st_size
        if size > MAX_ZIP:
            raise ResolveError('Downloaded asset is too large.')
        expected_size = asset.get('size')
        if expected_size is not None and size != int(expected_size):
            raise ResolveError('Incomplete asset download: ' + str(asset.get('name')))
        d = asset.get('digest') or ''
        if d.startswith('sha256:') and digest(path) != d[7:]:
            raise ResolveError('GitHub asset SHA-256 mismatch: ' + str(asset.get('name')))
        self.total_bytes += size
        if self.total_bytes > MAX_TOTAL:
            raise ResolveError('Download allowance exhausted.')
        ref = self.inspect(path, str(release.get('tag_name')) + ': ' + str(asset.get('name')))
        for app in ref['apps']:
            app['updatedAt'] = str(asset.get('updated_at') or asset.get('created_at') or '')
        self.cache[aid] = ref
        return ref

    def release_apps(self, release):
        apps = []
        assets = [a for a in release.get('assets', []) if str(a.get('name', '')).lower().endswith('.zip')]
        self.report['assetsSeen'].append({'tag': release.get('tag_name'), 'names': [a.get('name') for a in assets]})
        if len(assets) > 60:
            raise ResolveError('Release has too many ZIPs to inspect safely. Upload the three replacement ZIPs under Code.')
        for asset in assets:
            name = str(asset.get('name', '')).lower()
            if any(x in name for x in ['places-', 'verification-evidence', 'inventory', 'workflow-only', 'workflow-fixed']):
                continue
            apps.extend(self.download(release, asset)['apps'])
        return apps

    def local_archives(self):
        out = []
        for base, dirs, names in os.walk(self.work):
            rel = Path(base).relative_to(self.work)
            dirs[:] = sorted(d for d in dirs if not d.startswith(('.', '_'))
                             and d not in {'node_modules', 'site', 'src', 'tools'} and len(rel.parts) < 2)
            for name in sorted(names):
                if not name.lower().endswith('.zip'):
                    continue
                path = Path(base) / name
                if path.is_symlink():
                    continue
                try:
                    out.append(self.inspect(path, 'repository: ' + str(rel/name)))
                except ResolveError as exc:
                    # An unrelated old/broken archive is not the chosen replacement.
                    self.report['warnings'].append('Skipped unselected archive '+str(rel/name)+': '+str(exc))
        return out

    def ensure_releases(self):
        if self._releases_loaded:
            return
        self._releases_loaded = True
        rows = self.release_loader()
        self.releases = [r for r in rows if not r.get('draft') and (self.pinned or not r.get('prerelease'))]
        self.releases.sort(key=lambda r: (r.get('published_at') or '', r.get('created_at') or ''), reverse=True)

    def local_application(self):
        # The file the owner overwrites is authoritative. Never consult old releases
        # when this package is present; never silently fall back from a corrupt replacement.
        for relative in ['tixterex-release.zip', 'uploads/tixterex-release.zip']:
            path = self.work / relative
            if path.is_file():
                if path.is_symlink():
                    raise ResolveError('The replacement ZIP must not be a symbolic link.')
                candidate = self.choose(self.inspect(path, 'repository: ' + relative)['apps'])
                if candidate is None:
                    raise ResolveError(relative + ' does not contain the repaired TixTerex application and build tools.')
                self.report['selectionPolicy'] = 'exact replacement ZIP in Code; old Releases and backup applications ignored'
                return candidate
        apps = [a for archive in self.local_archives() for a in archive['apps']]
        candidate = self.choose(apps)
        if candidate:
            self.report['selectionPolicy'] = 'newest embedded application revision among Code ZIPs; no cross-version merge'
        return candidate

    def choose(self, apps):
        if not apps:
            return None
        unique = {(a['archive']['sha256'], a['prefix']): a for a in apps}
        candidates = list(unique.values())
        newest = max(a['releaseKey'] for a in candidates)
        finalists = [a for a in candidates if a['releaseKey'] == newest]
        identities = {a['identity'] for a in finalists}
        if len(identities) > 1:
            # A replace/upload timestamp is meaningful within one Release only.
            times = {a.get('updatedAt','') for a in finalists}
            if '' not in times and len(times) > 1:
                newest_time = max(times)
                finalists = [a for a in finalists if a['updatedAt'] == newest_time]
                identities = {a['identity'] for a in finalists}
            if len(identities) > 1:
                versions = ', '.join(sorted({str(a['manifest'].get('release')) for a in finalists}))
                raise ResolveError('Conflicting files have the SAME embedded application revision ('+versions+
                                   '). Upload the intended replacement as tixterex-release.zip in Code; old ZIPs can stay.')
        # Identical application/build code in a full kit and split release is not ambiguity.
        winner = sorted(finalists, key=lambda a: (-int(a['hasLocalities']), -a['rank'],
                                                 len(a['prefix']), a['archive']['label']))[0]
        for a in candidates:
            if a is winner:
                continue
            self.report['ignoredApplications'].append({
                'file': a['archive']['label'], 'applicationRelease': a['manifest'].get('release'),
                'reason': 'same application copy' if a['identity']==winner['identity'] else 'older application revision'
            })
        return winner

    def extract(self, archive, prefix, destination, data_only=False):
        destination = Path(destination)
        with zipfile.ZipFile(archive['path']) as z:
            for x in members(z):
                if not x.filename.startswith(prefix) or x.is_dir():
                    continue
                suffix = x.filename[len(prefix):]
                rel = PurePosixPath(suffix)
                if not suffix or rel.suffix.lower() in FONT_EXT:
                    continue
                if data_only and rel.suffix.lower() not in {'.json', '.ics'}:
                    raise ResolveError('Unexpected file type in a data archive: ' + suffix)
                target = destination.joinpath(*rel.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(x) as src, open(target, 'wb') as dst:
                    shutil.copyfileobj(src, dst)

    def places_complete(self):
        path = self.output / 'site/data/places.json'
        if not path.is_file():
            return False
        meta = json.loads(path.read_text(encoding='utf-8'))
        refs = set(meta.get('parts', {}).values()) | {x['url'] for x in meta.get('spatial', []) if 'url' in x}
        for ref in refs:
            p = PurePosixPath(ref)
            if p.is_absolute() or '..' in p.parts or '\\' in ref:
                raise ResolveError('Unsafe locality reference.')
        self.report['placeFilesExpected'] = len(refs)
        missing = [r for r in refs if not (self.output/'site/data'/r).is_file()]
        self.report['placeFilesMissing'] = len(missing)
        return bool(refs) and not missing

    def find_parts(self, parts, selected):
        def missing():
            return [p for p in parts if p['sha256'] not in self.archives]
        # Reuse local files and current-release assets first, then only hash-compatible data from older releases.
        self.local_archives()
        if missing():
            self.ensure_releases()
        for release in [selected] + [r for r in self.releases if r is not selected]:
            if release is None or not missing():
                continue
            for asset in release.get('assets', []):
                name = str(asset.get('name', '')).lower()
                if not name.endswith('.zip'):
                    continue
                sha = str(asset.get('digest') or '').removeprefix('sha256:')
                wanted = {p['sha256'] for p in missing()}
                if sha and re.fullmatch('[a-f0-9]{64}', sha) and sha not in wanted and 'kit' not in name:
                    continue
                if release is not selected and not any(k in name for k in ['place', 'kit']):
                    continue
                self.download(release, asset)
                if not missing():
                    break
        if missing():
            names = ', '.join(p['name'] for p in missing())
            raise ResolveError('Application found, but these matching data parts are not uploaded: ' + names +
                               '. Upload the named place ZIPs alongside tixterex-release.zip under Code. Do not change their contents.')
        for part in parts:
            archive = self.archives[part['sha256']]
            prefix = 'tixterex/site/data/localities/'
            with zipfile.ZipFile(archive['path']) as z:
                if any(not x.is_dir() and not x.filename.startswith(prefix) for x in members(z)):
                    raise ResolveError('Unexpected file in locality archive.')
            self.extract(archive, prefix, self.output/'site/data/localities', data_only=True)
            self.report['placeParts'].append({'name': part['name'], 'sha256': part['sha256'], 'obtainedFrom': archive['label']})

    def run(self):
        selected = None
        app = None
        if self.source not in ['auto', 'uploads', 'release', 'repository']:
            raise ResolveError('Source must be auto, uploads, release or repository.')
        if self.source == 'repository':
            root = self.work
            if not (root/'site/index.html').is_file() or not (root/'tools/release/assemble.py').is_file():
                raise ResolveError('Repository mode needs the complete repaired site and tools.')
            if self.output.parent.exists():
                shutil.rmtree(self.output.parent)
            self.output.mkdir(parents=True)
            for name in ['site', 'tools', 'src']:
                if (root/name).is_dir():
                    shutil.copytree(root/name, self.output/name)
            if not self.places_complete():
                raise ResolveError('Checked-in source has an incomplete place directory. Use the complete restored source ZIP.')
            self.report['application'] = 'repository source'
            mf = root/'BUNDLE_INPUTS.json'
            self.report['applicationRelease'] = json.loads(mf.read_text()).get('release') if mf.is_file() else None
        else:
            if self.source in ['auto', 'uploads'] and not self.pinned:
                app = self.local_application()
                if app is None and self.source == 'uploads':
                    raise ResolveError('Upload tixterex-release.zip to the top-level Code file list.')
            if app is None:
                self.ensure_releases()
                candidates = self.releases
                if self.pinned:
                    candidates = [r for r in candidates if r.get('tag_name') == self.pinned]
                    if not candidates:
                        raise ResolveError('The selected published release was not found: ' + self.pinned)
                for release in candidates:
                    apps = self.release_apps(release)
                    app = self.choose(apps)
                    if app:
                        selected = release
                        break
                    self.report['warnings'].append('No deployable application in release ' + str(release.get('tag_name')))
                    if self.pinned:
                        break
            if app is None:
                raise ResolveError('No repaired application ZIP was found. Upload tixterex-release.zip and its two place ZIPs under Code. '
                                   'A workflow ZIP alone is not the website.')
            if self.output.parent.exists():
                shutil.rmtree(self.output.parent)
            self.extract(app['archive'], app['prefix'], self.output)
            self.report['application'] = app['archive']['label']
            self.report['applicationSha256'] = app['archive']['sha256']
            self.report['applicationRelease'] = app['manifest'].get('release')
            self.report['releaseTag'] = selected.get('tag_name') if selected else None
            self.report['completeSourceArchive'] = bool(app['rank'])
            if not self.places_complete():
                self.find_parts(app['manifest'].get('requiredParts', []), selected)
            if not self.places_complete():
                raise ResolveError('The application still has missing place files after archive assembly.')
            if selected is None:
                # Preserve an explicitly uploaded collection snapshot; ordinary app
                # replacement does not create, refresh or fabricate any inventory.
                for relative in ['tixterex-inventory.zip', 'uploads/tixterex-inventory.zip']:
                    path = self.work / relative
                    if not path.is_file():
                        continue
                    ref = self.inspect(path, 'repository: ' + relative)
                    if len(ref['inventories']) != 1:
                        raise ResolveError('Uploaded inventory ZIP has no unique validated inventory root.')
                    self.extract(ref, ref['inventories'][0], self.output/'site/data/ingest', data_only=True)
                    self.report['inventory'] = ref['label']
                    break
            if selected:
                inventories = []
                for asset in selected.get('assets', []):
                    if 'inventory' in str(asset.get('name', '')).lower() and str(asset.get('name', '')).lower().endswith('.zip'):
                        ref = self.download(selected, asset)
                        for prefix in ref['inventories']:
                            inventories.append((ref, prefix))
                if len(inventories) > 1:
                    raise ResolveError('Multiple inventory snapshots found. Keep one current snapshot.')
                for ref, prefix in inventories:
                    self.extract(ref, prefix, self.output/'site/data/ingest', data_only=True)
                    self.report['inventory'] = ref['label']
        self.report['status'] = 'resolved'
        self.report['inputDirectory'] = str(self.output)
        return self.output

def cli():
    work = Path.cwd()
    report_path = work/'_reports/download-report.json'
    report_path.parent.mkdir(exist_ok=True)
    repo = os.environ.get('REPO', '')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo):
        raise ResolveError('Invalid repository identifier.')
    def api(endpoint):
        result = subprocess.run(['gh', 'api', endpoint, '-H', 'Accept: application/vnd.github+json'], capture_output=True, text=True)
        if result.returncode:
            raise ResolveError('GitHub API request failed for ' + endpoint + ': ' + result.stderr.strip()[:800])
        return json.loads(result.stdout)
    event = os.environ.get('GITHUB_EVENT_NAME', '')
    # Ordinary Code uploads always select Code ZIPs first, even if an old
    # repository variable still says "release". An explicit manual choice remains.
    source = os.environ.get('INPUT_SOURCE') or ('auto' if event == 'push' else os.environ.get('CONFIG_SOURCE') or 'auto')
    pinned = os.environ.get('RELEASE_TAG', '').strip()
    if any(c in pinned for c in '\r\n') or len(pinned) > 240:
        raise ResolveError('Invalid release tag.')
    def load_releases():
        releases = []
        if pinned:
            releases.append(api('repos/' + repo + '/releases/tags/' + urllib.parse.quote(pinned, safe='')))
        for page in range(1, 4):
            batch = api('repos/' + repo + '/releases?per_page=100&page=' + str(page))
            releases.extend(r for r in batch if r.get('id') not in {x.get('id') for x in releases})
            if len(batch) < 100:
                break
        for release in releases:
            assets = []
            for page in range(1, 5):
                batch = api('repos/' + repo + '/releases/' + str(int(release['id'])) + '/assets?per_page=100&page=' + str(page))
                assets.extend(batch)
                if len(batch) < 100:
                    break
            release['assets'] = assets
        return releases
    def fetch(asset, target):
        endpoint = 'repos/' + repo + '/releases/assets/' + str(int(asset['id']))
        for attempt in range(3):
            with open(target, 'wb') as stream:
                result = subprocess.run(['gh', 'api', endpoint, '-H', 'Accept: application/octet-stream'], stdout=stream, stderr=subprocess.PIPE)
            if result.returncode == 0:
                return
            if attempt == 2:
                raise ResolveError('Download failed for asset ' + str(asset.get('name')) + ': ' + result.stderr.decode(errors='replace')[:800])
    resolver = Resolver(work, [], fetch, pinned, source, release_loader=load_releases)
    try:
        result = resolver.run()
        with open(os.environ['GITHUB_ENV'], 'a', encoding='utf-8') as stream:
            stream.write('TF_INPUT=' + str(result) + '\n')
            stream.write('TF_ARTIFACT=' + ('release:' + str(resolver.report.get('releaseTag')) if resolver.report.get('releaseTag') else 'repository-archive') + '\n')
    except Exception as exc:
        resolver.report['status'] = 'failed'
        resolver.report['error'] = str(exc)
        raise
    finally:
        report_path.write_text(json.dumps(resolver.report, indent=2), encoding='utf-8')
        summary = os.environ.get('GITHUB_STEP_SUMMARY')
        if summary:
            with open(summary, 'a', encoding='utf-8') as stream:
                stream.write('\n## Release file resolution\n\n```json\n' + json.dumps(resolver.report, indent=2) + '\n```\n')
    print(json.dumps(resolver.report, indent=2))

if __name__ == '__main__':
    try:
        cli()
    except Exception as exc:
        text = str(exc).replace('%', '%25').replace('\r', '%0D').replace('\n', '%0A')
        print('::error::' + text, file=sys.stderr)
        raise SystemExit(1)
